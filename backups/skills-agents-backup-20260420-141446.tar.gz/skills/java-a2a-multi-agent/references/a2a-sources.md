# A2A Sources and Implementation Checkpoints

Last verified: 2026-04-09

## Source Documents

1. Official A2A Repository
- URL: https://github.com/a2aproject/A2A
- Key points used:
  - Official protocol home for architecture, spec, ADRs, and docs
  - JSON-RPC 2.0 interoperability baseline and agent card model

2. Official A2A Changelog
- URL: https://github.com/a2aproject/A2A/blob/main/CHANGELOG.md
- Key points used:
  - `1.0.0` release (2026-03-12)
  - Added/clarified modern operations including `tasks/list`
  - Spec refactor separating protocol from transport mapping
  - Updated extended agent card capability semantics

3. 2025 Full Guide (KO)
- URL: https://a2aprotocol.ai/blog/2025-full-guide-a2a-protocol-ko
- Key points used:
  - A2A is agent-to-agent collaboration standard over JSON-RPC 2.0 + HTTP(S)
  - Agent card discovery and task lifecycle are core
  - A2A and MCP are complementary (agent collaboration vs tool integration)

4. A2A Java Sample
- URL: https://a2aprotocol.ai/blog/a2a-java-sample
- Key points used:
  - Java 17+, Spring Boot-based server module pattern
  - Core endpoints: `/.well-known/agent-card`, `/a2a`, `/a2a/stream`
  - Core operations examples: `message/send`, `tasks/get`, `tasks/cancel` (plus modern `tasks/list` support in latest spec)
  - Model separation for JSON-RPC, Task, Message, Artifact

5. Local Supervisor/Subagent Sample
- Path: /Users/dolpaks/Downloads/project/a2a-samples/samples/java/custom_java_impl/A2A_SUPERVISOR_SUBAGENT_SAMPLE.md
- Key points used:
  - Supervisor workflow: load candidates -> classify intent -> select agent -> forward
  - Subagent workflow adapted to: classify operation -> MCP invocation -> LLM response composition -> build task
  - LangGraph4j state graph orchestration + Spring AI ChatClient

## Practical Implementation Notes

- Keep supervisor and subagent responsibilities strictly separated.
- Treat A2A models as protocol contracts, not business domain models.
- Normalize on one well-known card path internally, but support compatibility mapping where needed.
- Enforce MCP-based domain execution in subagents (no inline domain business logic in orchestration layer).
- Always include LLM composition phase after MCP tool execution for final response shaping.
