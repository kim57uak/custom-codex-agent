# A2A Supervisor / Sub-Agent Generation Manual

This reference turns the architecture documents into a repeatable code-generation workflow.

## 1. Goal

Generate production-oriented A2A supervisor and sub-agent code from a user request or planning document.

- infer the correct language stack when the user does not specify it
- preserve supervisor/sub-agent responsibility boundaries
- keep protocol, orchestration, and domain logic separated
- follow the current source-aligned rules from the host and sub-agent architecture documents

## 2. Language Selection

Choose the implementation language by this priority order:

1. user-specified language or stack
2. existing repository stack
3. explicit language in the planning document
4. architecture keywords and deployment shape in the request

### Java target

Use Java when the request implies a Spring Boot service, a production supervisor, A2A endpoint exposure, or a source stack that already uses Java server code.

Required stack:

- Java 21+
- Spring Boot
- Spring AI
- LangGraph4j
- A2A JSON-RPC / SSE boundary

### Python target

Use Python when the request implies a Python automation service, a lightweight agent runtime, or a repository that is already Python-first.

Required stack:

- latest stable Python version available in the project context
- LangChain
- LangGraph
- A2A-style boundary when the design calls for supervisor/sub-agent communication

## 2.1 LLM Selection

Choose the language model by this priority order:

1. user-specified model or provider
2. project configuration
3. repository defaults
4. task fit for the current generation step

Supported model families for this skill:

- OpenAI GPT-5.4 Mini
- Gemini 3.0 Preview
- Mistral Medium

Suggested fit:

- planning, reasoning, and code synthesis: OpenAI GPT-5.4 Mini
- alternative reasoning or multimodal planning: Gemini 3.0 Preview
- balanced generation or refactor assistance: Mistral Medium

If the user explicitly names a model, honor that preference unless the repository or runtime makes it impossible.

## 3. Request Classification

Classify the request before generating code.

- `supervisor` request: routing, HITL, handoff, agent-card discovery, task lifecycle, orchestration, review gating
- `subagent` request: bounded domain capability, tool/MCP execution, response composition, task result assembly
- `full-stack` request: both supervisor and sub-agent layers
- `refactor` request: improve an existing codebase without changing the external protocol unless the user asks for it

If the request is ambiguous, generate the smallest safe slice first and label assumptions.

## 4. Java Supervisor Generation Rules

When generating a Java supervisor, follow the current architecture documents as the source of truth.

### Mandatory runtime shape

- `Spring Boot` application
- `A2A controller` as the ingress boundary
- `LangGraph4j` for plan/select/invoke/compose style orchestration
- `Spring AI` for planning and composition prompts
- `Redis` for shared state, history, or checkpoint storage when persistence is needed

### Mandatory behavior

- keep A2A protocol models separate from internal domain models
- support `legacy + v1.0` A2A compatibility when required by the target ecosystem
- support `message/send`, `tasks/get`, `tasks/cancel`, and `tasks/list`
- enforce `APPROVE/CANCEL` HITL by default for mutation flows
- show `pre-HITL A2UI` before review or execution when the plan requires extra input
- route through allowlisted agent-card URLs only
- use feature-flagged handoff with max-hop and stream-support validation
- keep progress/event logging aligned through a shared progress module
- use typed state objects instead of loose map-heavy orchestration where possible

### Package design

Prefer a package layout that matches the architecture documents:

- `controller`
- `service`
- `service/agent/graph`
- `service/agent/compose`
- `service/agent/handoff`
- `service/agent/domain`
- `proxy`
- `registry`
- `store`
- `model/a2a`
- `model/internal`
- `config`
- `security`
- `support`

## 5. Python Sub-Agent Generation Rules

When generating a Python sub-agent or agent runtime, keep the same architectural discipline even if the runtime is smaller.

- isolate the protocol boundary from the domain execution layer
- keep tool execution explicit and testable
- make agent capability ownership bounded and narrow
- if the design uses MCP-style execution, keep the tool invocation layer separate from response composition
- if the design uses LangGraph, keep graph nodes deterministic and side-effect scoped

Use the Python stack as the default for agent automation when the request is script-oriented, notebook-oriented, or Python-first.

## 6. Sub-Agent Generation Rules

Generate sub-agents as bounded capability modules, not as mini supervisors.

- one sub-agent should own one domain capability
- keep command execution explicit
- keep internal domain logic out of orchestration glue
- return deterministic outputs for supervisor compatibility
- compose user-facing summaries after tool execution
- surface task/status/artifact data in a machine-readable shape

## 7. Supervisor Generation Flow

Use this sequence when turning a request into code:

1. classify the request
2. identify the target stack
3. extract supervisor responsibilities
4. extract sub-agent responsibilities
5. define protocol boundaries
6. define state, routing, and review policies
7. generate the smallest executable slice
8. verify the changed scope
9. expand only after the first slice is stable

## 8. Quality Constraints

- no hardcoded business rules or environment values in executable logic
- use constants, enums, config, or domain types when fixed values are required
- keep naming meaningful and domain-oriented
- write Korean comments when the user asks for Korean documentation style
- write standard-format comments, docstrings, and Javadoc in Korean as well
- add Javadoc or equivalent documentation on public types and non-obvious logic
- validate security-sensitive paths, especially routing, handoff, token handling, and task transitions
- prefer testable boundaries over clever inline orchestration

## 9. Verification

Verify according to the chosen stack.

### Java

- `./mvnw -q -DskipTests compile`
- `./mvnw -q test`
- `./mvnw -q verify`

### Python

- project-specific lint/test command
- unit tests for routing, tool execution, and task state transitions
- integration tests for agent boundary and message handling
