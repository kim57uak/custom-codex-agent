package com.example.a2a.example;

import static com.example.a2a.example.A2AModels.*;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Service;

@Service
public class SubagentWorkflow {

  private final MpcToolGateway mcp;
  private final ChatClient chatClient;

  public SubagentWorkflow(MpcToolGateway mcp, ChatClient.Builder chatClientBuilder) {
    this.mcp = mcp;
    this.chatClient = chatClientBuilder.build();
  }

  public JsonRpcResponse handleSendMessage(JsonRpcRequest request) {
    String prompt = String.valueOf(request.params().getOrDefault("message", ""));

    Operation op = classifyOperation(prompt);
    Map<String, Object> mcpArgs = buildMcpArgs(prompt, op);

    // Required: domain execution only via MCP function.
    MpcResult toolResult = mcp.invoke(op.mcpFunctionName(), mcpArgs);

    // Required: subagent LLM composes final user-facing response from MCP output.
    String composed = composeWithLlm(prompt, op, toolResult);

    Task task = new Task(
        "task-" + System.currentTimeMillis(),
        "ctx-" + System.currentTimeMillis(),
        TaskState.COMPLETED,
        new Message("assistant", List.of(new Part("text", composed, null, Map.of())), "msg-1"),
        List.of(new Artifact("result", List.of(new Part("json", null, "mcp-result.json", Map.of("raw", toolResult.payload()))))),
        Instant.now(),
        null);

    return new JsonRpcResponse("2.0", request.id(), task, null);
  }

  private Operation classifyOperation(String prompt) {
    String raw = chatClient.prompt()
        .user(u -> u.text("""
            Classify operation as one of: CREATE, READ, CANCEL.
            Return only the label.
            Input: %s
            """.formatted(prompt)))
        .call()
        .content();

    if (raw == null) {
      return Operation.READ;
    }

    return switch (raw.trim().toUpperCase()) {
      case "CREATE" -> Operation.CREATE;
      case "CANCEL" -> Operation.CANCEL;
      default -> Operation.READ;
    };
  }

  private Map<String, Object> buildMcpArgs(String prompt, Operation op) {
    return Map.of("operation", op.name(), "prompt", prompt);
  }

  private String composeWithLlm(String prompt, Operation op, MpcResult result) {
    return chatClient.prompt()
        .user(u -> u.text("""
            You are a reservation subagent.
            Create a concise final response in Korean.
            Mention operation, outcome, and next action.

            Operation: %s
            User Prompt: %s
            MCP Status: %s
            MCP Payload: %s
            """.formatted(op.name(), prompt, result.status(), result.payload())))
        .call()
        .content();
  }

  enum Operation {
    CREATE("reservation.create"),
    READ("reservation.read"),
    CANCEL("reservation.cancel");

    private final String mcpFunctionName;

    Operation(String mcpFunctionName) {
      this.mcpFunctionName = mcpFunctionName;
    }

    String mcpFunctionName() {
      return mcpFunctionName;
    }
  }

  public interface MpcToolGateway {
    MpcResult invoke(String functionName, Map<String, Object> args);
  }

  public record MpcResult(String status, Map<String, Object> payload) {}
}
