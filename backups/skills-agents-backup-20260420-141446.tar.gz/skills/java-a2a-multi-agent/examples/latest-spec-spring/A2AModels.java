package com.example.a2a.example;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public final class A2AModels {
  private A2AModels() {}

  public record JsonRpcRequest(
      String jsonrpc,
      String id,
      String method,
      Map<String, Object> params,
      Map<String, String> metadata) {}

  public record JsonRpcError(int code, String message, Map<String, Object> data) {}

  public record JsonRpcResponse(
      String jsonrpc,
      String id,
      Object result,
      JsonRpcError error) {}

  public enum TaskState {
    TASK_STATE_UNSPECIFIED,
    SUBMITTED,
    WORKING,
    INPUT_REQUIRED,
    COMPLETED,
    CANCELED,
    FAILED,
    REJECTED
  }

  public record Part(String type, String text, String name, Map<String, Object> metadata) {}

  public record Message(String role, List<Part> parts, String messageId) {}

  public record Artifact(String name, List<Part> parts) {}

  public record Task(
      String id,
      String contextId,
      TaskState state,
      Message message,
      List<Artifact> artifacts,
      Instant updatedAt,
      String errorMessage) {}

  public record AgentSkill(String id, String name, String description, List<String> tags) {}

  public record AgentCapabilities(
      boolean streaming,
      boolean pushNotifications,
      boolean stateTransitionHistory,
      Optional<Boolean> extendedAgentCard) {}

  public record AgentCard(
      String name,
      String description,
      String url,
      String version,
      AgentCapabilities capabilities,
      List<AgentSkill> skills,
      List<String> defaultInputModes,
      List<String> defaultOutputModes) {}
}
