package com.example.a2a.example;

import static com.example.a2a.example.A2AModels.*;

import java.util.List;
import java.util.Map;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Service;

@Service
public class SupervisorWorkflow {

  private final AgentRegistry agentRegistry;
  private final A2AClientFactory clientFactory;
  private final ChatClient chatClient;

  public SupervisorWorkflow(AgentRegistry agentRegistry, A2AClientFactory clientFactory, ChatClient.Builder chatClientBuilder) {
    this.agentRegistry = agentRegistry;
    this.clientFactory = clientFactory;
    this.chatClient = chatClientBuilder.build();
  }

  public JsonRpcResponse sendMessage(JsonRpcRequest request) {
    String userPrompt = extractPrompt(request);
    List<AgentCard> candidates = agentRegistry.listCards();
    String selectedUrl = classifyAndSelect(userPrompt, candidates);

    JsonRpcRequest downstream = new JsonRpcRequest(
        "2.0",
        request.id(),
        "SendMessage",
        request.params(),
        request.metadata());

    return clientFactory.clientFor(selectedUrl).post(downstream);
  }

  public JsonRpcResponse getTask(JsonRpcRequest request) {
    String agentUrl = agentRegistry.findOwnerByTaskId((String) request.params().get("id"));
    return clientFactory.clientFor(agentUrl).post(new JsonRpcRequest("2.0", request.id(), "GetTask", request.params(), request.metadata()));
  }

  public JsonRpcResponse listTasks(JsonRpcRequest request) {
    // In production, aggregate per-tenant/per-agent with cursor handling.
    return new JsonRpcResponse("2.0", request.id(), Map.of("tasks", List.of(), "nextPageToken", ""), null);
  }

  public JsonRpcResponse cancelTask(JsonRpcRequest request) {
    String agentUrl = agentRegistry.findOwnerByTaskId((String) request.params().get("id"));
    return clientFactory.clientFor(agentUrl).post(new JsonRpcRequest("2.0", request.id(), "CancelTask", request.params(), request.metadata()));
  }

  private String classifyAndSelect(String prompt, List<AgentCard> cards) {
    String shortlist = cards.stream().map(c -> c.name() + " => " + c.url()).reduce((a, b) -> a + "\n" + b).orElse("");
    String answer = chatClient.prompt()
        .user(u -> u.text("""
            Select exactly one agent URL for the request.
            Return URL only.

            Request:
            %s

            Candidates:
            %s
            """.formatted(prompt, shortlist)))
        .call()
        .content();
    return answer == null || answer.isBlank() ? cards.get(0).url() : answer.trim();
  }

  private String extractPrompt(JsonRpcRequest request) {
    // Keep protocol parsing isolated in mapper layer in production.
    return String.valueOf(request.params().getOrDefault("message", ""));
  }

  public interface AgentRegistry {
    List<AgentCard> listCards();

    String findOwnerByTaskId(String taskId);
  }

  public interface A2AClientFactory {
    A2AHttpClient clientFor(String baseUrl);
  }

  public interface A2AHttpClient {
    JsonRpcResponse post(JsonRpcRequest request);
  }
}
