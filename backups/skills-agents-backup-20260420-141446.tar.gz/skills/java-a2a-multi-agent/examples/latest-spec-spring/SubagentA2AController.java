package com.example.a2a.example;

import static com.example.a2a.example.A2AModels.*;

import java.util.List;
import java.util.Map;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/a2a")
public class SubagentA2AController {

  private final SubagentWorkflow workflow;

  public SubagentA2AController(SubagentWorkflow workflow) {
    this.workflow = workflow;
  }

  @PostMapping
  public ResponseEntity<JsonRpcResponse> handle(@RequestBody JsonRpcRequest request) {
    if (!"2.0".equals(request.jsonrpc())) {
      return ResponseEntity.badRequest().body(error(request.id(), -32600, "Invalid Request"));
    }

    return switch (normalizeMethod(request.method())) {
      case "SendMessage" -> ResponseEntity.ok(workflow.handleSendMessage(request));
      case "GetTask" -> ResponseEntity.ok(handleGetTask(request));
      case "ListTasks" -> ResponseEntity.ok(handleListTasks(request));
      case "CancelTask" -> ResponseEntity.ok(handleCancelTask(request));
      default -> ResponseEntity.ok(error(request.id(), -32601, "Method not found"));
    };
  }

  private JsonRpcResponse handleGetTask(JsonRpcRequest request) {
    String taskId = String.valueOf(request.params().getOrDefault("id", "unknown"));
    Task task = new Task(
        taskId,
        "ctx-" + taskId,
        TaskState.COMPLETED,
        new Message("assistant", List.of(new Part("text", "Task status fetched", null, Map.of())), "msg-get-1"),
        List.of(),
        java.time.Instant.now(),
        null);

    return new JsonRpcResponse("2.0", request.id(), task, null);
  }

  private JsonRpcResponse handleListTasks(JsonRpcRequest request) {
    return new JsonRpcResponse("2.0", request.id(), Map.of("tasks", List.of(), "nextPageToken", ""), null);
  }

  private JsonRpcResponse handleCancelTask(JsonRpcRequest request) {
    String taskId = String.valueOf(request.params().getOrDefault("id", "unknown"));
    Task task = new Task(
        taskId,
        "ctx-" + taskId,
        TaskState.CANCELED,
        new Message("assistant", List.of(new Part("text", "Task canceled", null, Map.of())), "msg-cancel-1"),
        List.of(),
        java.time.Instant.now(),
        null);

    return new JsonRpcResponse("2.0", request.id(), task, null);
  }

  private static String normalizeMethod(String method) {
    return switch (method) {
      case "message/send" -> "SendMessage";
      case "tasks/get" -> "GetTask";
      case "tasks/list" -> "ListTasks";
      case "tasks/cancel" -> "CancelTask";
      default -> method;
    };
  }

  private static JsonRpcResponse error(String id, int code, String message) {
    return new JsonRpcResponse("2.0", id, null, new JsonRpcError(code, message, null));
  }
}
