package com.example.a2a.example;

import static com.example.a2a.example.A2AModels.*;

import java.util.List;
import java.util.Optional;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AgentCardController {

  @GetMapping(value = "/.well-known/agent-card.json", produces = MediaType.APPLICATION_JSON_VALUE)
  public AgentCard getCard() {
    return new AgentCard(
        "Reservation Subagent",
        "Create/read/cancel reservation tasks via MCP tools",
        "https://reservation-agent.example.com/a2a",
        "1.0.0",
        new AgentCapabilities(true, false, true, Optional.of(true)),
        List.of(
            new AgentSkill("reservation-create", "Create Reservation", "Create reservation records", List.of("reservation", "create")),
            new AgentSkill("reservation-read", "Get Reservation", "Find reservation by id", List.of("reservation", "read")),
            new AgentSkill("reservation-cancel", "Cancel Reservation", "Cancel reservation", List.of("reservation", "cancel"))),
        List.of("text"),
        List.of("text", "json"));
  }
}
