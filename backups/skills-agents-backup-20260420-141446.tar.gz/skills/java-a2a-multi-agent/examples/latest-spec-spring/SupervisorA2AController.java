package com.example.a2a.example;

import static com.example.a2a.example.A2AModels.*;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/a2a")
public class SupervisorA2AController {
  private final SupervisorWorkflow workflow;

  public SupervisorA2AController(SupervisorWorkflow workflow) {
    this.workflow = workflow;
  }

  @PostMapping
  public ResponseEntity<JsonRpcResponse> handle(@RequestBody JsonRpcRequest request) {
    if (!"2.0".equals(request.jsonrpc())) {
      return ResponseEntity.badRequest().body(error(request.id(), -32600, "Invalid Request"));
    }

    return switch (normalizeMethod(request.method())) {
      case "SendMessage" -> ResponseEntity.ok(workflow.sendMessage(request));
      case "GetTask" -> ResponseEntity.ok(workflow.getTask(request));
      case "ListTasks" -> ResponseEntity.ok(workflow.listTasks(request));
      case "CancelTask" -> ResponseEntity.ok(workflow.cancelTask(request));
      default -> ResponseEntity.ok(error(request.id(), -32601, "Method not found"));
    };
  }

  private static String normalizeMethod(String method) {
    // Migration compatibility for older method names.
    return switch (method) {
      case "message/send" -> "SendMessage";
      case "tasks/get" -> "GetTask";
      case "tasks/list" -> "ListTasks";
      case "tasks/cancel" -> "CancelTask";
      default -> method;
    };
  }

  private static JsonRpcResponse error(String id, int code, String message) {
    return new JsonRpcResponse("2.0", id, null, new JsonRpcError(code, message, null));
  }
}
