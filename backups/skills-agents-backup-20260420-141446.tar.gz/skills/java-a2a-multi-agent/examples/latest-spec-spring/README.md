# Latest A2A (v1.0.0-aligned) Java/Spring Sample

This sample reflects current A2A direction from the official spec/changelog:
- JSON-RPC method names use PascalCase (`SendMessage`, `GetTask`, `ListTasks`, `CancelTask`)
- Agent card discovery endpoint: `/.well-known/agent-card.json`
- Subagent execution uses MCP functions, then LLM composition for final response

## Files

- `A2AModels.java`: minimal protocol and domain models for sample wiring
- `AgentCardController.java`: serves `/.well-known/agent-card.json`
- `SupervisorA2AController.java`: JSON-RPC entrypoint and method routing
- `SupervisorWorkflow.java`: supervisor routing workflow (candidate load -> classify -> forward)
- `SubagentA2AController.java`: subagent JSON-RPC endpoint for supervisor calls
- `SubagentWorkflow.java`: subagent flow with MCP invocation + LLM response composition

## Notes

- This is architecture-focused sample code, not a drop-in SDK implementation.
- Keep protocol models (`model/a2a`) separate from internal domain models.
- For compatibility migration, you may temporarily accept legacy names (`message/send`, etc.) and map them to PascalCase operations.
