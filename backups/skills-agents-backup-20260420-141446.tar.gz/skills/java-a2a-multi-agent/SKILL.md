---
name: java-a2a-multi-agent
description: Build A2A multi-agent systems with supervisor-subagent architecture, JSON-RPC 2.0 contracts, agent-card discovery, routing workflows, and verification gates. Use Java/Spring Boot/Java 21+/Spring AI/LangGraph4j for Java targets and LangChain/LangGraph/latest Python for Python targets.
origin: custom
---

# A2A Multi-Agent Patterns

Use this skill when generating or implementing multi-agent collaboration from planning docs, architecture docs, or codebase context.

## When to Activate

- Designing supervisor-subagent orchestration in Java/Spring Boot or Python
- Implementing A2A endpoints (`/a2a`, `/a2a/stream`) with JSON-RPC 2.0 when the target stack is Java
- Building agent-card based discovery and capability routing
- Adding task lifecycle handling (`message/send`, `tasks/get`, `tasks/cancel`, `tasks/list`)
- Generating supervisor or sub-agent code from a planning document
- Automatically selecting Java or Python from user intent and repository context
- Integrating Spring AI + LangGraph4j state workflows for Java routing/execution
- Integrating LangChain + LangGraph workflows for Python agent runtime generation
- Using OpenAI GPT-5.4 Mini, Gemini 3.0 Preview, or Mistral Medium as the generation LLM when the user or project context requires it

## Generation Manual

Read `references/generation-manual.md` before generating code from a planning document.

- Use it as the operational workflow for language selection, request classification, supervisor generation, and sub-agent generation.
- Use it for LLM selection as well.
- Use it for Korean standard-format comments, docstrings, and Javadoc as well.
- Treat it as the source of truth for whether Java or Python should be generated.
- If the request is ambiguous, generate the smallest safe slice first and label assumptions.

## Baseline Architecture (Required)

Always start from A2A supervisor-subagent architecture:

1. Supervisor Agent
- Receives user request
- Discovers/loads candidate subagents (agent cards)
- Routes to best subagent by intent + capability
- Aggregates/forwards task responses

2. Subagent
- Handles domain-specific capability only
- Interprets task message and executes internal operations
- Returns task/artifact/status in A2A format

3. Protocol Boundary
- JSON-RPC 2.0 over HTTP(S)
- A2A methods: `message/send`, `tasks/get`, `tasks/cancel`, `tasks/list`
- Optional streaming path: `/a2a/stream` (SSE)
- Multi-transport compatibility: JSON-RPC baseline, with gRPC/HTTP+JSON mapping compatibility where needed

## Language Targeting

Choose the target stack from the request and repository context before generating code.

### Java target

Choose Java when the user asks for a Spring Boot service, a production supervisor, or the request references the Spring AI / LangGraph4j source documents.

Required stack:

- Java 21+
- Spring Boot
- Spring AI
- LangGraph4j
- A2A JSON-RPC/SSE boundary

### Python target

Choose Python when the user asks for a Python-first agent runtime or the planning doc explicitly describes a Python implementation.

Required stack:

- latest stable Python version available in context
- LangChain
- LangGraph

When the request is ambiguous, infer the target from the architecture docs, repository stack, and execution environment, then state the assumption briefly.

## Current Source-Aligned Supervisor Rules

Use the source documents under `a2a-host_agent-architecture` and `mcp-orchestrator-architecture` as the operational baseline when designing or implementing a Java/Spring Boot supervisor.

- The supervisor entrypoint is a single A2A controller path such as `/a2a/supervisor`; do not fan out through other controllers from inside the supervisor flow.
- Support `legacy + v1.0` A2A method compatibility by default when the target ecosystem needs it.
- `APPROVE` and `CANCEL` are the baseline HITL decisions; treat `REVISE` and richer review flows as follow-up scope unless the user explicitly requires them.
- For create/update/delete style requests on product, reservation, or order flows, enforce HITL regardless of risk score.
- If pre-HITL A2UI is available, show it before HITL or execution.
- Use `SupervisorProgressSupport` or an equivalent shared progress module so user-facing progress and operational event logging stay aligned.
- Handoff is feature-flagged, off by default, and must respect allowed methods, allowed agent URLs, max hops, and stream support compatibility.
- A downstream agent that does not support stream handoff must be blocked from stream handoff regardless of other routing signals.
- Routing state should be explicit and typed; avoid raw `Map<String, Object>` for primary supervisor state when a dedicated value object is feasible.
- Swarm state and graph checkpoint are separate concerns: use swarm state for shared facts/event log and checkpoint for graph resume state.
- Swarm state updates should use optimistic versioning and retry-on-conflict semantics rather than blind overwrite.
- Circuit breaker is a hard invoke-time block; swarm cooldown is a soft planning-time skip.
- Structured event logging should preserve node, taskId, agent, status, and duration-style metadata.
- Javadoc is required for new or changed public types and 핵심 public methods in the supervisor area.

## Version Alignment (Latest A2A)

Use the latest public A2A architecture as baseline:

- A2A repo changelog indicates `1.0.0` release (2026-03-12) with spec refactors and transport mapping updates.
- `tasks/list` is part of modern task operations.
- Agent card capabilities now include extended card support semantics.
- Production design should be written to support `1.0` protocol interfaces while maintaining compatibility with deployed `0.3` ecosystems when required.

## Recommended Java Package Structure

```text
src/main/java/com/example/a2a/
  advice/            # global exception mapping for JSON-RPC/A2A errors
  config/            # Spring config (A2A, AI models, WebClient, security)
  controller/        # A2A endpoint controllers (/a2a, /a2a/stream)
  service/           # supervisor and subagent workflow orchestration
  proxy/             # A2A clients to downstream subagents
  registry/          # agent-card loading/cache/discovery registry
  workflow/          # LangGraph4j state nodes and compiled graphs
  model/
    a2a/             # JSON-RPC, Task, Message, Part, Artifact models
    internal/        # intent/routing/internal command models
  mapper/            # request-response and domain mapping
  security/          # authn/authz/token validation and trust controls
  support/           # id generation, correlation, retry/backoff, utilities
src/main/resources/
  application.yml
  application-dev.yml
  application-prod.yml
src/test/java/...    # mirrors main
```

Rules:
- `model/a2a` is protocol contract; do not mix business DTOs into it.
- `proxy` must isolate all remote agent calls and retry/timeouts.
- `workflow` should be deterministic and side-effect scoped per node.

## Supervisor And Sub-Agent Generation Manual

Use the architecture documents as the blueprint when generating code.

- For supervisor code, generate a single ingress boundary, explicit routing state, review gating, handoff policy, and typed state objects.
- For sub-agent code, generate one bounded capability per agent and keep tool execution separate from response composition.
- For Java, prefer Spring AI + LangGraph4j + Spring Boot + Java 21+.
- For Python, prefer LangChain + LangGraph + the latest stable Python version in context.
- For both stacks, make the architecture explicit in package layout, state flow, and tests before filling in implementation details.
- For both stacks, write standard-format comments in Korean for public APIs, domain rules, and complex flows.

## A2A Contract Rules

1. JSON-RPC Envelope
- Validate `jsonrpc == "2.0"`
- Validate `method` in supported set
- Return standardized `JSONRPCError` for invalid/missing fields

2. Task Lifecycle
- Use stable task IDs
- Track states (`submitted`, `working`, `input-required`, `completed`, `failed`)
- Support status query and cancellation consistently

3. Message/Artifact Discipline
- `role` and `parts` must be explicit
- Use artifacts for finalized outputs
- Keep result payload machine-readable where possible

4. Discovery
- Publish and consume agent cards via a well-known endpoint
- Maintain compatibility with ecosystem conventions (`/.well-known/agent-card`, and if required by your platform, `/.well-known/agent.json`)

## Supervisor Workflow Pattern (LangGraph4j)

Standard node sequence:

1. `prepareInput`
- Parse request params into typed A2A model
- Extract normalized user prompt

2. `loadCandidates`
- Load/cached-read agent cards
- Build candidate summaries: name, url, capabilities, skills/tags

3. `classifyIntent`
- Use Spring AI ChatClient (or deterministic rules first)
- Select target agent URL with explainable rationale

4. `forwardRequest`
- Call selected subagent via A2A client
- Persist task-owner mapping for `tasks/get`, `tasks/cancel`

5. `finalizeResponse`
- Map downstream response to upstream JSON-RPC response

Supervisor runtime node/state flow should reflect the current source shape:

1. `REQUEST_RECEIVED`
2. `HITL_EVALUATING`
3. `WAITING_REVIEW` or `REQUEST_VALIDATED`
4. `HISTORY_LOADED`
5. `PLANNED`
6. `ROUTING_SELECTED`
7. `A2A_CALLING`
8. `HANDOFF_EVALUATING`
9. `HANDOFF_APPLIED` or `HANDOFF_SKIPPED`
10. `A2A_RESULT_MERGED`
11. `COMPOSING`
12. `COMPLETED`

When `tasks/review/decide` returns `APPROVE`, the same taskId should resume execution. When `CANCEL` is chosen, terminate the waiting-review task cleanly.

## Subagent Workflow Pattern

Standard node sequence:

1. `extractPrompt`
2. `classifyOperation`
3. `planMcpInvocation`
4. `executeMcpFunction`
5. `composeResponseWithLlm`
6. `buildTaskResponse`

Rules:
- Each subagent owns one bounded domain.
- Domain operations should be explicit (`create/read/delete` etc.).
- Return deterministic response shapes for supervisor compatibility.
- `executeDomainFunction` must be implemented as MCP tool/function invocation.
- Do not implement business logic inline inside subagent orchestration nodes.
- Subagent must call its configured LLM after MCP execution to summarize/normalize outputs into final A2A response artifacts/messages.

## MCP Execution Contract (Required)

For subagent execution:

1. Intent -> MCP mapping
- Map operation class to explicit MCP function name and typed arguments.

2. MCP call
- Execute only via MCP client/tool layer (`proxy` or dedicated `mcp/` adapter).
- Enforce timeout/retry/circuit-breaker and structured error mapping.

3. LLM response composition
- Feed MCP result (sanitized/normalized) to subagent LLM prompt.
- Generate user-facing summary + machine-usable structured payload.
- Include task status transition and artifacts/messages in A2A-compliant form.

## Security and Trust Rules

- Enforce TLS for inter-agent communication in production.
- Validate auth tokens between supervisor and subagents.
- Never trust forwarded headers without trusted proxy config.
- Restrict supervisor routing to allowlisted agent-card domains/URLs.
- Add timeout, retry, and circuit-breaker on every remote agent call.
- Do not call subagent internals directly; only use the A2A invocation boundary and registered agent-card targets.
- Treat method fallback as a compatibility feature, not a way to bypass the protocol contract.

## Package And Boundary Rules

Use package boundaries that keep the supervisor readable and testable.

- `controller` handles A2A ingress only.
- `service` handles use-case orchestration and HITL decisions.
- `service/agent/graph` owns LangGraph state and node assembly.
- `service/agent/compose` owns response composition and A2UI assembly.
- `service/agent/handoff` owns handoff evaluation and application.
- `service/agent/domain` or equivalent owns domain capability registry and typed extraction.
- `model/a2a` remains protocol contract only.
- `proxy` or `client` owns downstream A2A calls and retries.
- `store` owns swarm state, history, and checkpoint persistence.
- `runtime` owns LLM runtime access.

Prefer interfaces in upper layers; concrete implementation details should stay in adapter packages.

## Configuration Rules

Externalize supervisor routing and safety policy in configuration instead of hardcoding.

- routing target URLs
- allowed methods
- timeouts and retries
- HITL mandatory mutation policy
- handoff feature flag
- handoff hop / per-minute limits
- progress emission switches
- circuit breaker thresholds and open duration
- swarm state versioning / TTL policy
- generation LLM choice when the project exposes multiple supported models

The recommended configuration model should separate routing, HITL, swarm, handoff, and progress concerns so that each concern can evolve independently.

## Reliability Rules

- Use idempotency keys for retryable writes.
- Include correlation IDs across supervisor/subagent logs.
- Keep per-node logs structured: `node`, `taskId`, `agent`, `status`, `durationMs`.
- On downstream failure, return typed A2A/JSON-RPC errors, never raw stack traces.
- On MCP failure, return normalized error payloads and let LLM produce safe, actionable failure summaries.

## Verification Gate (Maven or Gradle)

Run only the project build tool in use.

Maven:
```bash
./mvnw -q -DskipTests compile
./mvnw -q test
./mvnw -q verify
```

Gradle:
```bash
./gradlew compileJava
./gradlew test
./gradlew check
```

A2A-specific checks:
- agent-card endpoint responds and schema is valid
- `/a2a` handles `message/send`, `tasks/get`, `tasks/cancel`, `tasks/list`
- `/a2a/stream` SSE works or is explicitly disabled
- supervisor routes correctly to expected subagent
- cancellation/status query works for long-running tasks
- subagent executes domain actions through MCP (no inline domain logic path)
- subagent LLM composition step is present and tested for success/failure outputs

## Anti-Patterns

- Supervisor embedding domain business logic
- Subagent directly exposing internal exceptions to protocol boundary
- Mixing protocol model and internal domain model in one package
- Routing based only on keyword contains without capability metadata
- No timeout/retry policy in inter-agent HTTP calls
- Subagent executing domain logic directly instead of invoking MCP functions
- Returning raw MCP/tool output without LLM-level response composition
- Using untyped maps or loosely structured JSON blobs where supervisor state, handoff metadata, or HITL decisions need a stable schema
- Treating handoff as unconditional routing instead of a policy-checked, feature-flagged operation
- Overwriting swarm state without version conflict handling
- Skipping A2UI preflight when the plan explicitly requires pre-HITL user input

## Reference Usage

- Read `references/a2a-sources.md` for source mapping and implementation checkpoints.
- Use runnable architecture samples under:
  `examples/latest-spec-spring/`
- Re-check local sample flow before large refactors:
  `/Users/dolpaks/Downloads/project/a2a-samples/samples/java/custom_java_impl/A2A_SUPERVISOR_SUBAGENT_SAMPLE.md`

## 파일 입력 유효성 체크

- 이 스킬의 현재 요청이 파일 입력 없이도 수행 가능한 범위라면, 파일 경로를 요구하지 말고 바로 작업을 진행합니다.
- 사용자가 문서/코드/계약서 본문을 메시지에 직접 제공한 경우에는 파일 경로 없이도 해당 텍스트로 작업을 진행합니다.
- 특정 파일의 실제 내용을 읽어야만 작업이 가능한 경우에만, **파일 경로 + 파일명** 제공 여부를 확인합니다.
- 파일 경로 또는 파일명이 누락된 경우에는 파일 작업을 진행하지 않고, 사용자에게 정확한 파일 경로와 파일명을 먼저 요청합니다.
- 경로가 모호한 표현(예: "그 파일", "지난번 문서")만 있는 경우에도 동일하게 명시 경로를 요청합니다.

