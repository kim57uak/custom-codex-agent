---
name: skill-installer
description: 큐레이션된 목록이나 GitHub repo 경로에서 Codex 스킬을 `$CODEX_HOME/skills`에 설치합니다. 사용자가 설치 가능한 스킬 목록 조회, 큐레이션된 스킬 설치, 다른 repo의 스킬 설치(비공개 repo 포함)를 요청할 때 사용합니다.
metadata:
  short-description: openai/skills 또는 다른 repo에서 큐레이션된 스킬 설치
---

# Skill 설치기

스킬 설치를 도와줍니다. 기본 대상은 `https://github.com/openai/skills/tree/main/skills/.curated`이며, 사용자가 다른 위치를 줄 수도 있습니다. 실험적 스킬은 `https://github.com/openai/skills/tree/main/skills/.experimental`에 있고 같은 방식으로 설치할 수 있습니다.

작업에 맞는 helper script를 사용합니다.
- 사용자가 무엇이 가능한지 묻거나, 이 스킬을 구체적 작업 없이 호출하면 스킬 목록을 보여 줍니다. 기본 목록은 `.curated`이지만, 실험 스킬을 물으면 `--path skills/.experimental`을 사용합니다.
- 사용자가 skill name을 주면 curated 목록에서 설치합니다.
- 사용자가 GitHub repo/path를 주면 다른 repo에서 설치합니다. 비공개 repo 포함

스킬 설치는 helper script로 수행합니다.

## 커뮤니케이션

스킬 목록을 보여 줄 때는 사용자 요청 맥락에 따라 대략 다음 형식으로 출력합니다. 실험 스킬을 물었다면 `.curated` 대신 `.experimental`에서 목록을 가져오고 출처를 명시합니다.
"""
Skills from {repo}:
1. skill-1
2. skill-2 (already installed)
3. ...
Which ones would you like installed?
"""

스킬을 설치한 뒤에는 사용자에게 다음 문구를 알려줍니다.
"Restart Codex to pick up new skills."

## 스크립트

이 스크립트들은 모두 네트워크를 사용하므로, sandbox에서 실행할 때는 escalation을 요청합니다.

- `scripts/list-skills.py` 설치 여부 주석과 함께 skill 목록 출력
- `scripts/list-skills.py --format json`
- 예시: `scripts/list-skills.py --path skills/.experimental`
- `scripts/install-skill-from-github.py --repo <owner>/<repo> --path <path/to/skill> [<path/to/skill> ...]`
- `scripts/install-skill-from-github.py --url https://github.com/<owner>/<repo>/tree/<ref>/<path>`
- 예시: `scripts/install-skill-from-github.py --repo openai/skills --path skills/.experimental/<skill-name>`

## 동작과 옵션

- 공개 GitHub repo에는 기본적으로 direct download를 사용합니다.
- 다운로드가 auth/permission 오류로 실패하면 git sparse checkout으로 fallback합니다.
- 대상 skill 디렉터리가 이미 존재하면 중단합니다.
- 설치 경로는 `$CODEX_HOME/skills/<skill-name>`입니다. 기본값은 `~/.codex/skills`
- 여러 `--path` 값을 주면 한 번에 여러 스킬을 설치하며, `--name`이 없으면 각 경로 basename으로 이름을 정합니다.
- 옵션: `--ref <ref>` 기본 `main`, `--dest <path>`, `--method auto|download|git`

## 참고

- curated listing은 GitHub API를 통해 `https://github.com/openai/skills/tree/main/skills/.curated`에서 가져옵니다. 사용 불가능하면 오류를 설명하고 종료합니다.
- 비공개 GitHub repo는 기존 git credential 또는 선택적 `GITHUB_TOKEN`/`GH_TOKEN`으로 다운로드할 수 있습니다.
- git fallback은 HTTPS를 먼저 시도하고 그다음 SSH를 시도합니다.
- `https://github.com/openai/skills/tree/main/skills/.system` 아래 스킬은 이미 사전 설치되어 있으므로, 기본적으로 사용자의 설치를 도울 필요가 없습니다. 요청 시 그 사실을 설명하고, 사용자가 강하게 원하면 다운로드 후 덮어쓸 수 있습니다.
- installed annotation은 `$CODEX_HOME/skills`를 기준으로 계산합니다.

## 파일 입력 유효성 체크

- 이 스킬의 현재 요청이 파일 입력 없이도 수행 가능한 범위라면, 파일 경로를 요구하지 말고 바로 작업을 진행합니다.
- 사용자가 문서/코드/계약서 본문을 메시지에 직접 제공한 경우에는 파일 경로 없이도 해당 텍스트로 작업을 진행합니다.
- 특정 파일의 실제 내용을 읽어야만 작업이 가능한 경우에만, **파일 경로 + 파일명** 제공 여부를 확인합니다.
- 파일 경로 또는 파일명이 누락된 경우에는 파일 작업을 진행하지 않고, 사용자에게 정확한 파일 경로와 파일명을 먼저 요청합니다.
- 경로가 모호한 표현(예: "그 파일", "지난번 문서")만 있는 경우에도 동일하게 명시 경로를 요청합니다.

