# Input Schema

`build_proposal_estimate.py --input` JSON example:

```json
{
  "client": "Acme Corp",
  "problem": "전환율 저하",
  "approach": "퍼널 분석 + 랜딩 개선",
  "timeline": "4주",
  "packages": [
    {"name": "Basic", "scope": "진단", "duration_weeks": 2, "price": 3000000, "notes": "1회"},
    {"name": "Standard", "scope": "진단+개선", "duration_weeks": 4, "price": 7000000, "notes": "권장"}
  ]
}
```
