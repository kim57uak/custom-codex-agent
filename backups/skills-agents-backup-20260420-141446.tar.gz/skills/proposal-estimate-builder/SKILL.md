---
name: "proposal-estimate-builder"
description: "고객 제안서와 견적서를 빠르게 작성하고 상업적으로 설득력 있는 구조로 정리할 때 사용합니다. 리드가 들어온 직후 범위, 일정, 비용, 옵션 패키지(Basic/Standard/Premium)를 정의하고 제안서 초안을 만들어야 할 때 트리거됩니다."
---

# Proposal Estimate Builder

## 운영 오너
- 영업팀

## 빠른 실행
- 입력 스키마: `references/input-schema.md`
- 실행:
```bash
python3 scripts/build_proposal_estimate.py \
  --input brief.json \
  --proposal-out proposal.md \
  --estimate-out estimate.csv
```

## 워크플로
1. `brief.json`에 고객 문제, 접근 방법, 패키지 옵션을 작성합니다.
2. 스크립트로 `proposal.md`와 `estimate.csv`를 생성합니다.
3. 금액, 범위, 일정 문구를 검수하고 제출 버전으로 확정합니다.

## 품질 기준
- 패키지별 범위/기간/가격이 모두 존재해야 합니다.
- 할인이나 예외 조건은 반드시 근거를 남깁니다.

## 파일 입력 처리
- 입력이 파일일 때는 먼저 `scripts/extract_text_from_file.py`로 텍스트를 추출합니다.
- 지원 형식: `txt,pdf,ppt,pptx,doc,docx,excel(xls/xlsx),md,html`
- 실행 예시:
```bash
python3 scripts/extract_text_from_file.py --input ./input/source.docx --output ./tmp/source.txt
```
- 추출 텍스트를 바탕으로 각 스킬의 본 스크립트(견적/정산/분류/분석)를 실행합니다.

## 파일 입력 유효성 체크

- 이 스킬의 현재 요청이 파일 입력 없이도 수행 가능한 범위라면, 파일 경로를 요구하지 말고 바로 작업을 진행합니다.
- 사용자가 문서/코드/계약서 본문을 메시지에 직접 제공한 경우에는 파일 경로 없이도 해당 텍스트로 작업을 진행합니다.
- 특정 파일의 실제 내용을 읽어야만 작업이 가능한 경우에만, **파일 경로 + 파일명** 제공 여부를 확인합니다.
- 파일 경로 또는 파일명이 누락된 경우에는 파일 작업을 진행하지 않고, 사용자에게 정확한 파일 경로와 파일명을 먼저 요청합니다.
- 경로가 모호한 표현(예: "그 파일", "지난번 문서")만 있는 경우에도 동일하게 명시 경로를 요청합니다.

