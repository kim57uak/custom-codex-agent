#!/bin/zsh
set -euo pipefail
DIR="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$DIR/output"
mkdir -p "$OUT"
python3 "$DIR/scripts/build_proposal_estimate.py" --input "$DIR/assets/sample_brief.json" --proposal-out "$OUT/proposal.md" --estimate-out "$OUT/estimate.csv"
echo "Generated: $OUT/proposal.md, $OUT/estimate.csv"
