#!/usr/bin/env python3
import argparse
import csv
import json
from pathlib import Path


def money(v: float) -> str:
    return f"{v:,.0f}"


def main() -> None:
    p = argparse.ArgumentParser(description="Build proposal markdown and estimate CSV from JSON brief")
    p.add_argument("--input", required=True, help="Input JSON path")
    p.add_argument("--proposal-out", default="proposal.md")
    p.add_argument("--estimate-out", default="estimate.csv")
    args = p.parse_args()

    data = json.loads(Path(args.input).read_text(encoding="utf-8"))
    client = data.get("client", "고객사")
    problem = data.get("problem", "해결 과제를 입력하세요")
    approach = data.get("approach", "접근 방법을 입력하세요")
    timeline = data.get("timeline", "일정을 입력하세요")
    packages = data.get("packages", [])

    lines = [
        f"# {client} 제안서",
        "",
        "## 1. 문제 정의",
        problem,
        "",
        "## 2. 해결 전략",
        approach,
        "",
        "## 3. 수행 일정",
        timeline,
        "",
        "## 4. 패키지 옵션",
    ]

    with open(args.estimate_out, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["package", "scope", "duration_weeks", "price", "notes"])
        for pkg in packages:
            name = pkg.get("name", "Standard")
            scope = pkg.get("scope", "")
            duration = pkg.get("duration_weeks", "")
            price = float(pkg.get("price", 0))
            notes = pkg.get("notes", "")
            writer.writerow([name, scope, duration, int(price), notes])
            lines.append(f"- **{name}**: {scope} / {duration}주 / {money(price)}원")

    lines += [
        "",
        "## 5. 상업 조건",
        "- 범위 외 요청은 변경 합의 후 별도 견적",
        "- 결제 조건과 착수 조건을 계약서에 명시",
        "",
        "## 6. 다음 액션",
        "- 패키지 선택 -> 세부 범위 확정 -> 계약 진행",
    ]

    Path(args.proposal_out).write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
