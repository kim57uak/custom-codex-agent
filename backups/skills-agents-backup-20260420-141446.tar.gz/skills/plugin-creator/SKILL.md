---
name: plugin-creator
description: Codex용 plugin 디렉터리를 생성하고 스캐폴딩합니다. 필수 `.codex-plugin/plugin.json`, 선택적 폴더/파일, 퍼블리시나 테스트 전 수정할 수 있는 기본 placeholder를 포함합니다. Codex가 새 로컬 plugin을 만들거나, 선택적 plugin 구조를 추가하거나, repo-root `.agents/plugins/marketplace.json`의 plugin 순서/가용성 메타데이터를 생성 또는 갱신해야 할 때 사용합니다.
---

# Plugin 생성기

## 빠른 시작

1. scaffold 스크립트를 실행합니다.

```bash
  # Plugin names are normalized to lower-case hyphen-case and must be <= 64 chars.
  # The generated folder and plugin.json name are always the same.
# Run from repo root (or replace .agents/... with the absolute path to this SKILL).
# By default creates in <repo_root>/plugins/<plugin-name>.
python3 .agents/skills/plugin-creator/scripts/create_basic_plugin.py <plugin-name>
```

2. `<plugin-path>/.codex-plugin/plugin.json`을 열고 `[TODO: ...]` placeholder를 채웁니다.

3. plugin이 Codex UI 정렬에 나타나야 하면 repo marketplace entry를 생성하거나 갱신합니다.

```bash
# marketplace.json always lives at <repo-root>/.agents/plugins/marketplace.json
python3 .agents/skills/plugin-creator/scripts/create_basic_plugin.py my-plugin --with-marketplace
```

홈 로컬 plugin이라면 `<home>`을 루트로 보고 다음처럼 사용합니다.

```bash
python3 .agents/skills/plugin-creator/scripts/create_basic_plugin.py my-plugin \
  --path ~/plugins \
  --marketplace-path ~/.agents/plugins/marketplace.json \
  --with-marketplace
```

4. 필요 시 선택적 companion 폴더를 추가 생성합니다.

```bash
python3 .agents/skills/plugin-creator/scripts/create_basic_plugin.py my-plugin --path <parent-plugin-directory> \
  --with-skills --with-hooks --with-scripts --with-assets --with-mcp --with-apps --with-marketplace
```

`<parent-plugin-directory>`는 `<plugin-name>` 폴더가 생성될 상위 디렉터리입니다. 예: `~/code/plugins`

## 이 스킬이 만드는 것

- 사용자가 plugin 위치를 명확히 하지 않았다면, marketplace entry를 생성하기 전에 repo-local plugin인지 home-local plugin인지 먼저 묻습니다.
- plugin root를 `/<parent-plugin-directory>/<plugin-name>/`에 생성합니다.
- 항상 `/<parent-plugin-directory>/<plugin-name>/.codex-plugin/plugin.json`을 생성합니다.
- manifest에는 전체 schema 형태, placeholder 값, 완전한 `interface` 섹션을 채웁니다.
- `--with-marketplace`가 지정되면 `<repo-root>/.agents/plugins/marketplace.json`을 생성 또는 갱신합니다.
  - marketplace 파일이 아직 없으면 첫 plugin entry를 넣기 전에 top-level `name`과 `interface.displayName` placeholder를 먼저 생성합니다.
- `<plugin-name>`은 skill-creator 네이밍 규칙으로 정규화됩니다.
  - `My Plugin` -> `my-plugin`
  - `My--Plugin` -> `my-plugin`
  - underscore, 공백, 문장부호는 `-`로 변환
  - 결과는 소문자 hyphen 구분이며 연속 hyphen은 축약
- 선택적으로 다음도 생성할 수 있습니다.
  - `skills/`
  - `hooks/`
  - `scripts/`
  - `assets/`
  - `.mcp.json`
  - `.app.json`

## Marketplace 워크플로

- `marketplace.json`은 항상 `<repo-root>/.agents/plugins/marketplace.json`에 있습니다.
- home-local plugin도 같은 규칙을 사용하며, `<home>`을 루트로 봅니다.
  `~/.agents/plugins/marketplace.json` + `./plugins/<plugin-name>`
- marketplace 루트 메타데이터는 top-level `name`과 선택적 `interface.displayName`을 지원합니다.
- `plugins[]` 순서는 Codex 렌더 순서로 취급합니다. 사용자가 재정렬을 명시하지 않는 한 새 entry는 append합니다.
- `displayName`은 개별 `plugins[]` entry가 아니라 marketplace `interface` 객체 안에 있어야 합니다.
- 생성되는 모든 marketplace entry에는 다음이 포함되어야 합니다.
  - `policy.installation`
  - `policy.authentication`
  - `category`
- 새 entry 기본값:
  - `policy.installation: "AVAILABLE"`
  - `policy.authentication: "ON_INSTALL"`
- 사용자가 허용된 다른 값을 명시했을 때만 기본값을 덮어씁니다.
- 허용되는 `policy.installation` 값:
  - `NOT_AVAILABLE`
  - `AVAILABLE`
  - `INSTALLED_BY_DEFAULT`
- 허용되는 `policy.authentication` 값:
  - `ON_INSTALL`
  - `ON_USE`
- `policy.products`는 override입니다. 사용자가 product gating을 명시적으로 요구하지 않는 한 생략합니다.
- 생성되는 plugin entry 형태:

```json
{
  "name": "plugin-name",
  "source": {
    "source": "local",
    "path": "./plugins/plugin-name"
  },
  "policy": {
    "installation": "AVAILABLE",
    "authentication": "ON_INSTALL"
  },
  "category": "Productivity"
}
```

- 동일한 plugin name의 기존 marketplace entry를 의도적으로 교체할 때만 `--force`를 사용합니다.
- `<repo-root>/.agents/plugins/marketplace.json`이 아직 없으면 top-level `"name"`, `"displayName"`이 들어 있는 `"interface"` 객체, `plugins` 배열을 생성한 뒤 새 entry를 추가합니다.

- 새 marketplace 파일의 루트 객체 예시는 다음과 같습니다.

```json
{
  "name": "[TODO: marketplace-name]",
  "interface": {
    "displayName": "[TODO: Marketplace Display Name]"
  },
  "plugins": [
    {
      "name": "plugin-name",
      "source": {
        "source": "local",
        "path": "./plugins/plugin-name"
      },
      "policy": {
        "installation": "AVAILABLE",
        "authentication": "ON_INSTALL"
      },
      "category": "Productivity"
    }
  ]
}
```

## 필수 동작

- 바깥 폴더명과 `plugin.json`의 `"name"`은 항상 같은 정규화된 plugin name이어야 합니다.
- 필수 구조를 제거하지 않습니다. `.codex-plugin/plugin.json`은 항상 존재해야 합니다.
- manifest 값은 사람이 직접 채우거나 후속 단계가 명시될 때까지 placeholder로 유지합니다.
- 기존 plugin path 내부에 파일을 만들 때는 overwrite 의도가 분명한 경우에만 `--force`를 사용합니다.
- 기존 marketplace `interface.displayName`은 보존합니다.
- marketplace entry를 생성할 때는 기본값이더라도 항상 `policy.installation`, `policy.authentication`, `category`를 기록합니다.
- `policy.products`는 사용자가 명시적으로 요청할 때만 추가합니다.
- marketplace `source.path`는 repo root 기준 `./plugins/<plugin-name>`을 유지합니다.

## 정확한 spec 샘플 참고

plugin manifest와 marketplace entry의 canonical sample JSON은 다음을 사용합니다.

- `references/plugin-json-spec.md`

## 검증

`SKILL.md`를 수정한 뒤 다음을 실행합니다.

```bash
python3 <path-to-skill-creator>/scripts/quick_validate.py .agents/skills/plugin-creator
```

## 파일 입력 유효성 체크

- 이 스킬의 현재 요청이 파일 입력 없이도 수행 가능한 범위라면, 파일 경로를 요구하지 말고 바로 작업을 진행합니다.
- 사용자가 문서/코드/계약서 본문을 메시지에 직접 제공한 경우에는 파일 경로 없이도 해당 텍스트로 작업을 진행합니다.
- 특정 파일의 실제 내용을 읽어야만 작업이 가능한 경우에만, **파일 경로 + 파일명** 제공 여부를 확인합니다.
- 파일 경로 또는 파일명이 누락된 경우에는 파일 작업을 진행하지 않고, 사용자에게 정확한 파일 경로와 파일명을 먼저 요청합니다.
- 경로가 모호한 표현(예: "그 파일", "지난번 문서")만 있는 경우에도 동일하게 명시 경로를 요청합니다.

