# Plugin JSON 샘플 스펙

```json
{
  "name": "plugin-name",
  "version": "1.2.0",
  "description": "Brief plugin description",
  "author": {
    "name": "Author Name",
    "email": "author@example.com",
    "url": "https://github.com/author"
  },
  "homepage": "https://docs.example.com/plugin",
  "repository": "https://github.com/author/plugin",
  "license": "MIT",
  "keywords": ["keyword1", "keyword2"],
  "skills": "./skills/",
  "hooks": "./hooks.json",
  "mcpServers": "./.mcp.json",
  "apps": "./.app.json",
  "interface": {
    "displayName": "Plugin Display Name",
    "shortDescription": "Short description for subtitle",
    "longDescription": "Long description for details page",
    "developerName": "OpenAI",
    "category": "Productivity",
    "capabilities": ["Interactive", "Write"],
    "websiteURL": "https://openai.com/",
    "privacyPolicyURL": "https://openai.com/policies/row-privacy-policy/",
    "termsOfServiceURL": "https://openai.com/policies/row-terms-of-use/",
    "defaultPrompt": [
      "Summarize my inbox and draft replies for me.",
      "Find open bugs and turn them into Linear tickets.",
      "Review today's meetings and flag scheduling gaps."
    ],
    "brandColor": "#3B82F6",
    "composerIcon": "./assets/icon.png",
    "logo": "./assets/logo.png",
    "screenshots": [
      "./assets/screenshot1.png",
      "./assets/screenshot2.png",
      "./assets/screenshot3.png"
    ]
  }
}
```

## 필드 가이드

### 최상위 필드

- `name` (`string`): Plugin 식별자. kebab-case, 공백 없음. `plugin.json`이 manifest로 제공될 때 필수이며 manifest 이름과 component namespace로 사용됩니다.
- `version` (`string`): Plugin semantic version.
- `description` (`string`): 짧은 목적 요약.
- `author` (`object`): 발행자 정보.
  - `name` (`string`): 작성자 또는 팀 이름
  - `email` (`string`): 연락용 이메일
  - `url` (`string`): 작성자/팀 홈페이지 또는 프로필 URL
- `homepage` (`string`): Plugin 사용 문서 URL
- `repository` (`string`): 소스 코드 URL
- `license` (`string`): 라이선스 식별자. 예: `MIT`, `Apache-2.0`
- `keywords` (`array` of `string`): 검색/탐색 태그
- `skills` (`string`): skill 디렉터리/파일의 상대 경로
- `hooks` (`string`): hook config 경로
- `mcpServers` (`string`): MCP config 경로
- `apps` (`string`): plugin integration용 app manifest 경로
- `interface` (`object`): plugin 표시를 위한 interface/UX 메타데이터 블록

### `interface` 필드

- `displayName` (`string`): 사용자에게 보이는 plugin 제목
- `shortDescription` (`string`): compact view에서 쓰는 짧은 부제
- `longDescription` (`string`): detail screen에서 쓰는 긴 설명
- `developerName` (`string`): 사람이 읽을 수 있는 발행자 이름
- `category` (`string`): plugin 분류 카테고리
- `capabilities` (`array` of `string`): 구현 기능 목록
- `websiteURL` (`string`): plugin 공개 웹사이트
- `privacyPolicyURL` (`string`): 개인정보 처리방침 URL
- `termsOfServiceURL` (`string`): 서비스 약관 URL
- `defaultPrompt` (`array` of `string`): composer/UX 문맥에서 보여 줄 starter prompt
  - 최대 3개 문자열만 포함합니다. 이후 항목은 무시됩니다.
  - 각 문자열은 최대 128자입니다. 더 길면 잘립니다.
  - UI에서 잘 읽히도록 50자 안팎의 짧은 starter prompt를 선호합니다.
- `brandColor` (`string`): plugin 카드용 theme color
- `composerIcon` (`string`): icon asset 경로
- `logo` (`string`): logo asset 경로
- `screenshots` (`array` of `string`): screenshot asset 경로 목록
  - screenshot 항목은 PNG 파일명이어야 하고 `./assets/` 아래에 있어야 합니다.
  - 파일 경로는 plugin root 기준 상대 경로로 유지합니다.

### 경로 규칙과 기본값

- 경로 값은 상대 경로여야 하며 `./`로 시작해야 합니다.
- `skills`, `hooks`, `mcpServers`는 기본 component discovery를 대체하는 것이 아니라 그 위에 보강됩니다.
- custom path 값은 plugin root 규칙과 naming/namespacing 규칙을 따라야 합니다.
- 이 저장소의 scaffold는 `.codex-plugin/plugin.json`을 생성하므로, 이 스킬이 만드는 manifest 위치는 그것으로 간주합니다.

# Marketplace JSON 샘플 스펙

`marketplace.json` 위치는 plugin이 어디에 놓일지에 따라 달라집니다.

- Repo plugin: `<repo-root>/.agents/plugins/marketplace.json`
- Local plugin: `~/.agents/plugins/marketplace.json`

```json
{
  "name": "openai-curated",
  "interface": {
    "displayName": "ChatGPT Official"
  },
  "plugins": [
    {
      "name": "linear",
      "source": {
        "source": "local",
        "path": "./plugins/linear"
      },
      "policy": {
        "installation": "AVAILABLE",
        "authentication": "ON_INSTALL"
      },
      "category": "Productivity"
    }
  ]
}
```

## Marketplace 필드 가이드

### 최상위 필드

- `name` (`string`): marketplace 식별자 또는 카탈로그 이름
- `interface` (`object`, optional): marketplace 표시 메타데이터
- `plugins` (`array`): 순서 있는 plugin entry 목록. 이 순서가 Codex 렌더 순서를 결정합니다.

### `interface` 필드

- `displayName` (`string`, optional): 사용자에게 보이는 marketplace 제목

### Plugin entry 필드

- `name` (`string`): Plugin 식별자. plugin 폴더명과 `plugin.json`의 `name`과 일치해야 합니다.
- `source` (`object`): Plugin source descriptor
  - `source` (`string`): 이 워크플로에서는 `local` 사용
  - `path` (`string`): marketplace root 기준 상대 plugin 경로
    - Repo plugin: `./plugins/<plugin-name>`
    - `~/.agents/plugins/marketplace.json`을 쓰는 local plugin도 `./plugins/<plugin-name>`
  - repo-rooted와 home-rooted marketplace 모두 동일한 상대 경로 규칙을 사용합니다.
    - 예: `~/.agents/plugins/marketplace.json`에서 `./plugins/<plugin-name>`은 `~/plugins/<plugin-name>`으로 해석됩니다.
- `policy` (`object`): marketplace policy 블록. 항상 포함합니다.
  - `installation` (`string`): 가용성 정책
    - 허용값: `NOT_AVAILABLE`, `AVAILABLE`, `INSTALLED_BY_DEFAULT`
    - 새 entry 기본값: `AVAILABLE`
  - `authentication` (`string`): 인증 시점 정책
    - 허용값: `ON_INSTALL`, `ON_USE`
    - 새 entry 기본값: `ON_INSTALL`
  - `products` (`array` of `string`, optional): 이 plugin entry의 product override. product gating을 명시적으로 요청하지 않으면 생략합니다.
- `category` (`string`): 표시용 카테고리. 항상 포함합니다.

### Marketplace 생성 규칙

- `displayName`은 개별 plugin entry가 아니라 top-level `interface` 객체 아래에 둡니다.
- 새 marketplace 파일을 처음 만들 때는 top-level `name`과 함께 `interface.displayName`도 초기화합니다.
- 생성 또는 갱신하는 모든 plugin entry에는 `policy.installation`, `policy.authentication`, `category`를 항상 포함합니다.
- `policy.products`는 override로 취급하며 명시적 요청이 없으면 생략합니다.
- 사용자가 재정렬을 요청하지 않는 한 새 entry는 append합니다.
- 같은 plugin의 기존 entry를 교체하는 것은 overwrite 의도가 분명할 때만 합니다.
- marketplace 위치는 plugin 대상 위치와 맞춰 선택합니다.
  - Repo plugin: `<repo-root>/.agents/plugins/marketplace.json`
  - Local plugin: `~/.agents/plugins/marketplace.json`
