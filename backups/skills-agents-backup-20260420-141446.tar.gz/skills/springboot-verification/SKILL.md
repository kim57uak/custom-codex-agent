---
name: springboot-verification
description: "Spring Boot 프로젝트용 검증 루프입니다. 릴리스 또는 PR 전에 build, static analysis, coverage 포함 테스트, security scan, diff review를 수행합니다."
origin: ECC
---

# Spring Boot 검증 루프

PR 전, 큰 변경 후, 배포 전에 실행합니다.

## 빌드 도구 정책

- 검증 명령은 프로젝트가 실제로 사용하는 빌드 도구로 실행합니다.
- wrapper가 둘 다 있으면 팀 문서의 기본 도구를 우선합니다.
- 불확실하면 다음 순서로 감지합니다.
  1. `./gradlew` 존재 -> Gradle wrapper 사용
  2. `./mvnw` 존재 -> Maven wrapper 사용
  3. 마지막으로 시스템 `gradle` 또는 `mvn` 사용

## 활성화 시점

- Spring Boot 서비스 PR을 열기 전
- 큰 리팩터링 또는 의존성 업그레이드 후
- staging 또는 production 배포 전 검증
- 전체 build -> lint -> test -> security scan 파이프라인 수행 시
- 테스트 coverage 임계치를 검증할 때

## 1단계: 빌드

```bash
# Maven
./mvnw -T 4 clean verify -DskipTests
# or (no wrapper)
mvn -T 4 clean verify -DskipTests

# Gradle
./gradlew clean assemble -x test
# or (no wrapper)
gradle clean assemble -x test
```

빌드가 실패하면 중단하고 먼저 수정합니다.

## 2단계: 정적 분석

Maven:
```bash
./mvnw -T 4 spotbugs:check pmd:check checkstyle:check
# or: mvn -T 4 spotbugs:check pmd:check checkstyle:check
```

Gradle:
```bash
./gradlew checkstyleMain pmdMain spotbugsMain
# or: gradle checkstyleMain pmdMain spotbugsMain
```

## 3단계: 테스트 + 커버리지

```bash
# Maven
./mvnw -T 4 test
./mvnw jacoco:report   # 80%+ coverage 확인
# or: mvn -T 4 test && mvn jacoco:report

# Gradle
./gradlew test jacocoTestReport
# or: gradle test jacocoTestReport
```

보고 항목:
- 전체 테스트 수, 성공/실패 수
- Coverage % (line/branch)

### 단위 테스트

mock dependency로 service logic을 고립해서 검증합니다.

```java
@ExtendWith(MockitoExtension.class)
class UserServiceTest {

  @Mock private UserRepository userRepository;
  @InjectMocks private UserService userService;

  @Test
  void createUser_validInput_returnsUser() {
    var dto = new CreateUserDto("Alice", "alice@example.com");
    var expected = new User(1L, "Alice", "alice@example.com");
    when(userRepository.save(any(User.class))).thenReturn(expected);

    var result = userService.create(dto);

    assertThat(result.name()).isEqualTo("Alice");
    verify(userRepository).save(any(User.class));
  }

  @Test
  void createUser_duplicateEmail_throwsException() {
    var dto = new CreateUserDto("Alice", "existing@example.com");
    when(userRepository.existsByEmail(dto.email())).thenReturn(true);

    assertThatThrownBy(() -> userService.create(dto))
        .isInstanceOf(DuplicateEmailException.class);
  }
}
```

### Testcontainers 기반 통합 테스트

H2 대신 실제 데이터베이스를 대상으로 테스트합니다.

```java
@SpringBootTest
@Testcontainers
class UserRepositoryIntegrationTest {

  @Container
  static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:16-alpine")
      .withDatabaseName("testdb");

  @DynamicPropertySource
  static void configureProperties(DynamicPropertyRegistry registry) {
    registry.add("spring.datasource.url", postgres::getJdbcUrl);
    registry.add("spring.datasource.username", postgres::getUsername);
    registry.add("spring.datasource.password", postgres::getPassword);
  }

  @Autowired private UserRepository userRepository;

  @Test
  void findByEmail_existingUser_returnsUser() {
    userRepository.save(new User("Alice", "alice@example.com"));

    var found = userRepository.findByEmail("alice@example.com");

    assertThat(found).isPresent();
    assertThat(found.get().getName()).isEqualTo("Alice");
  }
}
```

### MockMvc 기반 API 테스트

전체 Spring context를 사용해 controller layer를 검증합니다.

```java
@WebMvcTest(UserController.class)
class UserControllerTest {

  @Autowired private MockMvc mockMvc;
  @MockBean private UserService userService;

  @Test
  void createUser_validInput_returns201() throws Exception {
    var user = new UserDto(1L, "Alice", "alice@example.com");
    when(userService.create(any())).thenReturn(user);

    mockMvc.perform(post("/api/users")
            .contentType(MediaType.APPLICATION_JSON)
            .content("""
                {"name": "Alice", "email": "alice@example.com"}
                """))
        .andExpect(status().isCreated())
        .andExpect(jsonPath("$.name").value("Alice"));
  }

  @Test
  void createUser_invalidEmail_returns400() throws Exception {
    mockMvc.perform(post("/api/users")
            .contentType(MediaType.APPLICATION_JSON)
            .content("""
                {"name": "Alice", "email": "not-an-email"}
                """))
        .andExpect(status().isBadRequest());
  }
}
```

## 4단계: 보안 스캔

```bash
# Dependency CVEs
./mvnw org.owasp:dependency-check-maven:check
# or: mvn org.owasp:dependency-check-maven:check

# Gradle
./gradlew dependencyCheckAnalyze
# or: gradle dependencyCheckAnalyze

# Secrets in source
grep -rn "password\s*=\s*\"" src/ --include="*.java" --include="*.yml" --include="*.properties"
grep -rn "sk-\|api_key\|secret" src/ --include="*.java" --include="*.yml"

# Secrets (git history)
git secrets --scan  # if configured
```

### 흔한 보안 발견사항

```
# Check for System.out.println (use logger instead)
grep -rn "System\.out\.print" src/main/ --include="*.java"

# Check for raw exception messages in responses
grep -rn "e\.getMessage()" src/main/ --include="*.java"

# Check for wildcard CORS
grep -rn "allowedOrigins.*\*" src/main/ --include="*.java"
```

## 5단계: Lint/Format

```bash
# Maven
./mvnw spotless:apply   # if using Spotless plugin
# or: mvn spotless:apply

# Gradle
./gradlew spotlessApply
# or: gradle spotlessApply
```

## 6단계: Diff 리뷰

```bash
git diff --stat
git diff
```

체크리스트:
- 디버깅 로그가 남아 있지 않다. `System.out`, 가드 없는 `log.debug`
- 오류와 HTTP status가 의미 있다
- 필요한 곳에 transaction과 validation이 존재한다
- config 변경이 문서화되었다

## 출력 템플릿

```
VERIFICATION REPORT
===================
Build:     [PASS/FAIL]
Static:    [PASS/FAIL] (spotbugs/pmd/checkstyle)
Tests:     [PASS/FAIL] (X/Y passed, Z% coverage)
Security:  [PASS/FAIL] (CVE findings: N)
Diff:      [X files changed]

Overall:   [READY / NOT READY]

Issues to Fix:
1. ...
2. ...
```

## 연속 모드

- 큰 변경이 있을 때마다 또는 장시간 세션에서는 30~60분마다 단계를 다시 실행합니다
- 짧은 루프를 유지합니다
  - Maven: `./mvnw -T 4 test` + spotbugs
  - Gradle: `./gradlew test` + spotbugs task

**기억할 것**: 늦은 놀람보다 빠른 피드백이 낫습니다. 운영 시스템에서는 warning도 defect처럼 다룹니다.

## 파일 입력 유효성 체크

- 이 스킬의 현재 요청이 파일 입력 없이도 수행 가능한 범위라면, 파일 경로를 요구하지 말고 바로 작업을 진행합니다.
- 사용자가 문서/코드/계약서 본문을 메시지에 직접 제공한 경우에는 파일 경로 없이도 해당 텍스트로 작업을 진행합니다.
- 특정 파일의 실제 내용을 읽어야만 작업이 가능한 경우에만, **파일 경로 + 파일명** 제공 여부를 확인합니다.
- 파일 경로 또는 파일명이 누락된 경우에는 파일 작업을 진행하지 않고, 사용자에게 정확한 파일 경로와 파일명을 먼저 요청합니다.
- 경로가 모호한 표현(예: "그 파일", "지난번 문서")만 있는 경우에도 동일하게 명시 경로를 요청합니다.

