#!/bin/zsh
set -euo pipefail
DIR="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$DIR/output"
mkdir -p "$OUT"
python3 "$DIR/scripts/score_automation_backlog.py" --input "$DIR/assets/sample_automation_tasks.csv" --output "$OUT/automation_priority.csv"
echo "Generated: $OUT/automation_priority.csv"
