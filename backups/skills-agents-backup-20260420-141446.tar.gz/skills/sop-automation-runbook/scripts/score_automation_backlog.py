#!/usr/bin/env python3
import argparse
import csv
from pathlib import Path


def score(freq_per_week: float, mins_per_run: float, error_rate: float, complexity: float) -> float:
    return (freq_per_week * mins_per_run * (1 + error_rate)) / max(complexity, 1)


def main() -> None:
    p = argparse.ArgumentParser(description="Prioritize SOP automation candidates")
    p.add_argument("--input", required=True, help="CSV columns: task,freq_per_week,mins_per_run,error_rate,complexity")
    p.add_argument("--output", default="automation_priority.csv")
    args = p.parse_args()

    rows = list(csv.DictReader(Path(args.input).read_text(encoding="utf-8").splitlines()))
    scored = []
    for r in rows:
        s = score(float(r["freq_per_week"]), float(r["mins_per_run"]), float(r["error_rate"]), float(r["complexity"]))
        band = "High" if s >= 120 else "Medium" if s >= 50 else "Low"
        scored.append((s, band, r))

    scored.sort(key=lambda x: x[0], reverse=True)
    with open(args.output, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["task", "score", "priority", "freq_per_week", "mins_per_run", "error_rate", "complexity"])
        for s, band, r in scored:
            w.writerow([r["task"], round(s, 2), band, r["freq_per_week"], r["mins_per_run"], r["error_rate"], r["complexity"]])


if __name__ == "__main__":
    main()
