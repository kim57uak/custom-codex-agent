---
name: "sop-automation-runbook"
description: "반복 업무를 SOP로 표준화하고 자동화 후보를 발굴해 실행 순서를 설계할 때 사용합니다. 수동 루틴을 줄이고 운영 효율을 높이기 위한 업무 절차 문서화가 필요할 때 트리거됩니다."
---

# SOP Automation Runbook

## 운영 오너
- 개발팀

## 빠른 실행
- 입력 스키마: `references/backlog-schema.md`
- 실행:
```bash
python3 scripts/score_automation_backlog.py \
  --input automation_tasks.csv \
  --output automation_priority.csv
```

## 워크플로
1. 반복 업무를 CSV로 수집합니다.
2. 스크립트 점수로 자동화 우선순위를 산출합니다.
3. High 우선순위부터 SOP 상세화와 구현 계획을 작성합니다.

## 품질 기준
- 점수 산식 변경 시 이유를 기록합니다.
- High 후보에는 롤백 절차를 반드시 정의합니다.

## 파일 입력 처리
- 입력이 파일일 때는 먼저 `scripts/extract_text_from_file.py`로 텍스트를 추출합니다.
- 지원 형식: `txt,pdf,ppt,pptx,doc,docx,excel(xls/xlsx),md,html`
- 실행 예시:
```bash
python3 scripts/extract_text_from_file.py --input ./input/source.docx --output ./tmp/source.txt
```
- 추출 텍스트를 바탕으로 각 스킬의 본 스크립트(견적/정산/분류/분석)를 실행합니다.

## 파일 입력 유효성 체크

- 이 스킬의 현재 요청이 파일 입력 없이도 수행 가능한 범위라면, 파일 경로를 요구하지 말고 바로 작업을 진행합니다.
- 사용자가 문서/코드/계약서 본문을 메시지에 직접 제공한 경우에는 파일 경로 없이도 해당 텍스트로 작업을 진행합니다.
- 특정 파일의 실제 내용을 읽어야만 작업이 가능한 경우에만, **파일 경로 + 파일명** 제공 여부를 확인합니다.
- 파일 경로 또는 파일명이 누락된 경우에는 파일 작업을 진행하지 않고, 사용자에게 정확한 파일 경로와 파일명을 먼저 요청합니다.
- 경로가 모호한 표현(예: "그 파일", "지난번 문서")만 있는 경우에도 동일하게 명시 경로를 요청합니다.

