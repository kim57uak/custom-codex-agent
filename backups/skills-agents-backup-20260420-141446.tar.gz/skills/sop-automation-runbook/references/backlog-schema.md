# Automation Backlog CSV Schema

Required columns:
- `task`
- `freq_per_week`
- `mins_per_run`
- `error_rate` (0~1)
- `complexity` (1~5)
