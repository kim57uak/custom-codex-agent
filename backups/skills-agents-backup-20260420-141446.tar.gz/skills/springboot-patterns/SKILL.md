---
name: springboot-patterns
description: Spring Boot 아키텍처 패턴, REST API 설계, 계층형 서비스, 데이터 접근, 캐싱, 비동기 처리, 로깅을 다룹니다. Java Spring Boot 백엔드 작업에 사용합니다.
origin: ECC+custom
---

# Spring Boot 개발 패턴

확장 가능하고 운영 수준의 서비스를 위한 Spring Boot 아키텍처 및 API 패턴입니다.

빌드 도구 호환성:
- 이 스킬의 모든 패턴은 Maven과 Gradle 빌드 모두에 유효합니다.
- 문서와 CI에서는 wrapper 기반 실행 `./mvnw`, `./gradlew`를 선호합니다.

## 활성화 시점

- Spring MVC 또는 WebFlux로 REST API를 만들 때
- controller -> service -> repository 계층을 구성할 때
- Spring Data JPA, 캐싱, 비동기 처리를 설정할 때
- 검증, 예외 처리, 페이지네이션을 추가할 때
- dev/staging/production profile을 구성할 때
- Spring Events 또는 Kafka 기반 event-driven 패턴을 구현할 때

## 아키텍처 기본선

- controller는 얇고 stateless하게 유지합니다.
- 비즈니스 orchestration은 application service에 둡니다.
- domain logic은 framework concern과 분리합니다.
- 외부 의존성은 port/adapter 패턴을 사용합니다.

## 권장 디렉터리 구조

유지보수 가능한 서비스를 위한 기본 package layout으로 사용합니다.

```text
src/main/java/com/example/app/
  advice/            # 전역 예외 처리 (@RestControllerAdvice), API error mapping
  config/            # spring/security/jackson/openapi/cache/async 설정
  controller/        # REST controller (request binding, validation, response mapping)
  service/           # use-case/application service, transaction boundary
  proxy/             # 외부 API client/proxy (Feign/WebClient/RestClient adapter)
  dto/               # controller 경계의 request/response DTO
  model/             # service/domain-facing model/command/result (내부 DTO)
  repository/        # persistence port/adapter (Spring Data repository, query adapter)
  entity/            # JPA entity (JPA 사용 시)
  mapper/            # entity <-> model <-> dto 매핑
  security/          # authn/authz filter, token provider, security utility
  event/             # domain/integration event와 handler
  common/            # 범위가 명확한 shared constant/error/utility
src/main/resources/
  application.yml
  application-dev.yml
  application-staging.yml
  application-prod.yml
src/test/java/...     # main package 구조를 반영
```

규칙:
- `dto/`는 controller boundary contract 전용입니다.
- `model/`은 service-layer/internal data contract 전용입니다.
- `proxy/`는 외부 API 관심사가 controller/service로 누수되지 않도록 격리합니다.
- `advice/`는 전역 API 예외 변환의 단일 지점으로 유지합니다.
- 비즈니스 로직을 `controller`, `proxy`, `mapper`에 두지 않습니다.

## REST API 구조

```java
@RestController
@RequestMapping("/api/markets")
@Validated
class MarketController {
  private final MarketService marketService;

  MarketController(MarketService marketService) {
    this.marketService = marketService;
  }

  @GetMapping
  ResponseEntity<Page<MarketResponse>> list(
      @RequestParam(defaultValue = "0") int page,
      @RequestParam(defaultValue = "20") int size) {
    Page<Market> markets = marketService.list(PageRequest.of(page, size));
    return ResponseEntity.ok(markets.map(MarketResponse::from));
  }

  @PostMapping
  ResponseEntity<MarketResponse> create(@Valid @RequestBody CreateMarketRequest request) {
    Market market = marketService.create(request);
    return ResponseEntity.status(HttpStatus.CREATED).body(MarketResponse.from(market));
  }
}
```

규칙:
- entity 객체를 직접 반환하지 않습니다.
- 들어오는 payload는 모두 검증합니다.
- 필요할 때 API contract를 안정적이고 버전 가능하게 유지합니다.

## Repository 패턴

```java
public interface MarketRepository extends JpaRepository<MarketEntity, Long> {
  @Query("select m from MarketEntity m where m.status = :status order by m.volume desc")
  List<MarketEntity> findActive(@Param("status") MarketStatus status, Pageable pageable);
}
```

규칙:
- repository method는 도메인 관점으로 유지합니다.
- N+1과 fetch strategy를 명시적으로 검토합니다.

## 트랜잭션이 있는 서비스 계층

```java
@Service
public class MarketService {
  private final MarketRepository repo;

  public MarketService(MarketRepository repo) {
    this.repo = repo;
  }

  @Transactional
  public Market create(CreateMarketRequest request) {
    MarketEntity entity = MarketEntity.from(request);
    MarketEntity saved = repo.save(entity);
    return Market.from(saved);
  }
}
```

규칙:
- transaction boundary는 service method에 정의합니다.
- read path에는 `@Transactional(readOnly = true)`를 사용합니다.

## DTO와 검증

```java
public record CreateMarketRequest(
    @NotBlank @Size(max = 200) String name,
    @NotBlank @Size(max = 2000) String description,
    @NotNull @FutureOrPresent Instant endDate,
    @NotEmpty List<@NotBlank String> categories) {}

public record MarketResponse(Long id, String name, MarketStatus status) {
  static MarketResponse from(Market market) {
    return new MarketResponse(market.id(), market.name(), market.status());
  }
}
```

## 예외 처리

```java
@ControllerAdvice
class GlobalExceptionHandler {
  @ExceptionHandler(MethodArgumentNotValidException.class)
  ResponseEntity<ApiError> handleValidation(MethodArgumentNotValidException ex) {
    String message = ex.getBindingResult().getFieldErrors().stream()
        .map(e -> e.getField() + ": " + e.getDefaultMessage())
        .collect(Collectors.joining(", "));
    return ResponseEntity.badRequest().body(ApiError.validation(message));
  }

  @ExceptionHandler(AccessDeniedException.class)
  ResponseEntity<ApiError> handleAccessDenied() {
    return ResponseEntity.status(HttpStatus.FORBIDDEN).body(ApiError.of("Forbidden"));
  }

  @ExceptionHandler(Exception.class)
  ResponseEntity<ApiError> handleGeneric(Exception ex) {
    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
        .body(ApiError.of("Internal server error"));
  }
}
```

규칙:
- 일관된 error schema를 사용합니다. Boot 3+에서는 RFC 7807/ProblemDetail을 선호합니다.
- 예기치 않은 예외는 correlation context와 함께 로깅합니다.

## 캐싱

설정 클래스에 `@EnableCaching`이 필요합니다.

```java
@Service
public class MarketCacheService {
  private final MarketRepository repo;

  public MarketCacheService(MarketRepository repo) {
    this.repo = repo;
  }

  @Cacheable(value = "market", key = "#id")
  public Market getById(Long id) {
    return repo.findById(id)
        .map(Market::from)
        .orElseThrow(() -> new EntityNotFoundException("Market not found"));
  }

  @CacheEvict(value = "market", key = "#id")
  public void evict(Long id) {}
}
```

## 비동기 처리

설정 클래스에 `@EnableAsync`가 필요합니다.

```java
@Service
public class NotificationService {
  @Async
  public CompletableFuture<Void> sendAsync(Notification notification) {
    return CompletableFuture.completedFuture(null);
  }
}
```

규칙:
- async handler는 멱등적이고 observable해야 합니다.
- executor pool limit은 명시적으로 설정합니다.

## 로깅

```java
@Service
public class ReportService {
  private static final Logger log = LoggerFactory.getLogger(ReportService.class);

  public Report generate(Long marketId) {
    log.info("generate_report marketId={}", marketId);
    try {
      // logic
    } catch (Exception ex) {
      log.error("generate_report_failed marketId={}", marketId, ex);
      throw ex;
    }
    return new Report();
  }
}
```

## 미들웨어 / 필터

```java
@Component
public class RequestLoggingFilter extends OncePerRequestFilter {
  private static final Logger log = LoggerFactory.getLogger(RequestLoggingFilter.class);

  @Override
  protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
      FilterChain filterChain) throws ServletException, IOException {
    long start = System.currentTimeMillis();
    try {
      filterChain.doFilter(request, response);
    } finally {
      long duration = System.currentTimeMillis() - start;
      log.info("req method={} uri={} status={} durationMs={}",
          request.getMethod(), request.getRequestURI(), response.getStatus(), duration);
    }
  }
}
```

## 페이지네이션과 정렬

```java
PageRequest page = PageRequest.of(pageNumber, pageSize, Sort.by("createdAt").descending());
Page<Market> results = marketService.list(page);
```

## 오류에 강한 외부 호출

```java
public <T> T withRetry(Supplier<T> supplier, int maxRetries) {
  int attempts = 0;
  while (true) {
    try {
      return supplier.get();
    } catch (Exception ex) {
      attempts++;
      if (attempts >= maxRetries) {
        throw ex;
      }
      try {
        Thread.sleep((long) Math.pow(2, attempts) * 100L);
      } catch (InterruptedException ie) {
        Thread.currentThread().interrupt();
        throw ex;
      }
    }
  }
}
```

운영 환경에서는 retry, timeout, circuit breaker, bulkhead를 위해 Resilience4j를 선호합니다.

## Rate Limiting

신뢰된 forwarded-header 전략이 end-to-end로 구성되지 않았다면 `request.getRemoteAddr()`를 사용합니다.
프록시 보강 없이 `X-Forwarded-For`를 직접 신뢰하지 않습니다.

## 백그라운드 작업

`@Scheduled` 또는 queue 기반 worker(Kafka/SQS/RabbitMQ)를 사용합니다. job은 멱등적이고 observable해야 합니다.

## 관측 가능성

- Structured logging (JSON)
- Metrics: Micrometer + Prometheus/OTel
- Tracing: Micrometer Tracing + OpenTelemetry/Brave

## 운영 기본값

- constructor injection을 선호합니다
- Spring Boot 3+에서는 `spring.mvc.problemdetails.enabled=true`를 권장합니다
- workload에 맞게 HikariCP pool/timeouts를 조정합니다
- HTTP/database client에는 명시적 timeout 설정을 둡니다
- profile별 외부화된 config를 사용합니다. `application-dev.yml`, `application-prod.yml`

## 품질 게이트

1. API contract가 검증되고 문서화되었다
2. transaction과 멱등성 동작이 검증되었다
3. 테스트가 success/failure와 boundary path를 포함한다
4. incident triage를 위한 log/metric/trace가 충분하다

**기억할 것**: controller는 얇게, service는 집중되게, repository는 단순하게, 오류 처리는 중앙에서 관리합니다. 유지보수성과 테스트 가능성을 우선합니다.

## 파일 입력 유효성 체크

- 이 스킬의 현재 요청이 파일 입력 없이도 수행 가능한 범위라면, 파일 경로를 요구하지 말고 바로 작업을 진행합니다.
- 사용자가 문서/코드/계약서 본문을 메시지에 직접 제공한 경우에는 파일 경로 없이도 해당 텍스트로 작업을 진행합니다.
- 특정 파일의 실제 내용을 읽어야만 작업이 가능한 경우에만, **파일 경로 + 파일명** 제공 여부를 확인합니다.
- 파일 경로 또는 파일명이 누락된 경우에는 파일 작업을 진행하지 않고, 사용자에게 정확한 파일 경로와 파일명을 먼저 요청합니다.
- 경로가 모호한 표현(예: "그 파일", "지난번 문서")만 있는 경우에도 동일하게 명시 경로를 요청합니다.

