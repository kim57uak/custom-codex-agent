---
name: springboot-security
description: Java Spring Boot 서비스에서 authn/authz, validation, CSRF, secret, header, rate limiting, dependency security를 다루는 Spring Security 모범 사례입니다.
origin: ECC
---

# Spring Boot 보안 리뷰

인증을 추가하거나, 입력을 처리하거나, endpoint를 만들거나, secret을 다룰 때 사용합니다.

## 활성화 시점

- 인증 추가. JWT, OAuth2, 세션 기반
- 인가 구현. `@PreAuthorize`, role 기반 접근 제어
- 사용자 입력 검증. Bean Validation, custom validator
- CORS, CSRF, security header 설정
- secret 관리. Vault, environment variable
- rate limiting 또는 brute-force 보호 추가
- 의존성 CVE 스캔

## 인증

- revocation list가 있는 stateless JWT 또는 opaque token을 선호합니다
- 세션에는 `httpOnly`, `Secure`, `SameSite=Strict` cookie를 사용합니다
- token 검증은 `OncePerRequestFilter` 또는 resource server로 수행합니다

```java
@Component
public class JwtAuthFilter extends OncePerRequestFilter {
  private final JwtService jwtService;

  public JwtAuthFilter(JwtService jwtService) {
    this.jwtService = jwtService;
  }

  @Override
  protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
      FilterChain chain) throws ServletException, IOException {
    String header = request.getHeader(HttpHeaders.AUTHORIZATION);
    if (header != null && header.startsWith("Bearer ")) {
      String token = header.substring(7);
      Authentication auth = jwtService.authenticate(token);
      SecurityContextHolder.getContext().setAuthentication(auth);
    }
    chain.doFilter(request, response);
  }
}
```

## 인가

- 메서드 보안을 활성화합니다. `@EnableMethodSecurity`
- `@PreAuthorize("hasRole('ADMIN')")` 또는 `@PreAuthorize("@authz.canEdit(#id)")`를 사용합니다
- 기본 거부 정책을 유지하고 필요한 scope만 노출합니다

```java
@RestController
@RequestMapping("/api/admin")
public class AdminController {

  @PreAuthorize("hasRole('ADMIN')")
  @GetMapping("/users")
  public List<UserDto> listUsers() {
    return userService.findAll();
  }

  @PreAuthorize("@authz.isOwner(#id, authentication)")
  @DeleteMapping("/users/{id}")
  public ResponseEntity<Void> deleteUser(@PathVariable Long id) {
    userService.delete(id);
    return ResponseEntity.noContent().build();
  }
}
```

## 입력 검증

- controller에는 `@Valid`와 Bean Validation을 사용합니다
- DTO에 `@NotBlank`, `@Email`, `@Size` 같은 제약과 custom validator를 둡니다
- HTML은 렌더링 전에 allowlist 기반 sanitize를 수행합니다

```java
// BAD: No validation
@PostMapping("/users")
public User createUser(@RequestBody UserDto dto) {
  return userService.create(dto);
}

// GOOD: Validated DTO
public record CreateUserDto(
    @NotBlank @Size(max = 100) String name,
    @NotBlank @Email String email,
    @NotNull @Min(0) @Max(150) Integer age
) {}

@PostMapping("/users")
public ResponseEntity<UserDto> createUser(@Valid @RequestBody CreateUserDto dto) {
  return ResponseEntity.status(HttpStatus.CREATED)
      .body(userService.create(dto));
}
```

## SQL Injection 방지

- Spring Data repository 또는 parameterized query를 사용합니다
- native query에는 `:param` 바인딩을 사용하고 문자열 연결은 금지합니다

```java
// BAD: String concatenation in native query
@Query(value = "SELECT * FROM users WHERE name = '" + name + "'", nativeQuery = true)

// GOOD: Parameterized native query
@Query(value = "SELECT * FROM users WHERE name = :name", nativeQuery = true)
List<User> findByName(@Param("name") String name);

// GOOD: Spring Data derived query (auto-parameterized)
List<User> findByEmailAndActiveTrue(String email);
```

## 비밀번호 인코딩

- 비밀번호는 항상 BCrypt 또는 Argon2로 해시하고, 평문 저장은 금지합니다
- 수동 해시 대신 `PasswordEncoder` bean을 사용합니다

```java
@Bean
public PasswordEncoder passwordEncoder() {
  return new BCryptPasswordEncoder(12); // cost factor 12
}

// In service
public User register(CreateUserDto dto) {
  String hashedPassword = passwordEncoder.encode(dto.password());
  return userRepository.save(new User(dto.email(), hashedPassword));
}
```

## CSRF 보호

- 브라우저 세션 앱은 CSRF를 유지하고 token을 form/header에 포함합니다
- Bearer token 기반 순수 API는 CSRF를 비활성화하고 stateless auth에 의존합니다

```java
http
  .csrf(csrf -> csrf.disable())
  .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS));
```

## Secret 관리

- 소스에 secret을 두지 말고 env 또는 vault에서 읽습니다
- `application.yml`에는 자격 증명을 직접 넣지 말고 placeholder를 사용합니다
- token과 DB credential은 정기적으로 교체합니다

```yaml
# BAD: Hardcoded in application.yml
spring:
  datasource:
    password: mySecretPassword123

# GOOD: Environment variable placeholder
spring:
  datasource:
    password: ${DB_PASSWORD}

# GOOD: Spring Cloud Vault integration
spring:
  cloud:
    vault:
      uri: https://vault.example.com
      token: ${VAULT_TOKEN}
```

## 보안 헤더

```java
http
  .headers(headers -> headers
    .contentSecurityPolicy(csp -> csp
      .policyDirectives("default-src 'self'"))
    .frameOptions(HeadersConfigurer.FrameOptionsConfig::sameOrigin)
    .xssProtection(Customizer.withDefaults())
    .referrerPolicy(rp -> rp.policy(ReferrerPolicyHeaderWriter.ReferrerPolicy.NO_REFERRER)));
```

## CORS 설정

- controller별이 아니라 security filter 수준에서 CORS를 설정합니다
- 운영 환경에서는 절대 `*`를 허용 origin으로 쓰지 않습니다

```java
@Bean
public CorsConfigurationSource corsConfigurationSource() {
  CorsConfiguration config = new CorsConfiguration();
  config.setAllowedOrigins(List.of("https://app.example.com"));
  config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE"));
  config.setAllowedHeaders(List.of("Authorization", "Content-Type"));
  config.setAllowCredentials(true);
  config.setMaxAge(3600L);

  UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
  source.registerCorsConfiguration("/api/**", config);
  return source;
}

// In SecurityFilterChain:
http.cors(cors -> cors.configurationSource(corsConfigurationSource()));
```

## Rate Limiting

- 비용이 큰 endpoint에는 Bucket4j 또는 gateway 수준 제한을 둡니다
- burst는 로깅하고 alert를 걸며, 429와 retry hint를 반환합니다

```java
// Using Bucket4j for per-endpoint rate limiting
@Component
public class RateLimitFilter extends OncePerRequestFilter {
  private final Map<String, Bucket> buckets = new ConcurrentHashMap<>();

  private Bucket createBucket() {
    return Bucket.builder()
        .addLimit(Bandwidth.classic(100, Refill.intervally(100, Duration.ofMinutes(1))))
        .build();
  }

  @Override
  protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
      FilterChain chain) throws ServletException, IOException {
    String clientIp = request.getRemoteAddr();
    Bucket bucket = buckets.computeIfAbsent(clientIp, k -> createBucket());

    if (bucket.tryConsume(1)) {
      chain.doFilter(request, response);
    } else {
      response.setStatus(HttpStatus.TOO_MANY_REQUESTS.value());
      response.getWriter().write("{\"error\": \"Rate limit exceeded\"}");
    }
  }
}
```

## 의존성 보안

- CI에서 OWASP Dependency Check / Snyk를 실행합니다
- Spring Boot와 Spring Security는 지원 버전을 유지합니다
- 알려진 CVE가 있으면 빌드를 실패시킵니다

## 로깅과 PII

- secret, token, password, 전체 PAN 데이터는 절대 로그에 남기지 않습니다
- 민감 필드는 redaction하고 structured JSON logging을 사용합니다

## 파일 업로드

- 크기, content type, extension을 검증합니다
- 웹 루트 밖에 저장하고, 필요 시 스캔합니다

## 배포 전 체크리스트

- [ ] Auth token이 올바르게 검증되고 만료된다
- [ ] 모든 민감 경로에 authorization guard가 있다
- [ ] 모든 입력이 검증되고 sanitize된다
- [ ] 문자열 연결 SQL이 없다
- [ ] 앱 유형에 맞는 CSRF posture가 설정되었다
- [ ] Secret이 외부화되어 있고 커밋되지 않았다
- [ ] Security header가 설정되었다
- [ ] API에 rate limiting이 있다
- [ ] 의존성이 스캔되었고 최신 상태다
- [ ] 로그에 민감 데이터가 없다

**기억할 것**: 기본 거부, 입력 검증, 최소 권한, 그리고 secure-by-configuration을 우선합니다.

## 파일 입력 유효성 체크

- 이 스킬의 현재 요청이 파일 입력 없이도 수행 가능한 범위라면, 파일 경로를 요구하지 말고 바로 작업을 진행합니다.
- 사용자가 문서/코드/계약서 본문을 메시지에 직접 제공한 경우에는 파일 경로 없이도 해당 텍스트로 작업을 진행합니다.
- 특정 파일의 실제 내용을 읽어야만 작업이 가능한 경우에만, **파일 경로 + 파일명** 제공 여부를 확인합니다.
- 파일 경로 또는 파일명이 누락된 경우에는 파일 작업을 진행하지 않고, 사용자에게 정확한 파일 경로와 파일명을 먼저 요청합니다.
- 경로가 모호한 표현(예: "그 파일", "지난번 문서")만 있는 경우에도 동일하게 명시 경로를 요청합니다.

