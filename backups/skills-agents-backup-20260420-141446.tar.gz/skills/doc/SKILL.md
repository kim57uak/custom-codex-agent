---
name: "doc"
description: "작업이 `.docx` 문서의 읽기, 생성, 편집을 포함할 때 사용합니다. 특히 서식이나 레이아웃 충실도가 중요할 때는 `python-docx`와 번들된 `scripts/render_docx.py`로 시각 검토를 우선합니다."
---


# DOCX 스킬

## 사용 시점
- 레이아웃이 중요한 DOCX 내용(표, 다이어그램, 페이지 나눔)을 읽거나 검토할 때
- 전문적인 서식으로 DOCX 파일을 만들거나 편집할 때
- 전달 전에 시각적 레이아웃을 검증해야 할 때

## 워크플로
1. 먼저 시각 검토를 우선합니다. 레이아웃, 표, 다이어그램을 확인합니다.
   - `soffice`와 `pdftoppm`이 있으면 DOCX -> PDF -> PNG로 변환합니다.
   - 또는 `scripts/render_docx.py`를 사용합니다. `pdf2image`와 Poppler가 필요합니다.
   - 이런 도구가 없으면 설치하거나, 사용자가 로컬에서 렌더링된 페이지를 검토하도록 안내합니다.
2. 편집과 구조화된 문서 생성은 `python-docx`를 사용합니다. 제목, 스타일, 표, 목록 생성에 적합합니다.
3. 의미 있는 변경마다 다시 렌더링하고 페이지를 점검합니다.
4. 시각 검토가 불가능하면 차선책으로 `python-docx`로 텍스트를 추출하되, 레이아웃 리스크를 명시합니다.
5. 중간 산출물은 정리된 구조로 관리하고, 최종 승인 후 정리합니다.

## 임시 파일 및 출력 규칙
- 중간 파일은 `tmp/docs/`를 사용하고 완료 후 삭제합니다.
- 이 저장소에서 작업할 때 최종 산출물은 `output/doc/` 아래에 둡니다.
- 파일명은 안정적이고 설명적으로 유지합니다.

## 의존성
의존성 관리는 `uv`를 우선합니다.

Python 패키지:
```
uv pip install python-docx pdf2image
```
`uv`를 사용할 수 없으면:
```
python3 -m pip install python-docx pdf2image
```
시스템 도구:
```
# macOS (Homebrew)
brew install libreoffice poppler

# Ubuntu/Debian
sudo apt-get install -y libreoffice poppler-utils
```

이 환경에서 설치가 불가능하면, 어떤 의존성이 빠졌는지와 로컬 설치 방법을 사용자에게 알려줍니다.

## 환경 변수
필수 환경 변수는 없습니다.

## 렌더링 명령
DOCX -> PDF:
```
soffice -env:UserInstallation=file:///tmp/lo_profile_$$ --headless --convert-to pdf --outdir $OUTDIR $INPUT_DOCX
```

PDF -> PNG:
```
pdftoppm -png $OUTDIR/$BASENAME.pdf $OUTDIR/$BASENAME
```

번들 도우미:
```
python3 scripts/render_docx.py /path/to/file.docx --output_dir /tmp/docx_pages
```

## 품질 기대치
- 일관된 타이포그래피, 간격, 여백, 명확한 계층 구조를 갖춘 고객 전달 가능 문서를 만들어야 합니다.
- 잘린 텍스트, 겹치는 텍스트, 깨진 표, 읽기 어려운 문자, 기본 템플릿 스타일 같은 서식 결함을 남기지 않습니다.
- 차트, 표, 시각 요소는 렌더링된 페이지에서 올바르게 정렬되고 읽을 수 있어야 합니다.
- 하이픈은 ASCII만 사용합니다. U+2011 같은 non-breaking hyphen이나 다른 Unicode 대시는 피합니다.
- 인용과 참고 문헌은 사람이 읽을 수 있어야 하며, 툴 토큰이나 placeholder 문자열을 남기지 않습니다.

## 최종 점검
- 최종 전달 전에 모든 페이지를 100% 확대 기준으로 다시 렌더링하고 점검합니다.
- 간격, 정렬, 페이지 나눔 문제가 있으면 수정하고 다시 렌더링합니다.
- 사용자가 유지하길 원하지 않는 한, 임시 파일과 중복 렌더링 산출물은 남기지 않습니다.

## 파일 입력 유효성 체크

- 이 스킬의 현재 요청이 파일 입력 없이도 수행 가능한 범위라면, 파일 경로를 요구하지 말고 바로 작업을 진행합니다.
- 사용자가 문서/코드/계약서 본문을 메시지에 직접 제공한 경우에는 파일 경로 없이도 해당 텍스트로 작업을 진행합니다.
- 특정 파일의 실제 내용을 읽어야만 작업이 가능한 경우에만, **파일 경로 + 파일명** 제공 여부를 확인합니다.
- 파일 경로 또는 파일명이 누락된 경우에는 파일 작업을 진행하지 않고, 사용자에게 정확한 파일 경로와 파일명을 먼저 요청합니다.
- 경로가 모호한 표현(예: "그 파일", "지난번 문서")만 있는 경우에도 동일하게 명시 경로를 요청합니다.

