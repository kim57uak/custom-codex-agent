# 언어 선택

계획 문서를 바탕으로 어떤 언어나 스택으로 구현할지 결정할 때 이 참고 문서를 사용합니다.

## 결정 순서

1. 사용자의 명시적 지시
2. 계획 문서에 명시된 언어
3. 기존 저장소의 스택
4. 기술 아키텍처와 제품 형태를 바탕으로 한 추론

이미 확립된 저장소 스택을 가볍게 뒤집지 않습니다.

## 추론 힌트

### Spring Boot

계획 문서가 다음을 시사하면 우선 고려합니다.

- 엔터프라이즈 백엔드 서비스
- 계층형 비즈니스 로직
- 관계형 DB, 트랜잭션, 강한 도메인 모델링
- 내부 플랫폼 또는 관리자 워크플로
- Java/Spring 생태계 연동에 대한 명시적 필요

신호:

- Spring Boot, JPA, Maven, Gradle, JVM, enterprise service, layered architecture 기반 REST API 언급

### Java

다음과 같은 경우 순수 Java를 우선 고려합니다.

- 대상이 전체 Spring Boot 런타임이 필요 없는 라이브러리, 유틸리티, 배치, CLI, 또는 Java 애플리케이션인 경우

### Python

계획 문서가 다음을 시사하면 우선 고려합니다.

- 스크립트, 자동화, 데이터 처리, ML, AI orchestration, 또는 빠른 백엔드/서비스 작업
- notebook, ETL, LLM workflow, lightweight API에 대한 강한 필요

신호:

- FastAPI, Flask, pandas, celery, data pipeline, agent, crawler, automation 언급

### Node.js

계획 문서가 다음을 시사하면 우선 고려합니다.

- 이벤트 기반 백엔드
- JS 생태계 연동
- 실시간 서비스
- 프론트엔드/백엔드 간 JavaScript 관례 공유

신호:

- Express, NestJS, WebSocket, npm, package.json, TypeScript/JS 백엔드 관례 언급

### JavaScript

다음과 같은 경우 우선 고려합니다.

- 작업이 브라우저 측 로직인 경우
- 서버 중심 요구가 없는 단순 프론트엔드 또는 가벼운 앱인 경우

### React Native

계획 문서가 다음을 시사하면 우선 고려합니다.

- iOS와 Android를 동시에 대상으로 하는 크로스플랫폼 모바일 앱
- 공유 가능한 모바일 UI와 비즈니스 로직
- Expo, Metro, React Native CLI, 또는 모바일 중심 JavaScript/TypeScript 스택

신호:

- React Native, Expo, mobile app, App Store, Google Play, native module, navigation, gesture handling, device API 언급

### HTML/CSS/JS

다음과 같은 경우 우선 고려합니다.

- 요청 결과물이 정적 또는 거의 정적인 웹 페이지, 랜딩 페이지, 프로토타입, 또는 낮은 복잡도의 UI인 경우

## 혼합 대상

계획 문서가 프론트엔드와 백엔드를 모두 명확히 요구한다면:

- 저장소에 기존 분리가 있으면 그 구조를 따른다
- 그렇지 않으면 가장 가치 있는 실행 가능한 단위부터 시작한다
- 작동하는 핵심 경로를 만들기 전에 불필요한 서비스를 스캐폴딩하지 않는다

## 질문이 필요한 경우

다음과 같은 경우에는 추측하지 말고 질문합니다.

- 두 스택이 모두 그럴듯하며 프로젝트 형태가 크게 달라지는 경우
- 사용자가 배포/런타임 특성을 중요하게 여길 가능성이 있는 경우
- 계획 문서가 여러 스택 옵션을 허용하지만 선택하지 않은 경우
