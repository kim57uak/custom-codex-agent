#!/bin/zsh
set -euo pipefail
DIR="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$DIR/output"
mkdir -p "$OUT"
python3 "$DIR/scripts/triage_tickets.py" --input "$DIR/assets/sample_tickets.csv" --output "$OUT/ticket_triage.csv"
echo "Generated: $OUT/ticket_triage.csv"
