#!/usr/bin/env python3
import argparse
import csv
from pathlib import Path

RULES = {
    "payment": ["결제", "환불", "영수증", "카드"],
    "incident": ["오류", "장애", "접속", "안됨", "에러"],
    "usage": ["사용", "설정", "가이드", "방법"],
    "complaint": ["불만", "화남", "최악", "실망", "항의"],
}

SLA = {
    "payment": "4h",
    "incident": "1h",
    "usage": "24h",
    "complaint": "2h",
    "other": "24h",
}


def classify(text: str) -> str:
    t = text.lower()
    for tag, kws in RULES.items():
        if any(k in t for k in kws):
            return tag
    return "other"


def main() -> None:
    p = argparse.ArgumentParser(description="Classify support tickets and suggest SLA")
    p.add_argument("--input", required=True, help="CSV columns: ticket_id,customer,message")
    p.add_argument("--output", default="ticket_triage.csv")
    args = p.parse_args()

    rows = list(csv.DictReader(Path(args.input).read_text(encoding="utf-8").splitlines()))
    with open(args.output, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["ticket_id", "customer", "category", "sla", "response_template"])
        for r in rows:
            cat = classify(r.get("message", ""))
            template = f"공감 -> 사실확인 -> 해결단계 -> 후속안내 ({cat})"
            w.writerow([r.get("ticket_id", ""), r.get("customer", ""), cat, SLA[cat], template])


if __name__ == "__main__":
    main()
