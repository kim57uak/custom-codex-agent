# Ticket CSV Schema

Required columns:
- `ticket_id`
- `customer`
- `message`
