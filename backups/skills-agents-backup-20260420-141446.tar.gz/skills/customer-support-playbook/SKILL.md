---
name: "customer-support-playbook"
description: "고객 문의 응대 품질을 표준화하고 재현 가능한 대응 플레이북을 만들 때 사용합니다. 문의 분류, 우선순위, SLA, 답변 템플릿, 클레임 대응 문구를 정리하거나 개선해야 할 때 트리거됩니다."
---

# Customer Support Playbook

## 운영 오너
- 고객만족팀

## 빠른 실행
- 입력 스키마: `references/ticket-schema.md`
- 실행:
```bash
python3 scripts/triage_tickets.py \
  --input tickets.csv \
  --output ticket_triage.csv
```

## 워크플로
1. 수집된 문의를 `tickets.csv`로 정리합니다.
2. 스크립트로 카테고리/SLA/응답 템플릿을 자동 분류합니다.
3. 고우선순위(`incident`, `payment`, `complaint`)를 먼저 처리합니다.

## 품질 기준
- 같은 유형 문의는 같은 톤과 절차로 답변합니다.
- 최종 답변에는 해결 확인 문구를 포함합니다.

## 파일 입력 처리
- 입력이 파일일 때는 먼저 `scripts/extract_text_from_file.py`로 텍스트를 추출합니다.
- 지원 형식: `txt,pdf,ppt,pptx,doc,docx,excel(xls/xlsx),md,html`
- 실행 예시:
```bash
python3 scripts/extract_text_from_file.py --input ./input/source.docx --output ./tmp/source.txt
```
- 추출 텍스트를 바탕으로 각 스킬의 본 스크립트(견적/정산/분류/분석)를 실행합니다.

## 파일 입력 유효성 체크

- 이 스킬의 현재 요청이 파일 입력 없이도 수행 가능한 범위라면, 파일 경로를 요구하지 말고 바로 작업을 진행합니다.
- 사용자가 문서/코드/계약서 본문을 메시지에 직접 제공한 경우에는 파일 경로 없이도 해당 텍스트로 작업을 진행합니다.
- 특정 파일의 실제 내용을 읽어야만 작업이 가능한 경우에만, **파일 경로 + 파일명** 제공 여부를 확인합니다.
- 파일 경로 또는 파일명이 누락된 경우에는 파일 작업을 진행하지 않고, 사용자에게 정확한 파일 경로와 파일명을 먼저 요청합니다.
- 경로가 모호한 표현(예: "그 파일", "지난번 문서")만 있는 경우에도 동일하게 명시 경로를 요청합니다.

