# HTML 리뷰

HTML 템플릿 또는 정적 마크업에 사용합니다.

## 중점 영역

- 의미론적 구조
- 접근성
- 폼의 정확성
- 유지보수성
- 마크업이 JS 또는 템플릿과 상호작용할 때의 안전성

## HTML 리스크

- 의미론적 구조 대신 div soup
- form control에 대한 label 누락
- 깨진 heading hierarchy
- 필요한 곳의 alt text 누락
- 접근성 처리 없이 clickable한 non-button/non-link 요소
- 잘못된 nesting
- inline event handler
- 중복된 ID
- 템플릿화하거나 설정해야 할 하드코딩 문구, 링크, tracking ID, locale 특화 가정

## 리뷰 제안

- 의미 전달에 도움이 되는 곳에서는 semantic element를 사용합니다
- 폼은 `label`, validation 힌트, 올바른 button type을 갖춘 명시적 구조로 유지합니다
- ARIA는 의미론을 대체하는 용도가 아니라 보조하는 용도로 사용합니다
- 마크업 구조는 CSS/JS hook과 정렬하되, 표현과 의미론이 과도하게 결합되지 않게 합니다
- template/config 소스가 있는데도 재사용 가능한 문구나 환경별 URL을 정적 마크업 안에 박아 두지 않습니다
