# CSS 리뷰

CSS 및 스타일시트 코드를 다룰 때 사용합니다.

## 중점 영역

- selector의 명확성
- cascade 안전성
- spacing, color, typography 규칙의 유지보수성
- 반응형 동작
- 접근성 영향

## CSS 리스크

- 과도하게 구체적인 selector
- 깊은 descendant 체인
- 토큰과 magic value의 중복
- 구조적 문제를 숨기는 layout hack
- 의외의 파급 범위를 가지는 전역 reset 또는 override
- 과도한 `!important`
- 반응형 레이아웃을 깨뜨리는 고정 치수
- 색상 대비 리스크
- 공유 토큰 없이 반복되는 하드코딩 color, spacing, z-index, breakpoint

## 네이밍

프로젝트 관례와 정렬된, 명확하고 일관된 네이밍을 선호합니다.

- 컴포넌트 중심 이름
- modifier/state 이름
- 리디자인 후 오해를 부를 수 있는 표현 중심 이름은 피하기

## 리뷰 제안

- 프로젝트가 사용 중이라면 공유 토큰을 변수나 custom property로 추출합니다
- specificity를 낮춥니다
- 깨지기 쉬운 positioning hack보다 flex/grid 같은 레이아웃 시스템을 선호합니다
- focus state와 hover 전용 상호작용이 키보드 사용자 접근을 막지 않는지 확인합니다
- color, spacing, shadow, breakpoint 값을 리터럴로 흩뿌리지 말고 중앙화합니다
