# Spring Boot 리뷰

Java 코드가 명확히 Spring Boot 애플리케이션 일부일 때 사용합니다.

## 중점 영역

- controller, service, domain, repository, config 간 레이어 분리
- request 경계에서의 검증
- 트랜잭션 범위
- 설정 안전성
- 보안 기본값
- persistence 정확성
- 관측 가능성

## Controllers

다음을 리뷰합니다.

- 입력 검증 annotation 누락
- controller 내부의 도메인 로직
- 내부 예외 메시지 누출
- 일관되지 않은 HTTP status 매핑
- 약한 API 계약

얇은 controller와 명시적인 request/response DTO를 선호합니다.

## Services

다음을 리뷰합니다.

- 분해가 필요한데 orchestration과 domain logic가 섞인 경우
- 쓰기 일관성이 중요한데 `@Transactional`이 누락된 경우
- 원격 호출이나 비싼 loop까지 감싸는 `@Transactional`
- 재시도 가능 흐름에서 불명확한 멱등성

## Persistence

다음을 리뷰합니다.

- N+1 query 리스크
- lazy loading으로 인한 surprise
- API를 통한 entity 직접 노출
- 비즈니스 규칙에 필요한 unique constraint 또는 optimistic locking 누락
- 안전한 binding 없는 native query 구성
- Redis 또는 Spring Cache 사용 시 cache invalidation 공백

## 설정과 보안

다음을 점검합니다.

- `application.yml` 또는 properties에 포함된 secret
- wildcard CORS
- 맥락 없이 비활성화된 CSRF
- 지나치게 허용적인 security config
- 외부 호출에 대한 timeout 또는 retry 설정 누락
- 자격 증명이 직접 포함된 Redis 또는 datasource 설정

## 관측 가능성

권장:

- structured logging
- correlation ID
- 핵심 흐름에 대한 의미 있는 metric
- 로그에 PII나 secret이 남지 않도록 하기
