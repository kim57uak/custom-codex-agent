# Python 리뷰

Python 애플리케이션, 스크립트, 서비스, 데이터 처리 코드에 사용합니다.

## 중점 영역

- 가독성과 명시성
- 모듈 및 함수 책임
- 오류 처리
- 프로젝트가 사용하는 경우 typing 규율
- 데이터 가변성과 기본 인자 안전성
- 패키지 경계

## 네이밍과 스타일

- modules/functions/variables: snake_case
- classes: PascalCase
- constants: UPPER_SNAKE_CASE
- boolean은 `is_ready`, `has_access`처럼 predicate로 읽혀야 함
- 자유로운 문자열 대신 닫힌 상태나 명령 집합에는 `Enum` 사용

지적할 항목:

- 매우 작은 범위를 제외한 불명확한 짧은 이름
- 혼동을 주는 singular/plural 불일치
- 유틸리티 덤핑 공간
- 모듈 전반에 흩어진 magic string 또는 숫자 임계값

## Python 특화 리스크

- mutable default argument
- bare `except:`
- 경계 이유 없이 넓게 잡는 `except Exception`
- 숨겨진 전역 상태
- dataclass나 typed model이 더 명확한데도 dict 중심으로 동작하는 구조
- comprehension 안의 과도한 부작용
- async 코드 안의 동기 blocking I/O
- await 없이 호출되는 async 함수
- raw SQL 문자열 구성 또는 안전하지 않은 Redis key/value 패턴

## 데이터와 계약

- shape가 중요하면 dataclass, pydantic model, typed object를 선호합니다
- 외부 입력은 초기에 검증합니다
- 파일, DB connection, network resource에는 context manager를 사용합니다

## 유지보수성

다음을 찾습니다.

- parsing, transformation, I/O를 한 함수에서 모두 처리하는 긴 함수
- 중복된 분기 규칙
- 구조화되지 않은 config 접근
- kwargs나 dict contract에 과도하게 의존하는 암묵적 동작

## 권장 개선 방향

- I/O와 순수 로직 분리
- 모호성이 리스크를 만들면 type hint 추가
- 중첩 dict 접근을 typed model로 대체
- 도메인 용어와 magic string을 상수로 추출
- 환경별 값을 settings/config 객체로 이동
