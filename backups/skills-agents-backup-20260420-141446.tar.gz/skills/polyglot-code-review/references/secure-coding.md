# 보안 코딩 리뷰

언어와 무관하게 모든 리뷰에 이 참고 문서를 적용합니다.

## 우선 점검 영역

항상 다음을 확인합니다.

- 입력 검증
- 적용 가능한 경우 출력 인코딩 또는 escaping
- 인증 및 인가 경계
- secret 처리
- injection 리스크
- 안전하지 않은 역직렬화
- 민감한 로깅
- 안전하지 않은 파일, 프로세스, 네트워크 접근
- 공개 endpoint에 대한 rate limiting 또는 abuse 제어

## 입력 검증

신뢰할 수 없는 입력이 경계에서 검증되는지 리뷰합니다.

- HTTP request body, query param, header
- CLI argument
- 파일 내용과 파일명
- queue 또는 event payload
- environment variable과 config

권장:

- schema validation
- 명시적인 길이 및 범위 검사
- enum, identifier, sort field에 대한 allowlist

지적할 항목:

- raw user input을 그대로 신뢰하는 경우
- 도메인 제약 없이 regex만으로 끝나는 검증
- 입력을 SQL, shell, HTML, file path, template rendering에 직접 사용하는 경우

## 인증과 인가

다음을 분리해서 확인합니다.

- authentication: 호출자가 누구인가
- authorization: 호출자가 무엇을 할 수 있는가

지적할 항목:

- UI 레벨에서만 보호된 endpoint
- 민감 작업에 대한 role 검사 누락
- object-level access check 누락
- multi-tenant 경계 누수

## Secret 및 자격 증명

절대 허용하지 않습니다.

- 코드에 포함된 secret
- 하드코딩된 API key
- 평문 비밀번호
- token, cookie, header, 자격 증명이 들어간 connection string을 그대로 로깅하는 행위

권장:

- environment variable
- secret manager
- short-lived credential
- 로그와 오류에서의 redaction

## Injection 리스크

항상 다음을 살핍니다.

- SQL 또는 ORM query concatenation
- shell command concatenation
- template injection
- HTML injection
- dynamic code execution

권장:

- parameterized query
- shell string 대신 command argument array
- 기본적으로 escaping이 적용되는 template

## 파일 및 경로 안전성

다음을 리뷰합니다.

- path traversal
- 파일 확장자만 신뢰하는 로직
- 안전하지 않은 temp file 처리
- 제어 없이 웹 접근 가능한 경로에 직접 저장하는 경우

## 직렬화와 파싱

지적할 항목:

- 안전하지 않은 객체 역직렬화
- 제어 없는 permissive polymorphic deserialization
- 제한 없이 신뢰할 수 없는 콘텐츠를 풍부한 object graph로 파싱하는 경우

권장:

- 엄격한 스키마
- 제한된 payload 크기
- 명시적인 허용 타입

## 로깅과 오류 처리

권장:

- structured log
- 민감 필드 redaction
- 외부에는 일반화된 오류 메시지, 내부에는 상세 로그

지적할 항목:

- 사용자에게 raw stack trace 노출
- secret 또는 PII 로깅
- 기본적으로 전체 request payload를 기록하는 행위

## 세션, 토큰, 쿠키 안전성

다음을 점검합니다.

- 관련될 경우 cookie의 `httpOnly`, `Secure`, `SameSite`
- token 만료 및 폐기 전략
- refresh token 처리
- 민감한 브라우저 token을 insecure local storage에 저장하는 경우
