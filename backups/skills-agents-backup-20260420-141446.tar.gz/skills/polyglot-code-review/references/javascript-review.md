# JavaScript 리뷰

주로 Node.js 서버 코드가 아닌 브라우저 측 또는 일반 JavaScript에 사용합니다.

## 중점 영역

- 상태 변화의 명확성
- DOM 안전성
- 이벤트 생명주기의 정확성
- 모듈 경계
- 네이밍과 유지보수성

## JavaScript 리스크

- 암묵적 전역 변수
- 깨지기 쉬운 truthy/falsy 로직
- 변이가 많은 공유 상태
- stale closure 또는 event handler
- 중복된 DOM selector와 명령형 spaghetti 코드
- 안전하지 않은 `innerHTML` 사용
- timer, listener, subscription 정리 누락
- event name, CSS selector, storage key, message type에 대한 반복 문자열 리터럴

## 네이밍과 구조

- functions and variables: camelCase
- constructors/classes: PascalCase
- constants: 진짜 상수일 때 UPPER_SNAKE_CASE

권장:

- 가능하면 pure helper 사용
- 소유권이 분명한 작은 모듈
- rendering, state, I/O 사이의 명시적 경계
- 재사용되는 selector, event name, storage key는 이름 있는 상수로 추출
