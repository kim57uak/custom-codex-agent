# React Native 리뷰

React Native CLI 또는 Expo 기반 React Native 앱, 공유 모바일 UI 코드, 플랫폼별 모바일 로직에 사용합니다.

## 중점 영역

- 컴포넌트 구조와 렌더링 경계
- 상태 흐름과 부작용의 정확성
- 모바일 navigation 및 screen 생명주기 동작
- 플랫폼별 분기와 native module 사용
- 반복 re-render 또는 list-heavy 화면에서의 성능
- 접근성, 터치 타깃, 기기 안전 레이아웃
- 공유 파일과 플랫폼별 파일 전반의 유지보수성

## React Native 리스크

- hook, handler, timer 안의 stale closure
- 피할 수 있는 re-render를 유발하는 반복 inline function 또는 object
- 안전하지 않은 `useEffect` dependency 또는 cleanup 누락
- 화면 로컬 관심사에 대한 과도한 global state 사용
- 작은 화면이나 큰 화면에서 깨지는 하드코딩 치수
- safe area, keyboard avoidance, orientation change를 무시하는 레이아웃
- 명확한 추상화 없이 반복되는 platform check
- fallback이나 capability check 없는 직접 native API 접근
- 누락된 accessibility label, role, 또는 부족한 touch target 크기
- virtualization 또는 memoized row 경계 없는 대형 리스트

## 네이밍과 구조

- components and screens: PascalCase
- hooks: 설명적인 이름과 `use` 접두사
- helpers and handlers: camelCase
- constants: 진짜 상수일 때 `UPPER_SNAKE_CASE`

권장:

- 명시적 props를 가진 작은 presentational component
- 로컬 UI 관심사는 local state로 유지
- 의미 있게 동작이 갈릴 때는 platform-specific module로 분리
- size, route, storage key, event name은 재사용 시 이름 있는 상수로 추출
- subscription, permission, lifecycle cleanup에 집중된 hook 사용

## 리뷰 체크

- hook dependency와 cleanup 경로를 확인합니다
- 모바일 레이아웃에서 safe area, keyboard, scrolling 동작을 점검합니다
- interactive element에 대해 accessibility label과 pressable semantics를 검증합니다
- hot render path에서 불필요한 object/function 재생성을 찾습니다
- platform-specific 코드가 잘 격리되어 트리 전반으로 분기 복잡도를 누수시키지 않는지 확인합니다
- list rendering의 key 안정성과 virtualization을 리뷰합니다
- permission, native module call, offline/degraded state에 대한 오류 처리를 검증합니다
