# Node.js 리뷰

JavaScript가 Node.js 환경에서 서버 측으로 실행될 때 사용합니다.

## 중점 영역

- async 정확성
- request 생명주기 안전성
- 검증과 인가
- 모듈 경계
- 설정과 secret 처리
- 운영 안정성
- 상수 및 config 소유권

## Node 특화 리스크

- 처리되지 않은 promise rejection
- 누락된 `await`
- callback과 promise 스타일 혼용
- 무거운 sync 작업으로 event loop를 막는 경우
- 너무 많은 일을 하는 request handler
- 외부 I/O에 대한 timeout, retry, cancellation 처리 누락
- 검증 없이 `req.body`, `req.query`, header를 신뢰하는 경우
- SQL 문자열 연결, 안전하지 않은 ORM raw query, 또는 Redis 오용
- handler 곳곳에 흩어진 하드코딩 route fragment, status 문자열, retry 횟수, cache key

## 네이밍과 구조

- 파일/모듈은 책임을 반영해야 합니다
- 작은 route handler가 service에 위임하는 구조를 선호합니다
- 거대한 `utils.js` 또는 `helpers.js`는 피합니다
- 반복 문자열은 흩뿌리지 말고 이름 있는 상수나 config module로 추출합니다

## 오류 처리

- 오류는 일관된 middleware 경계를 통해 전파되어야 합니다
- 중앙화된 middleware가 있다면 모든 handler에 중복된 try/catch를 두지 않습니다
- raw stack trace나 내부 오류를 그대로 클라이언트에 노출하지 않습니다

## 보안과 운영

다음을 점검합니다.

- shell, SQL, template에 대한 직접 문자열 보간
- 지나치게 허용적인 CORS
- 누락된 authz 검사
- 코드나 config 속 secret
- 공개 endpoint에 대한 부족한 rate limiting
- 약한 logging context
- 런타임 코드에 직접 박힌 환경별 값
