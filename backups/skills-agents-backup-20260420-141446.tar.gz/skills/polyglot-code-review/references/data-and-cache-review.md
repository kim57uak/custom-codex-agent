# 데이터 및 캐시 리뷰

코드가 database, ORM, query builder, Redis, cache abstraction, distributed lock, dedup 상태를 가진 queue, 또는 어떤 형태로든 persistence 경로를 다룰 때 이 참고 문서를 사용합니다.

## 데이터베이스 리뷰

### 쿼리 구성

권장:

- parameterized query
- prepared statement
- ORM query binding
- 쿼리 안전성을 유지하는 repository 메서드

지적할 항목:

- SQL 문자열 연결
- allowlist 없이 사용자 입력으로 `ORDER BY`, 테이블명, 컬럼명을 동적으로 구성하는 경우
- 요청값으로 raw query fragment를 이어 붙이는 경우

### 트랜잭션

다음을 리뷰합니다.

- 여러 단계의 쓰기 작업에 트랜잭션 경계가 없는 경우
- 느린 외부 네트워크 호출까지 감싸는 트랜잭션
- read-modify-write race
- 보상 또는 재시도 설계 없는 partial update

권장:

- 짧은 트랜잭션
- 서비스/애플리케이션 레이어에서 명시적인 트랜잭션 경계
- 재시도가 발생할 수 있는 경우 멱등적인 쓰기 설계

### 데이터 무결성

다음을 점검합니다.

- 유일성이 애플리케이션 로직에서만 보장되는 경우
- 동시 수정이 중요한데 optimistic locking이 없는 경우
- foreign key 또는 일관성 가정이 빠진 경우
- 불변 조건을 약하게 만드는 nullable 컬럼 또는 optional 필드

권장:

- 중요한 불변 조건은 database constraint로 강제
- 애플리케이션 검증과 데이터베이스 강제를 함께 사용

### 페이지네이션과 필터링

권장:

- 제한된 페이지 크기
- 안정적인 정렬 순서
- allowlist 기반 정렬 필드

지적할 항목:

- 제한 없는 조회
- 검증 없는 사용자 주도 동적 필터
- 매우 큰 데이터셋에서 안정성이 떨어지는 offset 기반 단독 페이징

### 민감 데이터

다음을 점검합니다.

- DB에 평문으로 저장된 secret 또는 token
- 필요한 곳에서 field encryption이 누락된 경우
- 민감 컬럼을 불필요하게 함께 가져오는 과도한 select

## Redis 및 캐시 리뷰

### 키 설계

다음 특성을 가진 키를 선호합니다.

- namespaced
- deterministic
- 필요할 경우 tenant, user, environment 범위가 반영됨
- 디버깅 가능한 수준의 가독성

예시:

- `session:{tenantId}:{sessionId}`
- `product:{productId}:summary`
- `rate_limit:{userId}:{minuteBucket}`

지적할 항목:

- 모호하거나 충돌 가능한 키
- tenant 경계가 빠진 키
- 정규화 없이 raw user input을 cache key로 사용하는 경우

### TTL과 무효화

다음을 리뷰합니다.

- 임시 데이터에 TTL이 없는 경우
- 가변 데이터에 대한 invalidation 전략이 없는 경우
- source of truth보다 오래 살아남을 수 있는 cache entry
- 명시적 정책 없이 쓰기 후 stale read가 발생하는 경우

권장:

- 비즈니스 신선도 기준의 명시적 TTL
- write-through, write-behind, cache-aside 중 의도적인 선택
- 변경 경로와 연결된 invalidation

### 직렬화

권장:

- 안정적이고 명시적인 직렬화 형식
- 스키마가 진화할 때를 고려한 version-aware 캐시 payload
- 불투명하고 위험한 직렬화보다 단순 JSON 또는 간결한 타입

지적할 항목:

- 호환성 또는 보안 리스크가 있는 언어 네이티브 객체 직렬화
- 안전한 스키마 진화를 견딜 수 없는 캐시 구조

### 락과 동시성

Redis를 락에 사용한다면:

- lock key 범위가 명확한지 확인
- 락에 TTL을 반드시 둠
- unlock 전에 ownership token/value를 반드시 검증
- atomic 대안이 있는데도 순진한 `SETNX` + 별도 `EXPIRE`에 의존하지 않음

지적할 항목:

- 소유권 검증 없는 unlock
- 무기한 락
- 잘못된 트랜잭션 설계의 대체물로 락을 사용하는 경우

### 카운터와 rate limiting

권장:

- atomic increment 패턴
- rolling window에 맞는 제한된 TTL
- hot key에 대한 명시적 처리

지적할 항목:

- race가 나는 multi-command counter 로직
- 윈도우 의미가 필요한데도 expiry가 없는 counter

## DB와 캐시의 일관성

다음을 리뷰합니다.

- DB는 갱신됐지만 캐시는 무효화되지 않은 경우
- DB commit 전에 캐시를 먼저 갱신한 경우
- stale read window를 인지하지 않은 경우
- 재시도 흐름이 쓰기를 중복시키지만 캐시 상태를 조정하지 않는 경우

권장:

- 명확한 source of truth
- 명시적인 read-after-write 전략
- 외부 재시도가 가능한 write 작업을 위한 idempotency key

## 던져볼 가치가 있는 리뷰 질문

- source of truth는 DB인가, cache인가?
- 여기서 stale data는 허용되는가? 허용된다면 얼마나 오랫동안인가?
- 어떤 동시성 패턴을 가정하고 있는가?
- 유일성 또는 소유권은 무엇이 강제하는가?
- Redis가 불가능할 때는 어떻게 되는가?
