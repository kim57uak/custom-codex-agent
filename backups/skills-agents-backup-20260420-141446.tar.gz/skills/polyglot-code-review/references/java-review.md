# Java 리뷰

Java 코드를 다룰 때 사용하며, Spring Boot가 감지되면 `springboot-review.md`와 함께 적용합니다.

## 중점 영역

- 명확한 package 및 layer 경계
- 기본적으로 불변성 지향
- null 안정성과 Optional 규율
- 예외 분류 체계
- collection 안전성과 defensive copy
- 트랜잭션 및 동시성 인식
- primitive obsession 대신 의미 있는 타입 모델링
- repository 및 persistence 안전성

## 네이밍과 구조

- classes, interfaces, records: PascalCase
- methods, fields, locals: camelCase
- constants: UPPER_SNAKE_CASE
- 흩어진 문자열 리터럴이나 boolean 조합 대신 닫힌 도메인 상태에는 enum 사용
- `Helper`, `Manager`, `CommonUtil` 같은 모호한 타입명은 피함

클래스당 하나의 명확한 책임을 선호합니다.

지적할 항목:

- god service
- DTO/entity/domain 누수
- static mutable state
- 긴 parameter 목록
- 안전한 바인딩 검토 없는 ad hoc JDBC 또는 native SQL
- status, role, event type, cache key에 대한 반복 문자열 리터럴
- 상수나 config 대신 서비스 로직 안에 박힌 숫자 임계값

## Java 특화 냄새

- field 또는 parameter로 사용되는 `Optional`
- 가드 없이 사용하는 `Optional.get()`
- raw type
- checked exception 삼키기
- 광범위한 `catch (Exception e)`
- mutable collection 노출
- loop보다 가독성이 떨어지는 stream pipeline
- controller 또는 repository 레이어에 숨겨진 비즈니스 로직

## Null 및 Collection 규칙

- `null`보다 빈 collection을 선호합니다
- 경계에서 입력을 검증합니다
- primitive가 도메인 의도를 숨기면 value object를 사용합니다
- 소유권이 중요하면 외부에서 전달된 collection을 복사합니다

## 예외

- 구체적인 예외 타입을 사용합니다
- 예외를 감쌀 때는 맥락을 보존합니다
- stack trace를 잃지 않습니다
- 도메인 실패와 인프라 실패를 구분해 매핑합니다

## 동시성과 트랜잭션

- 안전하지 않은 공유 가변 상태가 있는지 확인합니다
- 트랜잭션 경계가 임의의 helper가 아니라 application/service 메서드에 있는지 검증합니다
- 정당한 이유가 없다면 느린 원격 호출까지 트랜잭션 범위를 넓히지 않습니다

## 권장 개선 방향

자주 유효한 제안:

- 큰 서비스를 유스케이스 단위로 분리
- value object 추출
- boolean flag를 enum 또는 strategy 타입으로 대체
- 적절한 경우 mutable한 DTO 스타일 모델을 record로 전환
- 반복 리터럴을 상수, enum, 또는 `@ConfigurationProperties`로 승격
