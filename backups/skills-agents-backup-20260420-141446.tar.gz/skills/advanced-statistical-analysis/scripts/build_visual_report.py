#!/usr/bin/env python3
"""Create an HTML statistical report with embedded charts."""

from __future__ import annotations

import argparse
import base64
import html
import json
import re
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from profile_dataset import detect_role, load_frame


def fail(message: str) -> "NoReturn":
    raise SystemExit(f"ERROR: {message}")


def img_to_data_uri(path: Path) -> str:
    encoded = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:image/png;base64,{encoded}"


def render_inline(text: str) -> str:
    escaped = html.escape(text)
    return re.sub(r"`([^`]+)`", r"<code>\1</code>", escaped)


def markdown_to_html(markdown_text: str) -> str:
    lines = markdown_text.splitlines()
    blocks: list[str] = []
    paragraph: list[str] = []
    list_type: str | None = None

    def flush_paragraph() -> None:
        nonlocal paragraph
        if paragraph:
            joined = " ".join(part.strip() for part in paragraph if part.strip())
            if joined:
                blocks.append(f"<p>{render_inline(joined)}</p>")
            paragraph = []

    def close_list() -> None:
        nonlocal list_type
        if list_type is not None:
            blocks.append(f"</{list_type}>")
            list_type = None

    for raw_line in lines:
        line = raw_line.rstrip()
        stripped = line.strip()
        if not stripped:
            flush_paragraph()
            close_list()
            continue
        if stripped.startswith("#"):
            flush_paragraph()
            close_list()
            level = min(len(stripped) - len(stripped.lstrip("#")), 6)
            title = stripped[level:].strip()
            blocks.append(f"<h{level + 1}>{render_inline(title)}</h{level + 1}>")
            continue
        bullet_match = re.match(r"^[-*]\s+(.*)$", stripped)
        ordered_match = re.match(r"^\d+\.\s+(.*)$", stripped)
        if bullet_match or ordered_match:
            flush_paragraph()
            target_type = "ul" if bullet_match else "ol"
            if list_type != target_type:
                close_list()
                list_type = target_type
                blocks.append(f"<{list_type}>")
            content = bullet_match.group(1) if bullet_match else ordered_match.group(1)
            blocks.append(f"<li>{render_inline(content)}</li>")
            continue
        if stripped.startswith(">"):
            flush_paragraph()
            close_list()
            blocks.append(f"<blockquote>{render_inline(stripped.lstrip('>').strip())}</blockquote>")
            continue
        paragraph.append(stripped)

    flush_paragraph()
    close_list()
    return "\n".join(blocks)


def save_missingness_chart(frame, out_path: Path) -> Path | None:
    missing = frame.isna().mean().sort_values(ascending=False) * 100
    if float(missing.max()) == 0.0:
        return None
    fig, ax = plt.subplots(figsize=(10, 4))
    missing.plot(kind="bar", ax=ax, color="#6C3BFF")
    ax.set_title("Missingness by Column (%)")
    ax.set_ylabel("Percent")
    ax.set_xlabel("")
    plt.tight_layout()
    fig.savefig(out_path, dpi=160)
    plt.close(fig)
    return out_path


def save_distribution_chart(frame, numeric_cols: list[str], out_path: Path) -> Path | None:
    if not numeric_cols:
        return None
    cols = numeric_cols[:4]
    fig, axes = plt.subplots(len(cols), 1, figsize=(9, 2.6 * len(cols)))
    if len(cols) == 1:
        axes = [axes]
    for ax, col in zip(axes, cols):
        values = frame[col].dropna().astype(float)
        ax.hist(values, bins=min(20, max(5, len(values))), color="#1DAFCB", edgecolor="white")
        ax.set_title(f"Distribution: {col}")
    plt.tight_layout()
    fig.savefig(out_path, dpi=160)
    plt.close(fig)
    return out_path


def save_corr_chart(frame, numeric_cols: list[str], out_path: Path) -> Path | None:
    if len(numeric_cols) < 2:
        return None
    corr = frame[numeric_cols].corr(numeric_only=True)
    fig, ax = plt.subplots(figsize=(6 + len(numeric_cols) * 0.4, 5))
    im = ax.imshow(corr, cmap="coolwarm", vmin=-1, vmax=1)
    ax.set_xticks(range(len(numeric_cols)))
    ax.set_xticklabels(numeric_cols, rotation=45, ha="right")
    ax.set_yticks(range(len(numeric_cols)))
    ax.set_yticklabels(numeric_cols)
    ax.set_title("Correlation Heatmap")
    fig.colorbar(im, ax=ax, shrink=0.8)
    plt.tight_layout()
    fig.savefig(out_path, dpi=160)
    plt.close(fig)
    return out_path


def save_group_chart(frame, numeric_col: str, group_col: str, out_path: Path) -> Path | None:
    subset = frame[[numeric_col, group_col]].dropna()
    if subset.empty:
        return None
    grouped = [grp[numeric_col].astype(float).to_numpy() for _, grp in subset.groupby(group_col)]
    labels = [str(name) for name, _ in subset.groupby(group_col)]
    if len(grouped) < 2:
        return None
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.boxplot(grouped, tick_labels=labels)
    ax.set_title(f"{numeric_col} by {group_col}")
    ax.set_ylabel(numeric_col)
    plt.tight_layout()
    fig.savefig(out_path, dpi=160)
    plt.close(fig)
    return out_path


def save_time_chart(frame, time_col: str, numeric_col: str, out_path: Path) -> Path | None:
    import pandas as pd

    subset = frame[[time_col, numeric_col]].dropna().copy()
    if len(subset) < 3:
        return None
    subset[time_col] = pd.to_datetime(subset[time_col], errors="coerce")
    subset = subset.dropna().sort_values(time_col)
    if len(subset) < 3:
        return None
    fig, ax = plt.subplots(figsize=(9, 4.5))
    ax.plot(subset[time_col], subset[numeric_col].astype(float), marker="o", color="#6C3BFF")
    ax.set_title(f"{numeric_col} over time")
    ax.set_ylabel(numeric_col)
    plt.xticks(rotation=30, ha="right")
    plt.tight_layout()
    fig.savefig(out_path, dpi=160)
    plt.close(fig)
    return out_path


def save_coef_chart(regression: dict, out_path: Path) -> Path | None:
    coeffs = [c for c in regression.get("coefficients", []) if c["name"] not in {"const", "intercept"}]
    if not coeffs:
        return None
    names = [c["name"] for c in coeffs]
    values = [float(c["coef"]) for c in coeffs]
    order = np.argsort(np.abs(values))[::-1][:8]
    names = [names[i] for i in order]
    values = [values[i] for i in order]
    fig, ax = plt.subplots(figsize=(8, 4.5))
    colors = ["#6C3BFF" if v >= 0 else "#F25C54" for v in values]
    ax.barh(names, values, color=colors)
    ax.set_title("Top Coefficients")
    ax.invert_yaxis()
    plt.tight_layout()
    fig.savefig(out_path, dpi=160)
    plt.close(fig)
    return out_path


def summarize_methods(analysis: dict) -> list[str]:
    analyses = analysis.get("analyses", {})
    items: list[str] = []

    group_test = analyses.get("group_test")
    if group_test:
        method = group_test.get("method", "group comparison")
        numeric_col = group_test.get("numeric_column", "target")
        group_col = group_test.get("group_column", "group")
        if "anova" in method.lower():
            items.append(
                f"{numeric_col}의 집단 차이를 보기 위해 {group_col} 기준 분산분석을 수행했고, 효과크기와 유의확률을 함께 해석했다."
            )
        else:
            items.append(
                f"{numeric_col}의 집단 차이를 보기 위해 {group_col} 기준 {method}를 적용했다."
            )

    chi_square = analyses.get("chi_square")
    if chi_square:
        items.append(
            f"{chi_square.get('column_1', 'categorical_1')}와 {chi_square.get('column_2', 'categorical_2')}의 범주형 연관성을 카이제곱 기반으로 검토했다."
        )

    regression = analyses.get("regression")
    if regression:
        target = regression.get("target", "outcome")
        r_squared = regression.get("r_squared")
        if r_squared is not None:
            items.append(
                f"{target} 설명을 위해 회귀모형을 사용했고, 모형 설명력은 R²={float(r_squared):.3f} 수준이었다."
            )
        else:
            items.append(f"{target} 설명을 위해 회귀모형을 사용해 주요 설명변수를 점검했다.")

    time_analysis = analyses.get("time_analysis")
    if time_analysis:
        items.append(
            f"{time_analysis.get('time_column', 'time')} 기준으로 {time_analysis.get('target', 'metric')} 추세를 집계해 시간 흐름과 계절성 가능성을 검토했다."
        )

    return items


def build_html(analysis: dict, charts: list[tuple[str, Path]], output_path: Path, narrative_html: str = "") -> str:
    insights = analysis.get("insights", [])
    methods = summarize_methods(analysis)
    chart_blocks = []
    for title, path in charts:
        chart_blocks.append(
            f"<section class='chart-card'><h3>{html.escape(title)}</h3><img src='{img_to_data_uri(path)}' alt='{html.escape(title)}' /></section>"
        )
    method_items = "".join(f"<li>{html.escape(item)}</li>" for item in methods)
    insight_items = "".join(f"<li>{html.escape(item)}</li>" for item in insights)
    limitation_items = "".join(f"<li>{html.escape(item)}</li>" for item in analysis.get("limitations", []))
    narrative_block = (
        f"<section class='card narrative' style='margin-top:24px;'><h2>상세 분석 보고서</h2>{narrative_html}</section>"
        if narrative_html
        else ""
    )
    return f"""<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>{html.escape(analysis.get('dataset', 'Statistical Report'))}</title>
  <style>
    body {{ margin: 0; font-family: Aptos, Segoe UI, sans-serif; background: linear-gradient(180deg, #eef2ff 0%, #f8fafc 100%); color: #14213D; }}
    .page {{ max-width: 1180px; margin: 0 auto; padding: 40px 28px 56px; }}
    .hero {{ padding: 28px 32px; border-radius: 24px; background: linear-gradient(135deg, #13263E 0%, #6C3BFF 100%); color: white; box-shadow: 0 24px 60px rgba(17,24,39,.18); }}
    .hero h1 {{ margin: 0 0 8px; font-size: 40px; }}
    .hero p {{ margin: 0; font-size: 18px; color: rgba(255,255,255,.88); }}
    .grid {{ display: grid; grid-template-columns: 1.1fr .9fr; gap: 24px; margin-top: 28px; }}
    .card {{ background: rgba(255,255,255,.9); border: 1px solid rgba(20,33,61,.08); border-radius: 22px; padding: 24px; box-shadow: 0 16px 32px rgba(15,23,42,.08); }}
    h2 {{ margin: 0 0 16px; font-size: 24px; }}
    h3 {{ margin: 0 0 12px; font-size: 20px; }}
    h4 {{ margin: 18px 0 10px; font-size: 18px; }}
    p {{ line-height: 1.72; margin: 0 0 14px; }}
    ul {{ margin: 0; padding-left: 22px; line-height: 1.55; }}
    ol {{ margin: 0; padding-left: 22px; line-height: 1.6; }}
    code {{ padding: 2px 6px; border-radius: 8px; background: rgba(108,59,255,.08); font-family: ui-monospace, SFMono-Regular, monospace; }}
    blockquote {{ margin: 0 0 14px; padding: 14px 16px; border-left: 4px solid #6C3BFF; background: rgba(108,59,255,.05); border-radius: 12px; }}
    .charts {{ display: grid; grid-template-columns: 1fr; gap: 22px; margin-top: 24px; }}
    .chart-card {{ background: white; border-radius: 22px; padding: 22px; box-shadow: 0 14px 28px rgba(15,23,42,.08); }}
    .chart-card img {{ width: 100%; border-radius: 14px; border: 1px solid rgba(20,33,61,.08); }}
    .narrative h2 {{ margin-bottom: 18px; }}
    .narrative h3 {{ margin-top: 20px; }}
  </style>
</head>
<body>
  <div class="page">
    <section class="hero">
      <h1>통계 분석 리포트</h1>
      <p>Dataset: {html.escape(analysis.get('dataset', 'unknown'))}</p>
    </section>
    <div class="grid">
      <section class="card">
        <h2>핵심 인사이트</h2>
        <ul>{insight_items}</ul>
      </section>
      <section class="card">
        <h2>한계와 주의사항</h2>
        <ul>{limitation_items}</ul>
      </section>
    </div>
    <section class="card" style="margin-top:24px;">
      <h2>수행된 분석</h2>
      <ul>{method_items}</ul>
    </section>
    {narrative_block}
    <div class="charts">{''.join(chart_blocks)}</div>
  </div>
</body>
</html>"""


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build an HTML visual statistical report.")
    parser.add_argument("--input", required=True, help="Dataset path")
    parser.add_argument("--analysis-json", required=True, help="Analysis JSON path")
    parser.add_argument("--output-html", required=True, help="Output HTML path")
    parser.add_argument("--asset-dir", required=True, help="Directory to save chart PNGs")
    parser.add_argument("--narrative-md", help="Optional narrative markdown report to embed in the HTML output")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    data_path = Path(args.input).expanduser().resolve()
    analysis_path = Path(args.analysis_json).expanduser().resolve()
    output_html = Path(args.output_html).expanduser().resolve()
    asset_dir = Path(args.asset_dir).expanduser().resolve()
    asset_dir.mkdir(parents=True, exist_ok=True)

    frame = load_frame(data_path, None)
    analysis = json.loads(analysis_path.read_text(encoding="utf-8"))
    narrative_html = ""
    if args.narrative_md:
        narrative_path = Path(args.narrative_md).expanduser().resolve()
        narrative_html = markdown_to_html(narrative_path.read_text(encoding="utf-8"))
    profile = analysis["profile"]
    numeric_cols = [c for c, info in profile["columns"].items() if info["role"] == "numeric"]

    charts: list[tuple[str, Path]] = []
    maybe = save_missingness_chart(frame, asset_dir / "missingness.png")
    if maybe:
        charts.append(("결측치 현황", maybe))
    maybe = save_distribution_chart(frame, numeric_cols, asset_dir / "distributions.png")
    if maybe:
        charts.append(("주요 수치형 변수 분포", maybe))
    maybe = save_corr_chart(frame, numeric_cols, asset_dir / "correlation.png")
    if maybe:
        charts.append(("상관구조", maybe))

    group_test = analysis["analyses"].get("group_test")
    if group_test:
        maybe = save_group_chart(frame, group_test["numeric_column"], group_test["group_column"], asset_dir / "group_compare.png")
        if maybe:
            charts.append(("집단 비교", maybe))

    time_analysis = analysis["analyses"].get("time_analysis")
    if time_analysis:
        maybe = save_time_chart(frame, time_analysis["time_column"], time_analysis["target"], asset_dir / "time_series.png")
        if maybe:
            charts.append(("시계열 추세", maybe))

    regression = analysis["analyses"].get("regression")
    if regression:
        maybe = save_coef_chart(regression, asset_dir / "coefficients.png")
        if maybe:
            charts.append(("회귀계수", maybe))

    output_html.write_text(build_html(analysis, charts, output_html, narrative_html=narrative_html), encoding="utf-8")
    print(json.dumps({
        "html_report": str(output_html),
        "chart_count": len(charts),
        "charts": [str(path) for _, path in charts],
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
