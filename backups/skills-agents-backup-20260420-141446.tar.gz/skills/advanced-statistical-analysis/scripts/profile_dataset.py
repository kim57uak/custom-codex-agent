#!/usr/bin/env python3
"""Profile a tabular dataset and suggest analysis directions."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


def fail(message: str) -> "NoReturn":
    raise SystemExit(f"ERROR: {message}")


def load_frame(path: Path, sheet_name: str | None):
    try:
        import pandas as pd
    except ImportError as exc:
        fail(f"pandas is required: {exc}")

    suffix = path.suffix.lower()
    if suffix == ".csv":
        return pd.read_csv(path)
    if suffix == ".tsv":
        return pd.read_csv(path, sep="\t")
    if suffix in {".xlsx", ".xls"}:
        return pd.read_excel(path, sheet_name=sheet_name or 0)
    if suffix == ".json":
        try:
            return pd.read_json(path)
        except ValueError:
            return pd.read_json(path, lines=True)
    if suffix == ".jsonl":
        return pd.read_json(path, lines=True)
    if suffix == ".parquet":
        return pd.read_parquet(path)
    fail(f"Unsupported file type: {suffix}")


def detect_role(series) -> str:
    import pandas as pd

    non_null = series.dropna()
    if non_null.empty:
        return "empty"
    if series.nunique(dropna=False) <= 1:
        return "constant"
    if pd.api.types.is_bool_dtype(series):
        return "boolean"
    if pd.api.types.is_datetime64_any_dtype(series):
        return "datetime"
    if pd.api.types.is_numeric_dtype(series):
        nunique = non_null.nunique()
        ratio = nunique / max(len(non_null), 1)
        lowered = str(series.name).lower()
        if lowered.endswith("id") or lowered == "id":
            return "id-like"
        if nunique == 2 and set(non_null.astype(float).unique()).issubset({0.0, 1.0}):
            return "boolean"
        if nunique <= 10 and ratio < 0.2:
            return "ordinal-or-coded"
        return "numeric"

    stringified = non_null.astype(str)
    date_like_ratio = float(
        stringified.str.contains(r"\d{4}[-/]\d{1,2}[-/]\d{1,2}|\d{1,2}[-/]\d{1,2}[-/]\d{2,4}", regex=True).mean()
    )
    if date_like_ratio >= 0.8:
        parsed_dt = pd.to_datetime(stringified, errors="coerce")
        if float(parsed_dt.notna().mean()) >= 0.9:
            return "datetime"
    avg_len = float(stringified.str.len().mean())
    nunique = non_null.nunique()
    ratio = nunique / max(len(non_null), 1)
    lowered = str(series.name).lower()
    if lowered.endswith("id") or lowered == "id" or ratio > 0.9:
        return "id-like"
    if avg_len > 40:
        return "text"
    if nunique <= 20:
        return "categorical"
    if ratio < 0.3:
        return "categorical"
    return "text"


def summarize_column(series) -> dict[str, Any]:
    role = detect_role(series)
    summary: dict[str, Any] = {
        "role": role,
        "dtype": str(series.dtype),
        "missing": int(series.isna().sum()),
        "missing_pct": round(float(series.isna().mean() * 100), 2),
        "unique": int(series.nunique(dropna=True)),
    }
    non_null = series.dropna()
    if role in {"numeric", "ordinal-or-coded"} and not non_null.empty:
        desc = non_null.astype(float).describe(percentiles=[0.25, 0.5, 0.75]).to_dict()
        summary["stats"] = {
            key: round(float(value), 4) for key, value in desc.items() if key in {"mean", "std", "min", "25%", "50%", "75%", "max"}
        }
    elif role in {"categorical", "boolean", "ordinal-or-coded"} and not non_null.empty:
        vc = non_null.astype(str).value_counts().head(5).to_dict()
        summary["top_values"] = vc
    elif role == "text" and not non_null.empty:
        lengths = non_null.astype(str).str.len()
        summary["text_length"] = {
            "mean": round(float(lengths.mean()), 2),
            "p95": round(float(lengths.quantile(0.95)), 2),
        }
    return summary


def build_recommendations(frame) -> list[str]:
    recommendations: list[str] = []
    import pandas as pd

    numeric_cols = [c for c in frame.columns if detect_role(frame[c]) == "numeric"]
    categorical_cols = [c for c in frame.columns if detect_role(frame[c]) in {"categorical", "boolean", "ordinal-or-coded"}]
    datetime_cols = [c for c in frame.columns if detect_role(frame[c]) == "datetime"]
    rows = len(frame)

    recommendations.append("Always start with descriptive statistics, missingness review, and duplicate checks.")
    if len(numeric_cols) >= 2:
        recommendations.append("Evaluate correlation structure and multivariable regression candidates among numeric features.")
    if numeric_cols and categorical_cols:
        recommendations.append("Test group differences with t-tests/ANOVA or non-parametric alternatives for numeric outcomes across categories.")
    if len(categorical_cols) >= 2:
        recommendations.append("Check categorical association with contingency tables and chi-square/Fisher tests.")
    if datetime_cols:
        recommendations.append("Inspect trend, seasonality, and time-order effects before using cross-sectional methods.")
    if len(numeric_cols) >= 5 and rows >= 100:
        recommendations.append("Consider PCA or clustering only after scaling and checking whether interpretability is needed.")
    if rows < 50:
        recommendations.append("Use conservative inference because the sample is small; emphasize effect sizes and uncertainty over complex models.")
    if frame.isna().mean().max() > 0.3:
        recommendations.append("Review missingness mechanisms before dropping rows or fitting models.")
    return recommendations


def pick_target_candidates(frame) -> list[str]:
    candidates: list[tuple[int, str]] = []
    for col in frame.columns:
        role = detect_role(frame[col])
        score = 0
        lowered = str(col).lower()
        if any(token in lowered for token in ("target", "label", "outcome", "y", "sales", "revenue", "score", "price", "churn", "default")):
            score += 3
        if role == "numeric":
            score += 2
        if role in {"categorical", "boolean"}:
            score += 1
        if role in {"id-like", "text", "constant", "empty"}:
            score -= 2
        candidates.append((score, str(col)))
    ordered = [name for score, name in sorted(candidates, reverse=True) if score > 0]
    return ordered[:5]


def profile_frame(frame, dataset_name: str) -> dict[str, Any]:
    columns = {str(col): summarize_column(frame[col]) for col in frame.columns}
    profile = {
        "dataset": dataset_name,
        "shape": {"rows": int(len(frame)), "columns": int(len(frame.columns))},
        "duplicates": int(frame.duplicated().sum()),
        "columns": columns,
        "target_candidates": pick_target_candidates(frame),
        "recommended_analysis_families": build_recommendations(frame),
    }
    profile["role_counts"] = {}
    for info in columns.values():
        role = info["role"]
        profile["role_counts"][role] = profile["role_counts"].get(role, 0) + 1
    return profile


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Profile a tabular dataset.")
    parser.add_argument("--input", required=True, help="Input dataset path")
    parser.add_argument("--sheet-name", help="Excel sheet name or index")
    parser.add_argument("--output", help="Optional output JSON path")
    parser.add_argument("--indent", type=int, default=2, help="JSON indent")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    path = Path(args.input).expanduser().resolve()
    if not path.exists():
        fail(f"Input file not found: {path}")
    frame = load_frame(path, args.sheet_name)
    profile = profile_frame(frame, path.name)
    text = json.dumps(profile, ensure_ascii=False, indent=args.indent)
    if args.output:
        Path(args.output).expanduser().resolve().write_text(text, encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()
