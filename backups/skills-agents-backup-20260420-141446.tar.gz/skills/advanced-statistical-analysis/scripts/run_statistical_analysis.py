#!/usr/bin/env python3
"""Run a compact but useful statistical analysis workflow on tabular data."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np

from profile_dataset import detect_role, load_frame, profile_frame


def fail(message: str) -> "NoReturn":
    raise SystemExit(f"ERROR: {message}")


def safe_float(value: Any) -> float | None:
    if value is None:
        return None
    try:
        if np.isnan(value):
            return None
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return None


def choose_columns(frame, profile: dict[str, Any], target: str | None, group: str | None, time_col: str | None) -> dict[str, str | None]:
    columns = profile["columns"]
    if target and target not in frame.columns:
        fail(f"Target column not found: {target}")
    if group and group not in frame.columns:
        fail(f"Group column not found: {group}")
    if time_col and time_col not in frame.columns:
        fail(f"Time column not found: {time_col}")

    target_col = target or next(iter(profile.get("target_candidates", [])), None)
    group_col = group
    if group_col is None:
        for col, info in columns.items():
            if col == target_col:
                continue
            if info["role"] in {"categorical", "boolean", "ordinal-or-coded"}:
                group_col = col
                break
    time_name = time_col
    if time_name is None:
        for col, info in columns.items():
            if info["role"] == "datetime":
                time_name = col
                break
    return {"target": target_col, "group": group_col, "time": time_name}


def top_correlations(frame, profile: dict[str, Any]) -> list[dict[str, Any]]:
    numeric_cols = [c for c, info in profile["columns"].items() if info["role"] == "numeric"]
    if len(numeric_cols) < 2:
        return []
    corr = frame[numeric_cols].corr(numeric_only=True)
    pairs: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for a in numeric_cols:
        for b in numeric_cols:
            if a == b:
                continue
            key = tuple(sorted((a, b)))
            if key in seen:
                continue
            seen.add(key)
            value = safe_float(corr.loc[a, b])
            if value is None:
                continue
            pairs.append({"x": a, "y": b, "correlation": round(value, 4), "abs_correlation": round(abs(value), 4)})
    return sorted(pairs, key=lambda item: item["abs_correlation"], reverse=True)[:8]


def run_group_test(frame, numeric_col: str, group_col: str) -> dict[str, Any] | None:
    try:
        from scipy import stats
    except ImportError:
        return None

    subset = frame[[numeric_col, group_col]].dropna()
    groups = {
        str(name): values[numeric_col].astype(float).to_numpy()
        for name, values in subset.groupby(group_col)
        if len(values) >= 2
    }
    if len(groups) < 2:
        return None

    names = list(groups.keys())
    arrays = list(groups.values())
    result: dict[str, Any] = {
        "numeric_column": numeric_col,
        "group_column": group_col,
        "group_sizes": {name: int(len(values)) for name, values in groups.items()},
    }
    if len(groups) == 2:
        stat, pvalue = stats.ttest_ind(arrays[0], arrays[1], equal_var=False, nan_policy="omit")
        pooled = np.sqrt((np.var(arrays[0], ddof=1) + np.var(arrays[1], ddof=1)) / 2)
        d = None if pooled == 0 else (np.mean(arrays[0]) - np.mean(arrays[1])) / pooled
        result.update({
            "method": "welch_t_test",
            "groups": names,
            "statistic": round(float(stat), 4),
            "p_value": round(float(pvalue), 6),
            "effect_size": {"metric": "cohens_d", "value": None if d is None else round(float(d), 4)},
            "group_means": {name: round(float(np.mean(values)), 4) for name, values in groups.items()},
        })
    else:
        stat, pvalue = stats.f_oneway(*arrays)
        all_values = np.concatenate(arrays)
        grand_mean = float(np.mean(all_values))
        ss_between = sum(len(values) * (float(np.mean(values)) - grand_mean) ** 2 for values in arrays)
        ss_total = sum((float(value) - grand_mean) ** 2 for value in all_values)
        eta_sq = None if ss_total == 0 else ss_between / ss_total
        result.update({
            "method": "anova",
            "groups": names,
            "statistic": round(float(stat), 4),
            "p_value": round(float(pvalue), 6),
            "effect_size": {"metric": "eta_squared", "value": None if eta_sq is None else round(float(eta_sq), 4)},
            "group_means": {name: round(float(np.mean(values)), 4) for name, values in groups.items()},
        })
    return result


def run_chi_square(frame, profile: dict[str, Any]) -> dict[str, Any] | None:
    try:
        from scipy import stats
        import pandas as pd
    except ImportError:
        return None

    categoricals = [c for c, info in profile["columns"].items() if info["role"] in {"categorical", "boolean"}]
    if len(categoricals) < 2:
        return None
    x, y = categoricals[:2]
    subset = frame[[x, y]].dropna()
    if subset.empty:
        return None
    table = pd.crosstab(subset[x], subset[y])
    if table.shape[0] < 2 or table.shape[1] < 2:
        return None
    chi2, pvalue, dof, _ = stats.chi2_contingency(table)
    n = table.values.sum()
    min_dim = min(table.shape) - 1
    cramers_v = None if min_dim <= 0 or n <= 0 else np.sqrt(chi2 / (n * min_dim))
    return {
        "method": "chi_square",
        "columns": [x, y],
        "statistic": round(float(chi2), 4),
        "p_value": round(float(pvalue), 6),
        "degrees_of_freedom": int(dof),
        "effect_size": {"metric": "cramers_v", "value": None if cramers_v is None else round(float(cramers_v), 4)},
    }


def run_regression(frame, profile: dict[str, Any], target_col: str | None) -> dict[str, Any] | None:
    if not target_col or target_col not in frame.columns:
        return None
    target_role = profile["columns"][target_col]["role"]
    predictor_cols = [
        col for col, info in profile["columns"].items()
        if col != target_col and info["role"] == "numeric"
    ]
    if not predictor_cols:
        return None

    subset = frame[[target_col] + predictor_cols].dropna()
    if len(subset) < 8:
        return None
    X = subset[predictor_cols].astype(float)
    y = subset[target_col]

    if target_role == "numeric":
        try:
            import statsmodels.api as sm

            X_const = sm.add_constant(X, has_constant="add")
            model = sm.OLS(y.astype(float), X_const).fit()
            coefficients = []
            for name in model.params.index:
                coefficients.append({
                    "name": str(name),
                    "coef": round(float(model.params[name]), 6),
                    "p_value": round(float(model.pvalues[name]), 6),
                })
            return {
                "method": "ols",
                "target": target_col,
                "predictors": predictor_cols,
                "r_squared": round(float(model.rsquared), 6),
                "adj_r_squared": round(float(model.rsquared_adj), 6),
                "coefficients": coefficients,
            }
        except Exception:
            from sklearn.linear_model import LinearRegression

            model = LinearRegression().fit(X, y.astype(float))
            r2 = model.score(X, y.astype(float))
            coefficients = [{"name": name, "coef": round(float(coef), 6)} for name, coef in zip(predictor_cols, model.coef_)]
            coefficients.insert(0, {"name": "intercept", "coef": round(float(model.intercept_), 6)})
            return {
                "method": "linear_regression",
                "target": target_col,
                "predictors": predictor_cols,
                "r_squared": round(float(r2), 6),
                "coefficients": coefficients,
            }

    if target_role == "boolean":
        y_bin = y.astype(int)
        try:
            import statsmodels.api as sm

            X_const = sm.add_constant(X, has_constant="add")
            model = sm.Logit(y_bin, X_const).fit(disp=False)
            coefficients = []
            for name in model.params.index:
                coefficients.append({
                    "name": str(name),
                    "coef": round(float(model.params[name]), 6),
                    "odds_ratio": round(float(np.exp(model.params[name])), 6),
                    "p_value": round(float(model.pvalues[name]), 6),
                })
            return {
                "method": "logistic_regression",
                "target": target_col,
                "predictors": predictor_cols,
                "pseudo_r_squared": round(float(getattr(model, "prsquared", 0.0)), 6),
                "coefficients": coefficients,
            }
        except Exception:
            from sklearn.linear_model import LogisticRegression

            model = LogisticRegression(max_iter=2000).fit(X, y_bin)
            coefficients = [{"name": name, "coef": round(float(coef), 6)} for name, coef in zip(predictor_cols, model.coef_[0])]
            coefficients.insert(0, {"name": "intercept", "coef": round(float(model.intercept_[0]), 6)})
            return {
                "method": "logistic_regression_sklearn",
                "target": target_col,
                "predictors": predictor_cols,
                "coefficients": coefficients,
            }
    return None


def run_time_analysis(frame, target_col: str | None, time_col: str | None) -> dict[str, Any] | None:
    if not target_col or not time_col:
        return None
    subset = frame[[time_col, target_col]].dropna().copy()
    if len(subset) < 3:
        return None
    try:
        subset[time_col] = __import__("pandas").to_datetime(subset[time_col], errors="coerce")
    except Exception:
        return None
    subset = subset.dropna().sort_values(time_col)
    if len(subset) < 3:
        return None
    try:
        values = subset[target_col].astype(float).to_numpy()
    except Exception:
        return None
    x = np.arange(len(values))
    slope, intercept = np.polyfit(x, values, 1)
    pct_change = None
    if values[0] != 0:
        pct_change = (values[-1] - values[0]) / values[0]
    return {
        "method": "trend_summary",
        "time_column": time_col,
        "target": target_col,
        "start": str(subset[time_col].iloc[0].date()),
        "end": str(subset[time_col].iloc[-1].date()),
        "slope_per_period": round(float(slope), 6),
        "start_value": round(float(values[0]), 6),
        "end_value": round(float(values[-1]), 6),
        "pct_change": None if pct_change is None else round(float(pct_change), 6),
    }


def build_insights(profile: dict[str, Any], analyses: dict[str, Any], selected: dict[str, str | None]) -> list[str]:
    insights: list[str] = []
    rows = profile["shape"]["rows"]
    insights.append(f"데이터는 {rows}행, {profile['shape']['columns']}열이며 중복행은 {profile['duplicates']}개다.")
    if profile["target_candidates"]:
        insights.append(f"자동 감지 기준 가장 유력한 타깃 후보는 {', '.join(profile['target_candidates'][:3])}이다.")

    corr_pairs = analyses.get("top_correlations", [])
    if corr_pairs:
        top = corr_pairs[0]
        insights.append(
            f"{top['x']}와 {top['y']}의 상관계수는 {top['correlation']:.2f}로, 현재 데이터에서 가장 강한 선형 연관 후보다."
        )

    group_test = analyses.get("group_test")
    if group_test:
        metric = group_test["numeric_column"]
        pvalue = group_test["p_value"]
        insights.append(
            f"{group_test['group_column']} 기준 {metric} 비교는 {group_test['method']} 결과 p={pvalue:.4f}이며, 집단 차이 해석은 효과크기와 함께 봐야 한다."
        )

    regression = analyses.get("regression")
    if regression and regression["coefficients"]:
        coefs = [c for c in regression["coefficients"] if c["name"] != "const" and c["name"] != "intercept"]
        if coefs:
            lead = sorted(coefs, key=lambda item: abs(item["coef"]), reverse=True)[0]
            insights.append(
                f"{regression['method']} 기준 {regression['target']} 설명에서 {lead['name']}의 계수 절대값이 가장 커 주요 설명변수 후보로 보인다."
            )

    time_analysis = analyses.get("time_analysis")
    if time_analysis and time_analysis["pct_change"] is not None:
        insights.append(
            f"{time_analysis['target']}는 {time_analysis['start']}부터 {time_analysis['end']}까지 약 {time_analysis['pct_change'] * 100:.1f}% 변했다."
        )

    if rows < 50:
        insights.append("표본 수가 작으므로 복잡한 모델보다 보수적 추정과 효과크기 중심 해석이 적절하다.")
    return insights


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run statistical analysis on a tabular dataset.")
    parser.add_argument("--input", required=True, help="Dataset path")
    parser.add_argument("--output", required=True, help="Output analysis JSON path")
    parser.add_argument("--target", help="Target column")
    parser.add_argument("--group", help="Grouping column for group comparison")
    parser.add_argument("--time-column", help="Time column")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    path = Path(args.input).expanduser().resolve()
    frame = load_frame(path, None)
    profile = profile_frame(frame, path.name)
    selected = choose_columns(frame, profile, args.target, args.group, args.time_column)

    numeric_target = None
    if selected["target"] and profile["columns"].get(selected["target"], {}).get("role") == "numeric":
        numeric_target = selected["target"]
    elif selected["target"] and profile["columns"].get(selected["target"], {}).get("role") == "boolean":
        numeric_target = next((c for c, info in profile["columns"].items() if info["role"] == "numeric"), None)
    else:
        numeric_target = next((c for c, info in profile["columns"].items() if info["role"] == "numeric"), None)

    analyses = {
        "selected_columns": selected,
        "top_correlations": top_correlations(frame, profile),
        "group_test": run_group_test(frame, numeric_target, selected["group"]) if numeric_target and selected["group"] else None,
        "chi_square": run_chi_square(frame, profile),
        "regression": run_regression(frame, profile, selected["target"]),
        "time_analysis": run_time_analysis(frame, numeric_target or selected["target"], selected["time"]),
    }

    result = {
        "dataset": path.name,
        "profile": profile,
        "analyses": analyses,
        "insights": build_insights(profile, analyses, selected),
        "limitations": [
            "관찰자료만으로 인과를 단정할 수 없다.",
            "자동 선택된 분석은 데이터 구조를 기준으로 한 1차 추천이며, 도메인 맥락 검토가 필요하다.",
        ],
    }

    out_path = Path(args.output).expanduser().resolve()
    out_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
