#!/usr/bin/env python3
"""Suggest a statistical analysis plan from a dataset or profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


def fail(message: str) -> "NoReturn":
    raise SystemExit(f"ERROR: {message}")


def load_profile_from_dataset(dataset_path: Path) -> dict[str, Any]:
    from profile_dataset import load_frame, profile_frame

    frame = load_frame(dataset_path, None)
    return profile_frame(frame, dataset_path.name)


def load_profile(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def build_plan(profile: dict[str, Any]) -> dict[str, Any]:
    role_counts = profile.get("role_counts", {})
    rows = profile.get("shape", {}).get("rows", 0)
    columns = profile.get("columns", {})
    max_missing = 0.0
    for info in columns.values():
        max_missing = max(max_missing, float(info.get("missing_pct", 0.0)))

    methods: list[dict[str, str]] = []
    visuals: list[str] = []
    cautions: list[str] = []
    insights_focus: list[str] = []

    numeric_count = int(role_counts.get("numeric", 0))
    categorical_count = int(role_counts.get("categorical", 0) + role_counts.get("boolean", 0) + role_counts.get("ordinal-or-coded", 0))
    datetime_count = int(role_counts.get("datetime", 0))

    methods.append({
        "family": "descriptive",
        "recommendation": "Start with descriptive statistics, missingness, duplicates, and segment sizes.",
    })
    visuals.extend([
        "distribution charts for major numeric variables",
        "missingness summary or heatmap when missing data is material",
    ])
    insights_focus.append("identify unusual distributions, sparse groups, and data quality risks before inference")

    if numeric_count >= 2:
        methods.append({
            "family": "association",
            "recommendation": "Assess Pearson or Spearman relationships and consider multivariable regression for continuous outcomes.",
        })
        visuals.extend([
            "scatter plots with fit lines",
            "correlation heatmap if the variable count is manageable",
        ])
        insights_focus.append("separate strong drivers from redundant or collinear metrics")

    if numeric_count >= 1 and categorical_count >= 1:
        methods.append({
            "family": "group-comparison",
            "recommendation": "Compare numeric outcomes across groups with Welch t-tests, ANOVA, or non-parametric alternatives.",
        })
        visuals.extend([
            "box or violin plots by category",
            "point estimates with confidence intervals",
        ])
        insights_focus.append("quantify which groups differ meaningfully and by how much")

    if categorical_count >= 2:
        methods.append({
            "family": "categorical-association",
            "recommendation": "Use contingency tables and chi-square or Fisher tests for relationships between categorical variables.",
        })
        visuals.append("normalized stacked bars or mosaic-style comparisons")

    if datetime_count >= 1:
        methods.append({
            "family": "time-series",
            "recommendation": "Check trends, seasonality, and changepoints before using purely cross-sectional models.",
        })
        visuals.append("time-series line plots with rolling means and event annotations")
        insights_focus.append("distinguish durable trend from short-term volatility")

    if numeric_count >= 5 and rows >= 100:
        methods.append({
            "family": "multivariate-structure",
            "recommendation": "Use PCA or clustering only if the goal includes segmentation or structure discovery.",
        })
        visuals.extend([
            "PCA projection with explained variance",
            "cluster profile comparison",
        ])

    if rows < 50:
        cautions.append("Sample size is small; keep methods conservative and emphasize uncertainty.")
    if max_missing >= 30:
        cautions.append("At least one variable has heavy missingness; assess missingness mechanisms before inference.")
    if not cautions:
        cautions.append("Validate model assumptions and avoid overstating causal claims from observational structure.")

    return {
        "dataset": profile.get("dataset"),
        "shape": profile.get("shape"),
        "target_candidates": profile.get("target_candidates", []),
        "methods": methods,
        "visuals": visuals,
        "insights_focus": insights_focus,
        "cautions": cautions,
    }


def render_markdown(plan: dict[str, Any]) -> str:
    lines = [
        f"# Statistical analysis plan for {plan.get('dataset', 'dataset')}",
        "",
        f"- Shape: {plan.get('shape', {}).get('rows', '?')} rows x {plan.get('shape', {}).get('columns', '?')} columns",
        f"- Target candidates: {', '.join(plan.get('target_candidates', [])) or 'none detected'}",
        "",
        "## Recommended method families",
    ]
    for item in plan.get("methods", []):
        lines.append(f"- `{item['family']}`: {item['recommendation']}")
    lines.extend(["", "## Visualization priorities"])
    for item in plan.get("visuals", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Insight focus"])
    for item in plan.get("insights_focus", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Cautions"])
    for item in plan.get("cautions", []):
        lines.append(f"- {item}")
    return "\n".join(lines)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Suggest a statistical analysis plan.")
    parser.add_argument("--input", help="Raw dataset path")
    parser.add_argument("--profile", help="Profile JSON path")
    parser.add_argument("--format", choices=("json", "markdown"), default="markdown")
    parser.add_argument("--output", help="Optional output path")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if not args.input and not args.profile:
        fail("Provide either --input or --profile")
    if args.input and args.profile:
        fail("Use only one of --input or --profile")

    if args.input:
        profile = load_profile_from_dataset(Path(args.input).expanduser().resolve())
    else:
        profile = load_profile(Path(args.profile).expanduser().resolve())

    plan = build_plan(profile)
    if args.format == "json":
        text = json.dumps(plan, ensure_ascii=False, indent=2)
    else:
        text = render_markdown(plan)
    if args.output:
        Path(args.output).expanduser().resolve().write_text(text, encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()
