---
name: advanced-statistical-analysis
description: 표 형식 데이터에 대한 종합 통계 분석 워크플로입니다. 빠른 탐색적 프로파일링과 기술 통계부터 가설 검정, 회귀, 분류, 군집화, 차원 축소, 시계열 분석, 인과적 해석, 시각화, 비즈니스 인사이트 도출까지 포함합니다. Codex가 CSV/Excel/JSON/Parquet 데이터를 점검하고, 적절한 통계 접근을 자율적으로 선택하며, 엄밀한 분석을 수행하고, 가정과 한계를 설명하며, 강한 차트와 의사결정 중심 해석으로 명확한 내러티브 결과를 제시해야 할 때 사용합니다.
---

# 고급 통계 분석

## 개요

이 스킬은 원시 표 형식 데이터에서 방어 가능한 통계 결과까지 도달하기 위해 사용합니다. 먼저 데이터를 빠르게 프로파일링하고, 데이터 구조와 사용자 질문에 맞는 추론 또는 고급 방법을 선택한 뒤, 명확한 caveat, 시각적 근거, 필요 시 HTML/PPTX 산출물까지 포함한 해석 가능한 결과를 만들어야 합니다.

이 스킬은 단순 profiler 출력 래퍼가 아닙니다. 방법을 자율적으로 선택하고, 데이터를 여러 분석 관점에서 살펴보며, 기계적인 통계 목록이 아니라 깊이 있는 인사이트를 내는 것이 기대됩니다.

사용자가 정식 산출물을 원하면, 품질 기준은 상업적으로 사용 가능한 통계 보고서 수준이어야 합니다. 분석적으로 엄밀하고, 시각적으로 정돈되어 있으며, 일반적인 사실 검토 후 외부 또는 임원 대상 검토에 적합해야 합니다.

## 워크플로

### 1. 분석 목표 명확화

방법을 실행하기 전에 요청을 분류합니다.

- descriptive: 분포, 결측, 세그먼트, 추세 요약
- inferential: 그룹이나 효과가 노이즈 이상으로 다른지 검정
- predictive: 결과 추정 또는 라벨 분류
- explanatory: 드라이버, 효과 크기, 불확실성 정량화
- unsupervised: 세그먼트, 잠재 차원, 이상치 탐지
- time-series: 추세, 계절성, 변화점, 예측 리스크 모델링

사용자 질문이 충분히 구체적이지 않으면, 데이터셋 구조를 바탕으로 가장 가능성 높은 목표를 추론하고 그 추론을 명시합니다.

### 2. 방법 선택 전에 데이터 스캔

기본 데이터셋에는 먼저 `scripts/profile_dataset.py`를 실행합니다. 이를 통해 다음을 파악합니다.

- row 수, column 수, 중복, 결측, 상수 컬럼
- 컬럼 역할: numeric, categorical, boolean, datetime, text, id-like
- 데이터가 시사하는 후보 분석 계열
- 후보 타깃 컬럼과 작은 샘플, 심각한 결측 같은 리스크

그다음 profile 결과 또는 원본 데이터셋에 대해 `scripts/suggest_analysis_plan.py`를 실행하여 1차 분석 계획을 생성합니다.

그 계획은 초안일 뿐 최종 답이 아닙니다. 실제 데이터 구조에 맞게 다듬거나 확장하거나 교체합니다. 데이터가 더 풍부한 분석을 허용한다면 기본 계획에서 멈추지 말고 다음과 같은 여러 관점에서 문제를 봅니다.

- 규모와 분포
- 카테고리, 채널, 지역, 코호트, 시간 기준 세분화
- 드라이버 분석과 효과 크기
- 계절성, 추세, 체제 변화, 집중 리스크
- 민감도, 강건성, 해석 한계

end-to-end 분석에서는 다음 순서를 사용합니다.

1. `scripts/profile_dataset.py`
2. `scripts/suggest_analysis_plan.py`
3. `scripts/run_statistical_analysis.py`
4. `scripts/build_visual_report.py`
5. `scripts/build_analysis_deck.py`

### 3. 의도적으로 방법 선택

분석 계획을 기준선으로 삼되, 사용자 질문과 데이터 현실에 맞게 조정합니다.

방법 선택은 자율적이고 근거 기반이어야 합니다. 하나의 범용 스크립트만 실행하고 끝내지 않습니다. 데이터셋을 가장 잘 설명하는, 방어 가능한 descriptive, inferential, predictive, time-aware, segmentation 방법 조합을 선택합니다.

대표적인 방법 선택:

- 독립된 두 numeric 그룹: 기본은 Welch t-test, 분포 가정이 나쁘면 Mann-Whitney
- 세 그룹 이상: ANOVA 후 post-hoc test, 필요 시 Kruskal-Wallis
- paired measurement: paired t-test 또는 Wilcoxon signed-rank
- categorical association: chi-square 또는 Fisher exact
- continuous association: scale과 monotonicity에 따라 Pearson 또는 Spearman
- 다변량 numeric outcome: 진단을 포함한 OLS 또는 regularized regression
- binary outcome: calibration과 class-balance 점검을 포함한 logistic regression
- count outcome: 적절할 경우 Poisson 또는 negative binomial
- 계절성이 있는 시간 추세: cadence가 허용하면 decomposition과 ARIMA/ETS류 프레이밍
- segmentation: 스케일링, 변수 선택, 비즈니스 해석 가능성 점검 후에만 clustering
- 차원 축소: numeric 구조 탐색용 PCA, 인사이트의 대체물이 아님

선택이 명확하지 않으면 [method-selection.md](/Users/dolpaks/.codex/skills/advanced-statistical-analysis/references/method-selection.md)를 읽습니다.

### 4. p-value보다 인사이트 우선

항상 다음을 보고합니다.

- effect size 또는 실질적 중요도
- 불확실성: confidence interval, standard error, 또는 적절한 uncertainty 프레이밍
- 가정 점검과 데이터 품질 문제
- 비즈니스 또는 운영 관점 해석
- 어떤 조건에서 결론이 바뀌는지

통계적 유의성을 그 자체로 충분한 근거로 취급하지 않습니다.
통계적으로 강해도 전략적으로 중요하지 않다면 그 점을 직접 말합니다.

### 5. 대시보드 생성기가 아니라 분석가처럼 시각화

구조와 불확실성을 드러내는 차트를 선호합니다.

- 분포: histogram, KDE, ECDF, box/violin
- 관계: fit line과 uncertainty band를 포함한 scatter
- 그룹 평균과 불확실성: confidence interval이 있는 point plot
- 회귀 요약: 효과 크기 순으로 정렬한 coefficient plot
- 상관 구조: 변수 수가 적절할 때만 correlation heatmap
- 시계열: moving average 또는 regime marker가 있는 annotated time-series
- 고급 방법 사용 시 coefficient plot, partial dependence 스타일 시각화, cluster profile, PCA loading view

차트를 확정하기 전에 [interpretation-and-visualization.md](/Users/dolpaks/.codex/skills/advanced-statistical-analysis/references/interpretation-and-visualization.md)를 읽습니다.

### 6. 의사결정 언어로 결과 작성

좋은 출력 구조:

1. 목표와 데이터 범위
2. 빠른 데이터 품질 요약
3. 방법 선택과 적합 이유
4. 불확실성과 효과 크기를 포함한 핵심 결과
5. 주장 근거가 되는 시각화
6. 한계와 다음 분석 단계

내부 분석이라면 기술적 세부 사항을 더 넣고, 임원 또는 외부 고객 대상이라면 수식은 압축하고 결론을 앞세웁니다.

보고서, 메모, 발표 본문에 raw JSON blob을 붙여 넣지 않습니다. 기계 판독용 JSON은 별도 산출물로 둘 수 있지만, 메인 내러티브는 문장, 표, 차트, 간결한 통계 서술로 구성해야 합니다.

상세 markdown 보고서를 만들었다면, 사용자가 명시적으로 거절하지 않는 한 대응되는 HTML 보고서도 함께 생성합니다. HTML 보고서는 markdown 분석의 실질적 본문을 유지해야 하며, 짧은 대시보드 요약으로 대체하면 안 됩니다.

가치가 높은 산출물이라면 HTML 보고서는 두 층으로 구성합니다.

- 가장 중요한 의사결정 신호, 지표, 차트를 강조하는 대시보드형 상단
- 방법, 근거, 해석, caveat, 권고를 설명하는 상세 분석 섹션

HTML 출력은 의도적인 프레젠테이션 품질의 디자인을 적용합니다. raw notebook export나 평범한 dashboard처럼 보여서는 안 됩니다.

HTML에 차트를 포함할 때는 파일 하나로 이동 가능한 self-contained deliverable이 되도록 기본적으로 base64 data URI로 임베드합니다.

사용자가 "best" 또는 "deep" 분석을 요구하면 최소 기준은 다음과 같습니다.

- 단일 검정 계열이 아닌 여러 분석 관점
- effect size, 불확실성, 실질적 해석
- 구조, 드라이버, 리스크, 한계에 대한 명시적 설명
- 무엇이 중요하고 왜 중요한지 전달하는 내러티브 인사이트

## 스크립트

### `scripts/profile_dataset.py`

CSV, TSV, Excel, JSON, JSONL, Parquet 데이터를 프로파일링하고 구조화된 JSON profile을 출력합니다. 거의 모든 표 형식 데이터셋에서 첫 단계로 사용합니다.

```bash
python3 scripts/profile_dataset.py --input data.csv --output profile.json
```

### `scripts/suggest_analysis_plan.py`

원본 데이터셋 또는 profile JSON에서 통계 접근을 추천합니다.

```bash
python3 scripts/suggest_analysis_plan.py --input data.csv --format markdown
python3 scripts/suggest_analysis_plan.py --profile profile.json --format json
```

### `scripts/run_statistical_analysis.py`

데이터가 허용하는 범위에서 descriptive analysis, correlation, group test, chi-square, regression, time-trend summary를 수행합니다.

```bash
python3 scripts/run_statistical_analysis.py --input data.csv --output analysis.json
```

### `scripts/build_visual_report.py`

base64 PNG 차트와 내러티브 요약이 포함된 HTML 보고서를 생성합니다. 상세 markdown 보고서가 있으면 전달하여 본문 전체를 HTML에 포함합니다.

```bash
python3 scripts/build_visual_report.py \
  --input data.csv \
  --analysis-json analysis.json \
  --narrative-md report.md \
  --output-html report.html \
  --asset-dir report-assets
```

### `scripts/build_analysis_deck.py`

`pptx-generator`와 연동하여 분석 결과로부터 HTML deck과 PowerPoint 요약 deck을 생성합니다.

```bash
python3 scripts/build_analysis_deck.py \
  --analysis-json analysis.json \
  --chart-dir report-assets \
  --output-dir deliverables \
  --deck-name final-analysis
```

## 참고 문서

- [analysis-playbook.md](/Users/dolpaks/.codex/skills/advanced-statistical-analysis/references/analysis-playbook.md): end-to-end 워크플로와 보고 기준
- [method-selection.md](/Users/dolpaks/.codex/skills/advanced-statistical-analysis/references/method-selection.md): 방법 선택 규칙과 escalation 가이드
- [interpretation-and-visualization.md](/Users/dolpaks/.codex/skills/advanced-statistical-analysis/references/interpretation-and-visualization.md): 차트 선택과 인사이트 프레이밍

## 산출물

사용자가 다음 출력 중 하나 이상을 원할 때 이 스킬을 사용합니다.

- exploratory profile JSON
- analysis plan markdown 또는 JSON
- statistical analysis result JSON
- HTML visual analysis report
- base64 시각화가 포함된 self-contained HTML report
- `pptx-generator`를 통해 생성된 HTML deck
- `pptx-generator`를 통해 생성된 PowerPoint summary deck
- JSON 스타일 본문이 없는 narrative report

## 가드레일

- 명확한 설계 없이 observational correlation에서 인과성을 암시하지 않습니다.
- 검정력 부족, 결측 편향, leakage 리스크, multiple-testing 문제가 있으면 명시합니다.
- 복잡한 방법으로 올라가기 전에 단순하고 강건한 방법을 우선합니다.
- 가장 범용적이거나 가장 쉬운 스크립트 경로가 아니라, 의사결정에 가장 유용한 방법 조합을 선택합니다.
- 데이터가 작거나 지저분하면 그 사실을 명확히 말하고 분석 야심을 낮춥니다.
- 여전히 해석이 필요한 raw machine output만 남기지 않습니다.

## 파일 입력 유효성 체크

- 이 스킬의 현재 요청이 파일 입력 없이도 수행 가능한 범위라면, 파일 경로를 요구하지 말고 바로 작업을 진행합니다.
- 사용자가 문서/코드/계약서 본문을 메시지에 직접 제공한 경우에는 파일 경로 없이도 해당 텍스트로 작업을 진행합니다.
- 특정 파일의 실제 내용을 읽어야만 작업이 가능한 경우에만, **파일 경로 + 파일명** 제공 여부를 확인합니다.
- 파일 경로 또는 파일명이 누락된 경우에는 파일 작업을 진행하지 않고, 사용자에게 정확한 파일 경로와 파일명을 먼저 요청합니다.
- 경로가 모호한 표현(예: "그 파일", "지난번 문서")만 있는 경우에도 동일하게 명시 경로를 요청합니다.

