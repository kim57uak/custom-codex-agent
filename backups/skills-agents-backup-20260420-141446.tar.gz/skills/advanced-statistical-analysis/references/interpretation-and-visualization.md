# 해석과 시각화

## 차트 선택

- 분포 비교: violin + box overlay, faceted histogram, 또는 ECDF
- 두 numeric 변수 관계: fit line과 confidence band가 있는 scatter
- 불확실성을 포함한 그룹 평균: confidence interval이 있는 point plot
- 회귀 요약: effect magnitude 순으로 정렬한 coefficient plot
- 상관 구조: 변수 수가 중간 규모일 때만 clustered heatmap
- 시계열: rolling mean과 event/changepoint annotation이 있는 line plot
- 군집: PCA projection 또는 표준화된 profile chart와 cluster size

## 해석 규칙

- 실무적 결론을 먼저 말하고, 그다음 통계를 제시합니다.
- 가능하면 effect size를 도메인 단위로 보고합니다.
- 약하거나 불안정한 패턴을 과장하지 않습니다.
- 어떤 조건에서 결론이 무효화되는지 말합니다.
- HTML 산출물에서는 외부 차트 파일 링크보다 base64 이미지가 포함된 self-contained 시각 섹션을 선호합니다.
- 상세 내러티브 보고서가 있으면, 차트는 내러티브를 대체하는 갤러리가 아니라 그 내러티브를 지원해야 합니다.
- 상업 대상 출력에서는 명확한 시각 계층을 사용합니다. 먼저 high-signal dashboard summary, 다음으로 deeper explanation을 둡니다.
- 단순히 기능적인 렌더링이 아니라 우아한 보고서 디자인을 목표로 합니다. typography, spacing, 섹션 리듬, 카드 구성이 headline insight에서 상세 근거로 자연스럽게 이어지게 해야 합니다.

## 흔한 실수

- 연속형 분포에 bar chart 사용
- effect size 없이 significance star만 표시
- 너무 많은 변수를 하나의 heatmap 또는 scatter matrix에 표시
- 정규화 없이 크기가 매우 다른 그룹의 raw count를 직접 비교

## 좋은 발견사항 패턴

“Segment A 고객은 tenure와 channel을 통제한 뒤에도 Segment B보다 약 18% 더 많이 지출하지만, 최신 cohort에서는 샘플 수가 작아 추정치가 불안정하다.”
