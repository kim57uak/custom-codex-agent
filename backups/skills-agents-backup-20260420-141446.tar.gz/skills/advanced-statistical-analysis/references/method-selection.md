# 방법 선택

## 연속형 결과

- 하나의 그룹 vs 기준값: 가정이 합리적이면 one-sample t-test
- 독립된 두 그룹: 기본은 Welch t-test
- paired observation: paired t-test
- 세 그룹 이상: ANOVA 후 post-hoc comparison
- 작은 샘플에서 강한 비정규성이나 이상치가 있으면 Mann-Whitney, Wilcoxon, Kruskal-Wallis
- 여러 드라이버가 있으면 residual diagnostic을 포함한 OLS 또는 regularized regression

## 이진 결과

- 두 categorical 변수: chi-square 또는 Fisher exact
- 확률 모델링: logistic regression
- 강한 불균형이면 accuracy만 보지 말고 PR curve와 calibration 사용

## 카운트 결과

- 분산이 평균과 비슷하면 Poisson
- 과산포가 크면 negative binomial

## 시계열

- 가능하면 예측 전에 decomposition을 수행합니다.
- cadence, 누락된 timestamp, 계절성을 점검합니다.
- ARIMA 계열 모델 전에 단순 추세/계절성 baseline을 우선합니다.

## 세분화와 구조 탐색

- 상관된 numeric feature와 구조 탐색에는 PCA
- 스케일링과 feature 검토 이후에만 clustering
- silhouette score만이 아니라 cluster stability와 비즈니스 의미를 함께 보고

## 인과 해석 주의

- 상관은 인과가 아닙니다.
- observational data는 명확한 식별 전략이 있을 때만 인과적 언어를 허용합니다.
- 식별 전략이 없으면 결과를 연관 또는 predictive driver로 표현합니다.
