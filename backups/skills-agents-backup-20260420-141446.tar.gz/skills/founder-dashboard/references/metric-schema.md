# Metric JSON Schema

```json
{
  "revenue": 12000000,
  "leads": 35,
  "proposals": 12,
  "close_rate": 0.25,
  "runway_months": 4,
  "overdue_invoices": 1
}
```
