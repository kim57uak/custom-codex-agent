---
name: "founder-dashboard"
description: "1인기업 경영 지표를 주간/월간으로 요약하는 운영 대시보드를 만들 때 사용합니다. 매출, 리드, 전환율, 현금흐름, 실행 과제를 한 화면에서 의사결정용으로 점검해야 할 때 트리거됩니다."
---

# Founder Dashboard

## 운영 오너
- 정산팀

## 빠른 실행
- 입력 스키마: `references/metric-schema.md`
- 실행:
```bash
python3 scripts/build_founder_dashboard.py \
  --input weekly_metrics.json \
  --out founder_dashboard.md
```

## 워크플로
1. 주간 지표 JSON을 업데이트합니다.
2. 스크립트로 KPI/경고/다음 액션 섹션을 생성합니다.
3. 경고 항목에 대해 실행 책임자와 마감일을 확정합니다.

## 품질 기준
- KPI 정의가 바뀌면 버전 이력을 남깁니다.
- 대시보드는 10분 내 의사결정 가능해야 합니다.

## 파일 입력 처리
- 입력이 파일일 때는 먼저 `scripts/extract_text_from_file.py`로 텍스트를 추출합니다.
- 지원 형식: `txt,pdf,ppt,pptx,doc,docx,excel(xls/xlsx),md,html`
- 실행 예시:
```bash
python3 scripts/extract_text_from_file.py --input ./input/source.docx --output ./tmp/source.txt
```
- 추출 텍스트를 바탕으로 각 스킬의 본 스크립트(견적/정산/분류/분석)를 실행합니다.

## 파일 입력 유효성 체크

- 이 스킬의 현재 요청이 파일 입력 없이도 수행 가능한 범위라면, 파일 경로를 요구하지 말고 바로 작업을 진행합니다.
- 사용자가 문서/코드/계약서 본문을 메시지에 직접 제공한 경우에는 파일 경로 없이도 해당 텍스트로 작업을 진행합니다.
- 특정 파일의 실제 내용을 읽어야만 작업이 가능한 경우에만, **파일 경로 + 파일명** 제공 여부를 확인합니다.
- 파일 경로 또는 파일명이 누락된 경우에는 파일 작업을 진행하지 않고, 사용자에게 정확한 파일 경로와 파일명을 먼저 요청합니다.
- 경로가 모호한 표현(예: "그 파일", "지난번 문서")만 있는 경우에도 동일하게 명시 경로를 요청합니다.

