# Founder Weekly Dashboard

## KPI
- Revenue: 15,000,000
- Leads: 42
- Proposals: 15
- Close Rate: 21.0%
- Runway (months): 4
- Overdue Invoices: 1

## Alerts
- 미수금 존재: 리마인드 및 결제조건 조정 필요

## Next Actions
- 이번 주 핵심 액션 3개를 우선순위로 정리
