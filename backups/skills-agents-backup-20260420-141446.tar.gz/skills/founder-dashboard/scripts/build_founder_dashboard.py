#!/usr/bin/env python3
import argparse
import json
from pathlib import Path

THRESHOLDS = {
    "close_rate_min": 0.2,
    "runway_months_min": 3,
    "overdue_invoices_max": 0,
}


def main() -> None:
    p = argparse.ArgumentParser(description="Build weekly founder dashboard markdown from metric JSON")
    p.add_argument("--input", required=True)
    p.add_argument("--out", default="founder_dashboard.md")
    args = p.parse_args()

    m = json.loads(Path(args.input).read_text(encoding="utf-8"))
    alerts = []
    if float(m.get("close_rate", 0)) < THRESHOLDS["close_rate_min"]:
        alerts.append("수주율 저하: 제안 품질/타겟 재점검 필요")
    if float(m.get("runway_months", 0)) < THRESHOLDS["runway_months_min"]:
        alerts.append("현금 런웨이 부족: 비용 통제와 선입금 조건 강화 필요")
    if int(m.get("overdue_invoices", 0)) > THRESHOLDS["overdue_invoices_max"]:
        alerts.append("미수금 존재: 리마인드 및 결제조건 조정 필요")

    lines = [
        "# Founder Weekly Dashboard",
        "",
        "## KPI",
        f"- Revenue: {m.get('revenue', 0):,}",
        f"- Leads: {m.get('leads', 0)}",
        f"- Proposals: {m.get('proposals', 0)}",
        f"- Close Rate: {float(m.get('close_rate', 0))*100:.1f}%",
        f"- Runway (months): {m.get('runway_months', 0)}",
        f"- Overdue Invoices: {m.get('overdue_invoices', 0)}",
        "",
        "## Alerts",
    ]
    lines += [f"- {a}" for a in alerts] if alerts else ["- 없음"]
    lines += ["", "## Next Actions", "- 이번 주 핵심 액션 3개를 우선순위로 정리"]

    Path(args.out).write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
