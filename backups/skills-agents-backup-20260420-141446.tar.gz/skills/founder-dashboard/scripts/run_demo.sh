#!/bin/zsh
set -euo pipefail
DIR="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$DIR/output"
mkdir -p "$OUT"
python3 "$DIR/scripts/build_founder_dashboard.py" --input "$DIR/assets/sample_weekly_metrics.json" --out "$OUT/founder_dashboard.md"
echo "Generated: $OUT/founder_dashboard.md"
