---
name: "invoice-tax-workflow"
description: "청구서 발행, 입금 추적, 미수금 리마인드, 월말 정산까지 1인기업의 정산 루틴을 표준화할 때 사용합니다. 거래별 청구 상태를 관리하고 세금 관련 증빙을 정리해야 할 때 트리거됩니다."
---

# Invoice Tax Workflow

## 운영 오너
- 정산팀

## 빠른 실행
- 입력 스키마: `references/ledger-schema.md`
- 실행:
```bash
python3 scripts/run_invoice_workflow.py \
  --ledger ledger.csv \
  --summary-out settlement_summary.md \
  --reminder-out reminders.md
```

## 워크플로
1. `ledger.csv`를 최신 상태로 유지합니다.
2. 스크립트로 정산 요약과 미수 리마인드 메시지를 생성합니다.
3. 월말 마감 전에 연체 건과 미수 합계를 확인합니다.

## 품질 기준
- 총 청구/총 수납/미수금 계산이 일치해야 합니다.
- 만기일 포맷은 `YYYY-MM-DD`를 고정합니다.

## 파일 입력 처리
- 입력이 파일일 때는 먼저 `scripts/extract_text_from_file.py`로 텍스트를 추출합니다.
- 지원 형식: `txt,pdf,ppt,pptx,doc,docx,excel(xls/xlsx),md,html`
- 실행 예시:
```bash
python3 scripts/extract_text_from_file.py --input ./input/source.docx --output ./tmp/source.txt
```
- 추출 텍스트를 바탕으로 각 스킬의 본 스크립트(견적/정산/분류/분석)를 실행합니다.

## 파일 입력 유효성 체크

- 이 스킬의 현재 요청이 파일 입력 없이도 수행 가능한 범위라면, 파일 경로를 요구하지 말고 바로 작업을 진행합니다.
- 사용자가 문서/코드/계약서 본문을 메시지에 직접 제공한 경우에는 파일 경로 없이도 해당 텍스트로 작업을 진행합니다.
- 특정 파일의 실제 내용을 읽어야만 작업이 가능한 경우에만, **파일 경로 + 파일명** 제공 여부를 확인합니다.
- 파일 경로 또는 파일명이 누락된 경우에는 파일 작업을 진행하지 않고, 사용자에게 정확한 파일 경로와 파일명을 먼저 요청합니다.
- 경로가 모호한 표현(예: "그 파일", "지난번 문서")만 있는 경우에도 동일하게 명시 경로를 요청합니다.

