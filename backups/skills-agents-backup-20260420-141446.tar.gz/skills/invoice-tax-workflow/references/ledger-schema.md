# Ledger CSV Schema

Required columns:
- `invoice_id`
- `client`
- `due_date` (`YYYY-MM-DD`)
- `total`
- `status` (`issued`, `partial`, `paid`)
- `paid_amount`
