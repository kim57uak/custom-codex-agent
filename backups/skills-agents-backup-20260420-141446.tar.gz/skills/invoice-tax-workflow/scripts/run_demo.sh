#!/bin/zsh
set -euo pipefail
DIR="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$DIR/output"
mkdir -p "$OUT"
python3 "$DIR/scripts/run_invoice_workflow.py" --ledger "$DIR/assets/sample_ledger.csv" --summary-out "$OUT/settlement_summary.md" --reminder-out "$OUT/reminders.md"
echo "Generated: $OUT/settlement_summary.md, $OUT/reminders.md"
