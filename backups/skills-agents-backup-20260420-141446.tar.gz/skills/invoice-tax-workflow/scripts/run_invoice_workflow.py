#!/usr/bin/env python3
import argparse
import csv
from datetime import date, datetime
from pathlib import Path


def parse_date(v: str) -> date:
    return datetime.strptime(v, "%Y-%m-%d").date()


def main() -> None:
    p = argparse.ArgumentParser(description="Generate AR summary and reminder messages from invoice ledger CSV")
    p.add_argument("--ledger", required=True, help="CSV columns: invoice_id,client,due_date,total,status,paid_amount")
    p.add_argument("--summary-out", default="settlement_summary.md")
    p.add_argument("--reminder-out", default="reminders.md")
    args = p.parse_args()

    today = date.today()
    rows = list(csv.DictReader(Path(args.ledger).read_text(encoding="utf-8").splitlines()))

    total_billed = 0
    total_paid = 0
    overdue = []
    reminder_lines = ["# 미수 리마인드 메시지", ""]

    for r in rows:
        total = int(float(r.get("total", "0") or 0))
        paid = int(float(r.get("paid_amount", "0") or 0))
        status = (r.get("status", "").strip() or "issued").lower()
        due = parse_date(r["due_date"])
        total_billed += total
        total_paid += paid

        if status != "paid" and due < today:
            overdue_amt = max(total - paid, 0)
            overdue.append((r["invoice_id"], r["client"], due.isoformat(), overdue_amt))
            reminder_lines += [
                f"## {r['invoice_id']} / {r['client']}",
                f"안녕하세요. {due.isoformat()} 만기 건 미입금 금액 {overdue_amt:,}원 확인 부탁드립니다.",
                "",
            ]

    outstanding = max(total_billed - total_paid, 0)
    summary = [
        "# 월말 정산 요약",
        "",
        f"- 총 청구: {total_billed:,}원",
        f"- 총 수납: {total_paid:,}원",
        f"- 미수금: {outstanding:,}원",
        f"- 연체 건수: {len(overdue)}건",
        "",
        "## 연체 목록",
    ]
    if overdue:
        for i, c, d, a in overdue:
            summary.append(f"- {i} | {c} | 만기 {d} | 미수 {a:,}원")
    else:
        summary.append("- 없음")

    Path(args.summary_out).write_text("\n".join(summary) + "\n", encoding="utf-8")
    Path(args.reminder_out).write_text("\n".join(reminder_lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
