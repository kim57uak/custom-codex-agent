# 경쟁사 변화 리포트

## 신규
- 없음

## 삭제
- 없음

## 변경
- Alpha::message: '팀 협업 중심' -> 'AI 자동화 중심'
- Alpha::pricing: 'Starter 49' -> 'Starter 59'
