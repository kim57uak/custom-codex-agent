---
name: "competitor-watch"
description: "경쟁사 가격, 기능, 메시지, 프로모션 변화를 주기적으로 추적하고 대응 액션을 도출할 때 사용합니다. 마케팅/영업 전략 업데이트를 위해 경쟁 동향 요약이 필요할 때 트리거됩니다."
---

# Competitor Watch

## 운영 오너
- 마케팅팀

## 빠른 실행
- 입력 스키마: `references/snapshot-schema.md`
- 실행:
```bash
python3 scripts/build_competitor_delta.py \
  --prev prev_snapshot.json \
  --curr curr_snapshot.json \
  --out competitor_changes.md
```

## 워크플로
1. 이전/현재 스냅샷 JSON을 준비합니다.
2. 스크립트로 신규/삭제/변경 항목을 자동 추출합니다.
3. 영향도와 대응 액션을 리포트 하단에 수동 추가합니다.

## 품질 기준
- 사실과 해석을 분리해 기록합니다.
- 모든 변화 항목에 출처 수집 시점을 남깁니다.

## 파일 입력 처리
- 입력이 파일일 때는 먼저 `scripts/extract_text_from_file.py`로 텍스트를 추출합니다.
- 지원 형식: `txt,pdf,ppt,pptx,doc,docx,excel(xls/xlsx),md,html`
- 실행 예시:
```bash
python3 scripts/extract_text_from_file.py --input ./input/source.docx --output ./tmp/source.txt
```
- 추출 텍스트를 바탕으로 각 스킬의 본 스크립트(견적/정산/분류/분석)를 실행합니다.

## 파일 입력 유효성 체크

- 이 스킬의 현재 요청이 파일 입력 없이도 수행 가능한 범위라면, 파일 경로를 요구하지 말고 바로 작업을 진행합니다.
- 사용자가 문서/코드/계약서 본문을 메시지에 직접 제공한 경우에는 파일 경로 없이도 해당 텍스트로 작업을 진행합니다.
- 특정 파일의 실제 내용을 읽어야만 작업이 가능한 경우에만, **파일 경로 + 파일명** 제공 여부를 확인합니다.
- 파일 경로 또는 파일명이 누락된 경우에는 파일 작업을 진행하지 않고, 사용자에게 정확한 파일 경로와 파일명을 먼저 요청합니다.
- 경로가 모호한 표현(예: "그 파일", "지난번 문서")만 있는 경우에도 동일하게 명시 경로를 요청합니다.

