# Snapshot JSON Schema

Array of objects:

```json
[
  {"competitor": "A", "field": "pricing", "value": "Starter $49"},
  {"competitor": "A", "field": "message", "value": "For teams"}
]
```
