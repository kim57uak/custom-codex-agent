#!/bin/zsh
set -euo pipefail
DIR="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$DIR/output"
mkdir -p "$OUT"
python3 "$DIR/scripts/build_competitor_delta.py" --prev "$DIR/assets/sample_prev_snapshot.json" --curr "$DIR/assets/sample_curr_snapshot.json" --out "$OUT/competitor_changes.md"
echo "Generated: $OUT/competitor_changes.md"
