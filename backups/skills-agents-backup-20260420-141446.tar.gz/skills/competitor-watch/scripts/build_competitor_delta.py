#!/usr/bin/env python3
import argparse
import json
from pathlib import Path


def to_map(items):
    return {f"{i.get('competitor')}::{i.get('field')}": i.get('value') for i in items}


def main() -> None:
    p = argparse.ArgumentParser(description="Generate competitor change report from previous/current snapshots")
    p.add_argument("--prev", required=True)
    p.add_argument("--curr", required=True)
    p.add_argument("--out", default="competitor_changes.md")
    args = p.parse_args()

    prev = to_map(json.loads(Path(args.prev).read_text(encoding="utf-8")))
    curr = to_map(json.loads(Path(args.curr).read_text(encoding="utf-8")))

    added = sorted(set(curr) - set(prev))
    removed = sorted(set(prev) - set(curr))
    changed = sorted(k for k in set(curr) & set(prev) if curr[k] != prev[k])

    lines = ["# 경쟁사 변화 리포트", "", "## 신규", *([f"- {k}: {curr[k]}" for k in added] or ["- 없음"]), "", "## 삭제", *([f"- {k}: {prev[k]}" for k in removed] or ["- 없음"]), "", "## 변경"]
    lines += [f"- {k}: '{prev[k]}' -> '{curr[k]}'" for k in changed] or ["- 없음"]

    Path(args.out).write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
