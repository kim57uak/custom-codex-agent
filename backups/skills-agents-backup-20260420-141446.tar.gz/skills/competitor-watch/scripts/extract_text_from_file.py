#!/usr/bin/env python3
from __future__ import annotations

import argparse
import html
import io
import re
import subprocess
import sys
import zipfile
from html.parser import HTMLParser
from pathlib import Path


def _read_plain(path: Path) -> str:
    for enc in ("utf-8", "cp949", "euc-kr", "latin-1"):
        try:
            return path.read_text(encoding=enc)
        except UnicodeDecodeError:
            continue
    return path.read_text(errors="replace")


class _HTMLTextExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.parts: list[str] = []

    def handle_data(self, data: str) -> None:
        if data and data.strip():
            self.parts.append(data.strip())

    def text(self) -> str:
        return "\n".join(self.parts)


def _read_html(path: Path) -> str:
    raw = _read_plain(path)
    parser = _HTMLTextExtractor()
    parser.feed(raw)
    return html.unescape(parser.text())


def _xml_text(xml_bytes: bytes) -> str:
    text = re.sub(rb"<[^>]+>", b" ", xml_bytes)
    return re.sub(r"\s+", " ", text.decode("utf-8", errors="replace")).strip()


def _read_docx(path: Path) -> str:
    with zipfile.ZipFile(path, "r") as z:
        xml = z.read("word/document.xml")
    return _xml_text(xml)


def _read_pptx(path: Path) -> str:
    lines: list[str] = []
    with zipfile.ZipFile(path, "r") as z:
        slide_names = sorted(n for n in z.namelist() if n.startswith("ppt/slides/slide") and n.endswith(".xml"))
        for name in slide_names:
            lines.append(_xml_text(z.read(name)))
    return "\n".join(filter(None, lines))


def _read_xlsx(path: Path) -> str:
    try:
        import openpyxl  # type: ignore

        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        out: list[str] = []
        for ws in wb.worksheets:
            out.append(f"# Sheet: {ws.title}")
            for row in ws.iter_rows(values_only=True):
                vals = [str(v) for v in row if v is not None and str(v).strip()]
                if vals:
                    out.append("\t".join(vals))
        return "\n".join(out)
    except Exception as err:
        raise RuntimeError(
            "xlsx 읽기 실패. openpyxl 설치가 필요할 수 있습니다. 예: python3 -m pip install openpyxl"
        ) from err


def _run_external(cmd: list[str], path: Path, tool_name: str) -> str:
    try:
        result = subprocess.run(cmd + [str(path)], check=True, capture_output=True, text=True)
        return result.stdout.strip()
    except FileNotFoundError as err:
        raise RuntimeError(f"{tool_name} 도구가 없어 {path.suffix} 파일을 읽을 수 없습니다.") from err
    except subprocess.CalledProcessError as err:
        raise RuntimeError(f"{tool_name} 실행 실패: {err.stderr.strip() or err}") from err


def _read_pdf(path: Path) -> str:
    try:
        from pypdf import PdfReader  # type: ignore

        reader = PdfReader(str(path))
        chunks: list[str] = []
        for page in reader.pages:
            chunks.append(page.extract_text() or "")
        return "\n".join(chunks).strip()
    except Exception:
        try:
            import pdfplumber  # type: ignore

            chunks: list[str] = []
            with pdfplumber.open(str(path)) as pdf:
                for page in pdf.pages:
                    chunks.append(page.extract_text() or "")
            return "\n".join(chunks).strip()
        except Exception as err:
            raise RuntimeError(
                "pdf 읽기 실패. pypdf 또는 pdfplumber 설치가 필요할 수 있습니다. 예: python3 -m pip install pypdf pdfplumber"
            ) from err


def extract_text(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix in {".txt", ".md", ".csv", ".json", ".yaml", ".yml"}:
        return _read_plain(path)
    if suffix in {".html", ".htm"}:
        return _read_html(path)
    if suffix == ".pdf":
        return _read_pdf(path)
    if suffix == ".docx":
        return _read_docx(path)
    if suffix == ".pptx":
        return _read_pptx(path)
    if suffix in {".xlsx", ".xlsm"}:
        return _read_xlsx(path)
    if suffix == ".doc":
        return _run_external(["antiword"], path, "antiword")
    if suffix == ".ppt":
        return _run_external(["catppt"], path, "catppt")
    if suffix == ".xls":
        try:
            import xlrd  # type: ignore

            wb = xlrd.open_workbook(str(path))
            out: list[str] = []
            for i in range(wb.nsheets):
                sh = wb.sheet_by_index(i)
                out.append(f"# Sheet: {sh.name}")
                for r in range(sh.nrows):
                    vals = [str(v) for v in sh.row_values(r) if str(v).strip()]
                    if vals:
                        out.append("\t".join(vals))
            return "\n".join(out)
        except Exception as err:
            raise RuntimeError(
                "xls 읽기 실패. xlrd 설치가 필요할 수 있습니다. 예: python3 -m pip install xlrd"
            ) from err
    raise RuntimeError(f"지원하지 않는 파일 형식: {suffix}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Extract text from txt,pdf,ppt,pptx,doc,docx,excel,md,html")
    parser.add_argument("--input", required=True, help="Input file path")
    parser.add_argument("--output", required=False, help="Output text path. default: <input>.extracted.txt")
    args = parser.parse_args()

    src = Path(args.input)
    if not src.exists() or not src.is_file():
        raise SystemExit(f"입력 파일을 찾을 수 없습니다: {src}")

    text = extract_text(src)
    out = Path(args.output) if args.output else src.with_suffix(src.suffix + ".extracted.txt")
    out.write_text(text + "\n", encoding="utf-8")
    print(out)


if __name__ == "__main__":
    main()
