---
name: pptx-generator
description: Create polished, business-ready presentations from a structured brief, including direct `.pptx` generation and HTML-first slide design with image-rich layouts that can be converted into `.pptx`. Use when Codex needs to plan, draft, or generate commercial presentations such as sales decks, executive updates, proposals, training decks, product overviews, investor-style summaries, or internal strategy presentations, especially when output quality, visual control, screenshots, or HTML to PPTX conversion matter.
---

# PPTX Generator

Use this skill to turn a presentation brief into:

- a commercial-grade HTML slide deck with strong visual direction
- a screenshot-based `.pptx` assembled from rendered HTML slides

For final business delivery, do not skip the HTML stage.

## Quick Start

1. Capture the presentation brief before drafting slides. Do not invent missing business-critical facts.
2. If the audience, objective, or desired outcome is unclear, stop and ask.
3. Build slides in HTML first using `references/html-brief-schema.md` with `scripts/build_html_presentation.py`.
4. Render one screenshot per slide and convert to `.pptx` with `scripts/images_to_pptx.py`.
5. Deliver the `.pptx` converted from HTML slides.
6. Review the generated output. If it shows density, copy, or slide-structure problems, fix the brief and regenerate.

## Brief Intake Rules

Collect these inputs before generating a deck:

- deck objective: what decision, action, or understanding the deck should drive
- audience: executive, client, partner, investor, internal team, training cohort, etc.
- presenter context: speaker, company, and delivery context
- tone: formal, consultative, analytical, persuasive, instructional
- brand constraints: colors, logos, preferred typefaces, or template requirements
- output constraints: slide count, language, aspect ratio, and deadline

Treat the following as required. If any are missing, ask instead of guessing:

- the primary audience
- the single most important takeaway
- whether the deck is external-facing or internal-only

## Quality Bar

Aim for business presentation quality, not generic AI filler.

- Keep one idea per slide.
- Prefer short assertion-style titles over topic labels.
- Keep bullets parallel, concrete, and decision-oriented.
- Avoid more than 5 bullets on one slide.
- Avoid bullets longer than roughly 110 characters.
- Prefer evidence, comparisons, or next-step framing over vague adjectives.
- Reserve dense detail for speaker notes or appendix slides.
- Keep wording suitable for direct client or executive review.

For fuller rules, read `references/quality-bar.md`.

## Workflow

### 1. Structure the narrative

Use a simple business arc:

1. context or opening
2. core argument or diagnosis
3. recommendation or plan
4. proof, implications, or next steps

If the user already has a detailed outline, preserve it and only tighten the copy.

### 2. Use HTML-first as the default build path

For commercial-quality output, always use HTML-first and then convert to `.pptx`.

Only allow direct `.pptx` generation when the user explicitly asks for a fast internal draft and accepts reduced design fidelity.

### 3. Choose slide types deliberately

Use the slide types in `references/html-brief-schema.md`, especially:

- `visual`
- `image-compare`

### 4. Generate from a brief

Create a JSON file and run:

```bash
python3 scripts/build_html_presentation.py --input brief.json --output deck.html
```

Then render the HTML and convert screenshots into `.pptx`:

```bash
python3 scripts/images_to_pptx.py --input-dir slide-images --output deck.pptx
```

When using Playwright MCP, open the local `deck.html`, capture each `.slide` at 1280x720, and name the images in presentation order such as `01.png`, `02.png`, `03.png`.

If a `.pptx` is requested, this conversion step is mandatory for final delivery.

### 5. Handle images deliberately

- Prefer meaningful images over generic stock visuals.
- Use user-provided or licensed assets when available.
- If the user asks for suitable images and does not provide them, search or generate only images that materially reinforce the slide message.
- Prefer maps, product screenshots, diagrams, infrastructure photos, facility photos, or exported charts over abstract decoration.
- Keep captions and credits short and factual.

### 6. Review before delivery

Check:

- title wording is assertive and specific
- slide order supports the message arc
- no slide is overloaded
- branding and tone fit the audience
- images support the argument instead of filling space
- closing slide contains a clear ask, takeaway, or next step

## Commercial-Use Guardrails

This skill is designed for commercial-grade output, but it cannot legally or objectively guarantee suitability in every business context. Treat the deck as production-oriented only after review against the brief, the brand rules, and any legal or regulatory requirements the user is subject to.

When the request implies high stakes, do not skip human review for:

- regulated claims
- financial forecasts
- legal commitments
- client-specific confidential information
- copyrighted brand assets supplied by third parties

## Resources

### `scripts/build_presentation.py`

Generate a direct `.pptx` deck from a JSON brief. Use only for explicitly requested internal drafts where HTML-first flow is intentionally waived.

### `scripts/build_html_presentation.py`

Generate a self-contained HTML slide deck from a JSON brief. Use this when the deck needs visual layouts, image panels, or HTML review before packaging.

### `scripts/images_to_pptx.py`

Convert ordered slide screenshots into a `.pptx` deck. Use this after rendering the HTML deck in a browser or with Playwright MCP.

### `references/brief-schema.md`

Use this as the contract for the input brief.

### `references/html-brief-schema.md`

Use this when building HTML-first decks with image-led slides.

### `references/quality-bar.md`

Use this when tightening copy or deciding whether a deck is client-ready.

## 파일 입력 유효성 체크

- 이 스킬의 현재 요청이 파일 입력 없이도 수행 가능한 범위라면, 파일 경로를 요구하지 말고 바로 작업을 진행합니다.
- 사용자가 문서/코드/계약서 본문을 메시지에 직접 제공한 경우에는 파일 경로 없이도 해당 텍스트로 작업을 진행합니다.
- 특정 파일의 실제 내용을 읽어야만 작업이 가능한 경우에만, **파일 경로 + 파일명** 제공 여부를 확인합니다.
- 파일 경로 또는 파일명이 누락된 경우에는 파일 작업을 진행하지 않고, 사용자에게 정확한 파일 경로와 파일명을 먼저 요청합니다.
- 경로가 모호한 표현(예: "그 파일", "지난번 문서")만 있는 경우에도 동일하게 명시 경로를 요청합니다.

