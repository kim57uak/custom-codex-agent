#!/usr/bin/env python3
"""Build a polished business PPTX deck from a JSON brief."""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any


def fail(message: str) -> "NoReturn":
    print(f"ERROR: {message}", file=sys.stderr)
    raise SystemExit(1)


Presentation = None
RGBColor = None
MSO_AUTO_SHAPE_TYPE = None
PP_ALIGN = None
Inches = None
Pt = None


DEFAULT_THEME = {
    "primary_color": "#173F5F",
    "accent_color": "#F6AE2D",
    "background_color": "#F7F8FA",
    "text_color": "#14213D",
    "font_family": "Aptos",
}

SUPPORTED_TYPES = {"title", "section", "bullets", "two-column", "quote", "closing"}
PLACEHOLDER_RE = re.compile(r"\b(todo|lorem ipsum|tbd|placeholder)\b", re.IGNORECASE)


@dataclass
class Theme:
    primary_color: RGBColor
    accent_color: RGBColor
    background_color: RGBColor
    text_color: RGBColor
    font_family: str


def load_pptx_dependencies() -> None:
    global Presentation, RGBColor, MSO_AUTO_SHAPE_TYPE, PP_ALIGN, Inches, Pt
    try:
        from pptx import Presentation as _Presentation
        from pptx.dml.color import RGBColor as _RGBColor
        from pptx.enum.shapes import MSO_AUTO_SHAPE_TYPE as _MSO_AUTO_SHAPE_TYPE
        from pptx.enum.text import PP_ALIGN as _PP_ALIGN
        from pptx.util import Inches as _Inches, Pt as _Pt
    except ImportError:  # pragma: no cover - dependency guard
        fail(
            "python-pptx is not installed. Install it with "
            "`python3 -m pip install python-pptx pillow` and rerun."
        )

    Presentation = _Presentation
    RGBColor = _RGBColor
    MSO_AUTO_SHAPE_TYPE = _MSO_AUTO_SHAPE_TYPE
    PP_ALIGN = _PP_ALIGN
    Inches = _Inches
    Pt = _Pt


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Generate a business-ready PowerPoint deck from a JSON brief."
    )
    parser.add_argument("--input", required=True, help="Path to the JSON brief")
    parser.add_argument("--output", required=True, help="Path to the output .pptx file")
    parser.add_argument(
        "--allow-overflow",
        action="store_true",
        help="Allow dense slides instead of failing validation.",
    )
    return parser.parse_args()


def hex_to_rgb(value: str) -> RGBColor:
    normalized = value.strip().lstrip("#")
    if not re.fullmatch(r"[0-9a-fA-F]{6}", normalized):
        fail(f"Invalid hex color: {value}")
    return RGBColor.from_string(normalized.upper())


def load_brief(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        fail(f"Input file not found: {path}")
    except json.JSONDecodeError as exc:
        fail(f"Invalid JSON in {path}: {exc}")
    if not isinstance(data, dict):
        fail("Top-level brief must be a JSON object")
    return data


def require_non_empty(mapping: dict[str, Any], key: str) -> str:
    value = mapping.get(key)
    if not isinstance(value, str) or not value.strip():
        fail(f"Missing required string field: {key}")
    return value.strip()


def validate_text(text: str, field_name: str) -> None:
    if PLACEHOLDER_RE.search(text):
        fail(f"Field {field_name} contains placeholder text: {text!r}")


def validate_bullets(bullets: Any, field_name: str) -> list[str]:
    if not isinstance(bullets, list) or not bullets:
        fail(f"{field_name} must be a non-empty list")
    cleaned: list[str] = []
    for idx, item in enumerate(bullets, start=1):
        if not isinstance(item, str) or not item.strip():
            fail(f"{field_name}[{idx}] must be a non-empty string")
        text = item.strip()
        validate_text(text, f"{field_name}[{idx}]")
        cleaned.append(text)
    return cleaned


def validate_brief(data: dict[str, Any], allow_overflow: bool) -> list[str]:
    meta = data.get("meta")
    if not isinstance(meta, dict):
        fail("meta must be an object")
    require_non_empty(meta, "title")
    require_non_empty(meta, "audience")
    require_non_empty(meta, "objective")

    slides = data.get("slides")
    if not isinstance(slides, list) or not slides:
        fail("slides must be a non-empty array")

    warnings: list[str] = []
    seen_titles: set[str] = set()
    for idx, slide in enumerate(slides, start=1):
        if not isinstance(slide, dict):
            fail(f"slides[{idx}] must be an object")
        slide_type = require_non_empty(slide, "type")
        if slide_type not in SUPPORTED_TYPES:
            fail(f"slides[{idx}] has unsupported type: {slide_type}")
        title = require_non_empty(slide, "title")
        validate_text(title, f"slides[{idx}].title")
        lowered_title = title.casefold()
        if lowered_title in seen_titles:
            fail(f"Duplicate slide title: {title}")
        seen_titles.add(lowered_title)

        if len(title) > 70:
            warnings.append(f"slides[{idx}] title is long and may wrap poorly")

        if slide_type == "bullets":
            bullets = validate_bullets(slide.get("bullets"), f"slides[{idx}].bullets")
            if len(bullets) > 5 and not allow_overflow:
                fail(f"slides[{idx}] has more than 5 bullets")
            for bullet in bullets:
                if len(bullet) > 110:
                    warnings.append(f"slides[{idx}] bullet may be too long for a clean layout")
        elif slide_type == "two-column":
            validate_bullets(slide.get("left_bullets"), f"slides[{idx}].left_bullets")
            validate_bullets(slide.get("right_bullets"), f"slides[{idx}].right_bullets")
            require_non_empty(slide, "left_title")
            require_non_empty(slide, "right_title")
        elif slide_type == "section":
            require_non_empty(slide, "body")
        elif slide_type == "quote":
            require_non_empty(slide, "quote")
        elif slide_type == "closing":
            require_non_empty(slide, "body")

    if len(slides) > 20:
        warnings.append("Deck has more than 20 slides; check whether it should be split")
    return warnings


def build_theme(data: dict[str, Any]) -> Theme:
    theme_in = data.get("theme") if isinstance(data.get("theme"), dict) else {}
    merged = {**DEFAULT_THEME, **theme_in}
    return Theme(
        primary_color=hex_to_rgb(merged["primary_color"]),
        accent_color=hex_to_rgb(merged["accent_color"]),
        background_color=hex_to_rgb(merged["background_color"]),
        text_color=hex_to_rgb(merged["text_color"]),
        font_family=str(merged["font_family"]).strip() or DEFAULT_THEME["font_family"],
    )


def set_background(slide, rgb: RGBColor) -> None:
    fill = slide.background.fill
    fill.solid()
    fill.fore_color.rgb = rgb


def add_textbox(slide, left: float, top: float, width: float, height: float, text: str):
    return slide.shapes.add_textbox(Inches(left), Inches(top), Inches(width), Inches(height))


def style_paragraph(paragraph, theme: Theme, size: int, bold: bool = False) -> None:
    paragraph.font.name = theme.font_family
    paragraph.font.size = Pt(size)
    paragraph.font.bold = bold
    paragraph.font.color.rgb = theme.text_color


def add_title_bar(slide, theme: Theme) -> None:
    shape = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.RECTANGLE, Inches(0), Inches(0), Inches(13.333), Inches(0.18)
    )
    fill = shape.fill
    fill.solid()
    fill.fore_color.rgb = theme.accent_color
    shape.line.fill.background()


def render_title_slide(prs: Presentation, slide_data: dict[str, Any], meta: dict[str, Any], theme: Theme) -> None:
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_background(slide, theme.background_color)
    add_title_bar(slide, theme)

    title_box = add_textbox(slide, 0.9, 1.2, 11.5, 1.7, slide_data["title"])
    p = title_box.text_frame.paragraphs[0]
    p.text = slide_data["title"]
    style_paragraph(p, theme, 28, bold=True)

    subtitle = slide_data.get("subtitle") or meta.get("subtitle", "")
    if subtitle:
        sub_box = add_textbox(slide, 0.95, 3.0, 10.5, 0.8, subtitle)
        p = sub_box.text_frame.paragraphs[0]
        p.text = subtitle
        style_paragraph(p, theme, 16)

    footer_text = " | ".join(filter(None, [meta.get("company"), meta.get("author"), meta.get("audience")]))
    if footer_text:
        footer = add_textbox(slide, 0.95, 6.6, 10.5, 0.4, footer_text)
        p = footer.text_frame.paragraphs[0]
        p.text = footer_text
        style_paragraph(p, theme, 10)


def render_section_slide(prs: Presentation, slide_data: dict[str, Any], theme: Theme) -> None:
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_background(slide, theme.primary_color)
    title = add_textbox(slide, 0.9, 1.6, 11.5, 1.4, slide_data["title"])
    p = title.text_frame.paragraphs[0]
    p.text = slide_data["title"]
    p.font.name = theme.font_family
    p.font.size = Pt(26)
    p.font.bold = True
    p.font.color.rgb = RGBColor(255, 255, 255)

    eyebrow = slide_data.get("eyebrow")
    if eyebrow:
        box = add_textbox(slide, 0.95, 0.9, 4.5, 0.4, eyebrow)
        p = box.text_frame.paragraphs[0]
        p.text = eyebrow
        p.font.name = theme.font_family
        p.font.size = Pt(11)
        p.font.bold = True
        p.font.color.rgb = theme.accent_color

    body = add_textbox(slide, 0.95, 3.3, 10.5, 1.5, slide_data["body"])
    p = body.text_frame.paragraphs[0]
    p.text = slide_data["body"]
    p.font.name = theme.font_family
    p.font.size = Pt(16)
    p.font.color.rgb = RGBColor(245, 245, 245)


def render_bullets_slide(prs: Presentation, slide_data: dict[str, Any], theme: Theme) -> None:
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_background(slide, theme.background_color)
    add_title_bar(slide, theme)
    title = add_textbox(slide, 0.9, 0.7, 11.2, 0.8, slide_data["title"])
    p = title.text_frame.paragraphs[0]
    p.text = slide_data["title"]
    style_paragraph(p, theme, 22, bold=True)

    body = add_textbox(slide, 1.0, 1.8, 11.0, 4.8, "")
    tf = body.text_frame
    tf.word_wrap = True
    for idx, bullet in enumerate(slide_data["bullets"]):
        paragraph = tf.paragraphs[0] if idx == 0 else tf.add_paragraph()
        paragraph.level = 0
        paragraph.space_after = Pt(10)
        paragraph.text = f"• {bullet}"
        style_paragraph(paragraph, theme, 16)


def render_two_column_slide(prs: Presentation, slide_data: dict[str, Any], theme: Theme) -> None:
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_background(slide, theme.background_color)
    add_title_bar(slide, theme)
    title = add_textbox(slide, 0.9, 0.7, 11.2, 0.8, slide_data["title"])
    p = title.text_frame.paragraphs[0]
    p.text = slide_data["title"]
    style_paragraph(p, theme, 22, bold=True)

    for x, header, bullets in (
        (0.9, slide_data["left_title"], slide_data["left_bullets"]),
        (6.8, slide_data["right_title"], slide_data["right_bullets"]),
    ):
        header_box = add_textbox(slide, x, 1.8, 5.0, 0.5, header)
        p = header_box.text_frame.paragraphs[0]
        p.text = header
        style_paragraph(p, theme, 16, bold=True)
        p.alignment = PP_ALIGN.LEFT

        card = slide.shapes.add_shape(
            MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE, Inches(x), Inches(2.3), Inches(5.2), Inches(3.8)
        )
        fill = card.fill
        fill.solid()
        fill.fore_color.rgb = RGBColor(255, 255, 255)
        card.line.color.rgb = theme.primary_color

        body = add_textbox(slide, x + 0.2, 2.55, 4.7, 3.1, "")
        tf = body.text_frame
        tf.word_wrap = True
        for idx, bullet in enumerate(bullets):
            paragraph = tf.paragraphs[0] if idx == 0 else tf.add_paragraph()
            paragraph.level = 0
            paragraph.space_after = Pt(8)
            paragraph.text = f"• {bullet}"
            style_paragraph(paragraph, theme, 14)


def render_quote_slide(prs: Presentation, slide_data: dict[str, Any], theme: Theme) -> None:
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_background(slide, theme.background_color)
    add_title_bar(slide, theme)
    title = add_textbox(slide, 0.9, 0.7, 11.0, 0.8, slide_data["title"])
    p = title.text_frame.paragraphs[0]
    p.text = slide_data["title"]
    style_paragraph(p, theme, 20, bold=True)

    quote_box = add_textbox(slide, 1.1, 2.0, 10.8, 2.2, slide_data["quote"])
    p = quote_box.text_frame.paragraphs[0]
    p.text = f"“{slide_data['quote']}”"
    p.font.name = theme.font_family
    p.font.size = Pt(24)
    p.font.italic = True
    p.font.color.rgb = theme.primary_color

    attribution = slide_data.get("attribution")
    if attribution:
        box = add_textbox(slide, 1.15, 4.7, 6.0, 0.5, attribution)
        p = box.text_frame.paragraphs[0]
        p.text = attribution
        style_paragraph(p, theme, 12, bold=True)


def render_closing_slide(prs: Presentation, slide_data: dict[str, Any], theme: Theme) -> None:
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_background(slide, theme.primary_color)
    title = add_textbox(slide, 0.9, 1.9, 11.2, 1.1, slide_data["title"])
    p = title.text_frame.paragraphs[0]
    p.text = slide_data["title"]
    p.font.name = theme.font_family
    p.font.size = Pt(26)
    p.font.bold = True
    p.font.color.rgb = RGBColor(255, 255, 255)

    body = add_textbox(slide, 0.95, 3.4, 10.8, 1.4, slide_data["body"])
    p = body.text_frame.paragraphs[0]
    p.text = slide_data["body"]
    p.font.name = theme.font_family
    p.font.size = Pt(16)
    p.font.color.rgb = RGBColor(245, 245, 245)

    accent = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.RECTANGLE, Inches(0.95), Inches(5.6), Inches(2.2), Inches(0.16)
    )
    accent.fill.solid()
    accent.fill.fore_color.rgb = theme.accent_color
    accent.line.fill.background()


def render_slide(prs: Presentation, slide_data: dict[str, Any], meta: dict[str, Any], theme: Theme) -> None:
    slide_type = slide_data["type"]
    if slide_type == "title":
        render_title_slide(prs, slide_data, meta, theme)
    elif slide_type == "section":
        render_section_slide(prs, slide_data, theme)
    elif slide_type == "bullets":
        render_bullets_slide(prs, slide_data, theme)
    elif slide_type == "two-column":
        render_two_column_slide(prs, slide_data, theme)
    elif slide_type == "quote":
        render_quote_slide(prs, slide_data, theme)
    elif slide_type == "closing":
        render_closing_slide(prs, slide_data, theme)
    else:  # pragma: no cover - protected by validation
        fail(f"Unsupported slide type: {slide_type}")


def main() -> None:
    args = parse_args()
    load_pptx_dependencies()
    input_path = Path(args.input)
    output_path = Path(args.output)

    brief = load_brief(input_path)
    warnings = validate_brief(brief, allow_overflow=args.allow_overflow)
    theme = build_theme(brief)
    meta = brief["meta"]

    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    prs.core_properties.author = meta.get("author", "")
    prs.core_properties.title = meta.get("title", "")
    prs.core_properties.subject = meta.get("objective", "")
    prs.core_properties.company = meta.get("company", "")

    for slide_data in brief["slides"]:
        render_slide(prs, slide_data, meta, theme)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    prs.save(str(output_path))
    print(f"Created {output_path}")

    if warnings:
        print("Warnings:")
        for warning in warnings:
            print(f"- {warning}")


if __name__ == "__main__":
    main()
