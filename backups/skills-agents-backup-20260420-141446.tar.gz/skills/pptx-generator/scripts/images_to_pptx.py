#!/usr/bin/env python3
"""Convert slide images into a PPTX deck."""

from __future__ import annotations

import argparse
from pathlib import Path


def fail(message: str) -> "NoReturn":
    raise SystemExit(f"ERROR: {message}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Create a PPTX deck from ordered slide images.")
    parser.add_argument(
        "--input-dir",
        required=True,
        help="Directory containing slide images named in presentation order",
    )
    parser.add_argument("--output", required=True, help="Path to the output .pptx file")
    parser.add_argument(
        "--pattern",
        default="*.png",
        help="Glob pattern used to collect slide images, default: *.png",
    )
    parser.add_argument("--title", default="", help="Deck title for PPTX metadata")
    parser.add_argument("--author", default="", help="Deck author for PPTX metadata")
    return parser.parse_args()


def load_pptx():
    try:
        from pptx import Presentation
        from pptx.util import Inches
    except ImportError as exc:  # pragma: no cover - dependency guard
        fail(f"python-pptx is required: {exc}")
    return Presentation, Inches


def collect_images(input_dir: Path, pattern: str) -> list[Path]:
    images = sorted(path for path in input_dir.glob(pattern) if path.is_file())
    if not images:
        fail(f"No images matched {pattern!r} in {input_dir}")
    return images


def main() -> None:
    args = parse_args()
    input_dir = Path(args.input_dir)
    output_path = Path(args.output)
    if not input_dir.exists():
        fail(f"Input directory not found: {input_dir}")

    Presentation, Inches = load_pptx()
    images = collect_images(input_dir, args.pattern)

    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    prs.core_properties.title = args.title
    prs.core_properties.author = args.author

    blank = prs.slide_layouts[6]
    for image_path in images:
        slide = prs.slides.add_slide(blank)
        slide.shapes.add_picture(
            str(image_path),
            0,
            0,
            width=prs.slide_width,
            height=prs.slide_height,
        )

    output_path.parent.mkdir(parents=True, exist_ok=True)
    prs.save(str(output_path))
    print(f"Created {output_path} from {len(images)} slide images")


if __name__ == "__main__":
    main()
