#!/usr/bin/env python3
"""Build a self-contained HTML slide deck from a JSON brief."""

from __future__ import annotations

import argparse
import html
import json
import re
import sys
from pathlib import Path
from typing import Any


DEFAULT_THEME = {
    "primary_color": "#173F5F",
    "accent_color": "#F6AE2D",
    "background_color": "#F7F8FA",
    "surface_color": "#FFFFFF",
    "text_color": "#14213D",
    "muted_text_color": "#5B6472",
    "font_family": "Aptos, Segoe UI, sans-serif",
}

PLACEHOLDER_RE = re.compile(r"\b(todo|lorem ipsum|tbd|placeholder)\b", re.IGNORECASE)
SUPPORTED_TYPES = {
    "title",
    "section",
    "bullets",
    "two-column",
    "quote",
    "closing",
    "visual",
    "image-compare",
}


def fail(message: str) -> "NoReturn":
    print(f"ERROR: {message}", file=sys.stderr)
    raise SystemExit(1)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate an HTML slide deck from a JSON brief.")
    parser.add_argument("--input", required=True, help="Path to the JSON brief")
    parser.add_argument("--output", required=True, help="Path to the output HTML file")
    return parser.parse_args()


def load_brief(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        fail(f"Input file not found: {path}")
    except json.JSONDecodeError as exc:
        fail(f"Invalid JSON in {path}: {exc}")
    if not isinstance(data, dict):
        fail("Top-level brief must be a JSON object")
    return data


def require_non_empty(mapping: dict[str, Any], key: str) -> str:
    value = mapping.get(key)
    if not isinstance(value, str) or not value.strip():
        fail(f"Missing required string field: {key}")
    return value.strip()


def validate_text(value: str, field_name: str) -> None:
    if PLACEHOLDER_RE.search(value):
        fail(f"Field {field_name} contains placeholder text: {value!r}")


def validate_bullets(bullets: Any, field_name: str) -> list[str]:
    if not isinstance(bullets, list) or not bullets:
        fail(f"{field_name} must be a non-empty list")
    cleaned: list[str] = []
    for idx, item in enumerate(bullets, start=1):
        if not isinstance(item, str) or not item.strip():
            fail(f"{field_name}[{idx}] must be a non-empty string")
        text = item.strip()
        validate_text(text, f"{field_name}[{idx}]")
        cleaned.append(text)
    return cleaned


def validate_image(image: Any, field_name: str) -> dict[str, str]:
    if not isinstance(image, dict):
        fail(f"{field_name} must be an object")
    src = require_non_empty(image, "src")
    alt = str(image.get("alt", "")).strip()
    caption = str(image.get("caption", "")).strip()
    credit = str(image.get("credit", "")).strip()
    return {"src": src, "alt": alt, "caption": caption, "credit": credit}


def validate_brief(data: dict[str, Any]) -> None:
    meta = data.get("meta")
    if not isinstance(meta, dict):
        fail("meta must be an object")
    require_non_empty(meta, "title")
    require_non_empty(meta, "audience")
    require_non_empty(meta, "objective")

    slides = data.get("slides")
    if not isinstance(slides, list) or not slides:
        fail("slides must be a non-empty array")

    seen_titles: set[str] = set()
    for idx, slide in enumerate(slides, start=1):
        if not isinstance(slide, dict):
            fail(f"slides[{idx}] must be an object")
        slide_type = require_non_empty(slide, "type")
        if slide_type not in SUPPORTED_TYPES:
            fail(f"slides[{idx}] has unsupported type: {slide_type}")
        title = require_non_empty(slide, "title")
        validate_text(title, f"slides[{idx}].title")
        lowered_title = title.casefold()
        if lowered_title in seen_titles:
            fail(f"Duplicate slide title: {title}")
        seen_titles.add(lowered_title)

        if slide_type == "bullets":
            validate_bullets(slide.get("bullets"), f"slides[{idx}].bullets")
        elif slide_type == "two-column":
            require_non_empty(slide, "left_title")
            require_non_empty(slide, "right_title")
            validate_bullets(slide.get("left_bullets"), f"slides[{idx}].left_bullets")
            validate_bullets(slide.get("right_bullets"), f"slides[{idx}].right_bullets")
        elif slide_type == "section":
            require_non_empty(slide, "body")
        elif slide_type == "quote":
            require_non_empty(slide, "quote")
        elif slide_type == "closing":
            require_non_empty(slide, "body")
        elif slide_type == "visual":
            if "image" not in slide:
                fail(f"slides[{idx}].image is required for visual slides")
            validate_image(slide["image"], f"slides[{idx}].image")
            body = str(slide.get("body", "")).strip()
            bullets = slide.get("bullets")
            if not body and not bullets:
                fail(f"slides[{idx}] visual slide needs body or bullets")
            if bullets is not None:
                validate_bullets(bullets, f"slides[{idx}].bullets")
        elif slide_type == "image-compare":
            require_non_empty(slide, "left_title")
            require_non_empty(slide, "right_title")
            validate_image(slide.get("left_image"), f"slides[{idx}].left_image")
            validate_image(slide.get("right_image"), f"slides[{idx}].right_image")


def normalize_theme(data: dict[str, Any]) -> dict[str, str]:
    theme_in = data.get("theme") if isinstance(data.get("theme"), dict) else {}
    merged = {**DEFAULT_THEME, **theme_in}
    return {key: str(value).strip() for key, value in merged.items()}


def esc(text: str) -> str:
    return html.escape(text, quote=True)


def render_bullets(items: list[str], class_name: str = "bullet-list") -> str:
    return "<ul class=\"%s\">%s</ul>" % (
        class_name,
        "".join(f"<li>{esc(item)}</li>" for item in items),
    )


def render_image(image: dict[str, str], output_path: Path, class_name: str = "image-frame") -> str:
    src = image["src"]
    alt = image.get("alt", "")
    caption = image.get("caption", "")
    credit = image.get("credit", "")
    if not re.match(r"^(https?:|data:)", src):
        image_path = Path(src)
        if not image_path.is_absolute():
            image_path = (output_path.parent / image_path).resolve()
        src = image_path.as_uri()
    caption_parts = []
    if caption:
        caption_parts.append(f"<div class=\"caption\">{esc(caption)}</div>")
    if credit:
        caption_parts.append(f"<div class=\"credit\">{esc(credit)}</div>")
    return (
        f"<figure class=\"{class_name}\">"
        f"<img src=\"{esc(src)}\" alt=\"{esc(alt)}\" />"
        f"{''.join(caption_parts)}"
        f"</figure>"
    )


def render_slide(slide: dict[str, Any], meta: dict[str, Any], output_path: Path) -> str:
    slide_type = slide["type"]
    title = esc(slide["title"])
    slide_no = slide.get("_index", 0) + 1
    footer = esc(meta.get("company") or meta.get("author") or meta["audience"])

    if slide_type == "title":
        subtitle = esc(slide.get("subtitle") or meta.get("subtitle", ""))
        return f"""
        <section class="slide title-slide" data-slide="{slide_no}">
          <div class="accent-bar"></div>
          <div class="slide-body title-layout">
            <div class="eyebrow">Executive Presentation</div>
            <h1>{title}</h1>
            <p class="subtitle">{subtitle}</p>
            <div class="footer">{footer}</div>
          </div>
        </section>
        """

    if slide_type == "section":
        eyebrow = esc(slide.get("eyebrow", "Section"))
        body = esc(slide["body"])
        return f"""
        <section class="slide section-slide" data-slide="{slide_no}">
          <div class="slide-body section-layout">
            <div class="eyebrow">{eyebrow}</div>
            <h2>{title}</h2>
            <p class="section-copy">{body}</p>
          </div>
        </section>
        """

    if slide_type == "bullets":
        bullets_html = render_bullets(slide["bullets"])
        return f"""
        <section class="slide standard-slide" data-slide="{slide_no}">
          <div class="accent-bar"></div>
          <div class="slide-body">
            <h2>{title}</h2>
            {bullets_html}
            <div class="footer muted">{footer}</div>
          </div>
        </section>
        """

    if slide_type == "two-column":
        left_html = render_bullets(slide["left_bullets"], "bullet-list compact")
        right_html = render_bullets(slide["right_bullets"], "bullet-list compact")
        return f"""
        <section class="slide standard-slide" data-slide="{slide_no}">
          <div class="accent-bar"></div>
          <div class="slide-body">
            <h2>{title}</h2>
            <div class="two-col">
              <div class="card">
                <div class="card-title">{esc(slide['left_title'])}</div>
                {left_html}
              </div>
              <div class="card">
                <div class="card-title">{esc(slide['right_title'])}</div>
                {right_html}
              </div>
            </div>
          </div>
        </section>
        """

    if slide_type == "quote":
        quote = esc(slide["quote"])
        attribution = esc(slide.get("attribution", ""))
        attribution_html = f"<div class=\"quote-attribution\">{attribution}</div>" if attribution else ""
        return f"""
        <section class="slide standard-slide quote-slide" data-slide="{slide_no}">
          <div class="accent-bar"></div>
          <div class="slide-body">
            <h2>{title}</h2>
            <blockquote>{quote}</blockquote>
            {attribution_html}
          </div>
        </section>
        """

    if slide_type == "closing":
        body = esc(slide["body"])
        return f"""
        <section class="slide closing-slide" data-slide="{slide_no}">
          <div class="slide-body closing-layout">
            <h2>{title}</h2>
            <p>{body}</p>
            <div class="closing-bar"></div>
          </div>
        </section>
        """

    if slide_type == "visual":
        layout = slide.get("layout", "image-right").strip() or "image-right"
        body = esc(str(slide.get("body", "")).strip())
        body_html = f"<p class=\"visual-copy\">{body}</p>" if body else ""
        bullets = slide.get("bullets") or []
        bullets_html = render_bullets(bullets, "bullet-list compact") if bullets else ""
        image_html = render_image(slide["image"], output_path, "image-frame tall")
        reverse = " reverse" if layout == "image-left" else ""
        return f"""
        <section class="slide standard-slide" data-slide="{slide_no}">
          <div class="accent-bar"></div>
          <div class="slide-body">
            <h2>{title}</h2>
            <div class="visual-grid{reverse}">
              <div class="visual-copy-wrap">
                {body_html}
                {bullets_html}
              </div>
              {image_html}
            </div>
          </div>
        </section>
        """

    if slide_type == "image-compare":
        left_html = render_image(slide["left_image"], output_path, "image-frame compare")
        right_html = render_image(slide["right_image"], output_path, "image-frame compare")
        return f"""
        <section class="slide standard-slide" data-slide="{slide_no}">
          <div class="accent-bar"></div>
          <div class="slide-body">
            <h2>{title}</h2>
            <div class="two-col compare-grid">
              <div class="card image-card">
                <div class="card-title">{esc(slide['left_title'])}</div>
                {left_html}
              </div>
              <div class="card image-card">
                <div class="card-title">{esc(slide['right_title'])}</div>
                {right_html}
              </div>
            </div>
          </div>
        </section>
        """

    fail(f"Unsupported slide type: {slide_type}")


def build_html(brief: dict[str, Any], output_path: Path) -> str:
    theme = normalize_theme(brief)
    meta = brief["meta"]

    slides_html = []
    for index, slide in enumerate(brief["slides"]):
        slide = dict(slide)
        slide["_index"] = index
        slides_html.append(render_slide(slide, meta, output_path))

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>{esc(meta['title'])}</title>
  <style>
    :root {{
      --primary: {esc(theme['primary_color'])};
      --accent: {esc(theme['accent_color'])};
      --bg: {esc(theme['background_color'])};
      --surface: {esc(theme['surface_color'])};
      --text: {esc(theme['text_color'])};
      --muted: {esc(theme['muted_text_color'])};
      --font: {esc(theme['font_family'])};
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      padding: 24px;
      font-family: var(--font);
      background:
        radial-gradient(circle at top left, rgba(245,174,45,0.18), transparent 28%),
        linear-gradient(180deg, #eef2f6 0%, #dde5ef 100%);
      color: var(--text);
    }}
    .deck {{
      display: flex;
      flex-direction: column;
      gap: 28px;
      align-items: center;
    }}
    .slide {{
      width: 1280px;
      min-height: 720px;
      position: relative;
      overflow: hidden;
      background: var(--bg);
      border-radius: 28px;
      box-shadow: 0 20px 60px rgba(17, 24, 39, 0.18);
      page-break-after: always;
    }}
    .slide::before {{
      content: "";
      position: absolute;
      inset: 0;
      background:
        radial-gradient(circle at top right, rgba(197,139,43,0.10), transparent 26%),
        radial-gradient(circle at bottom left, rgba(23,63,95,0.10), transparent 22%);
      pointer-events: none;
    }}
    .accent-bar {{
      position: absolute;
      left: 0;
      top: 0;
      width: 100%;
      height: 18px;
      background: linear-gradient(90deg, var(--accent), color-mix(in srgb, var(--accent) 40%, white));
    }}
    .slide-body {{
      position: relative;
      z-index: 1;
      padding: 52px 66px 52px 66px;
      min-height: 720px;
      display: flex;
      flex-direction: column;
    }}
    .title-slide {{
      background:
        radial-gradient(circle at top left, rgba(245,174,45,0.14), transparent 28%),
        linear-gradient(140deg, #fffdf8 0%, #f3efe7 52%, #ece7de 100%);
    }}
    .section-slide, .closing-slide {{
      background:
        radial-gradient(circle at top right, rgba(255,255,255,0.10), transparent 24%),
        linear-gradient(135deg, color-mix(in srgb, var(--primary) 88%, black), var(--primary));
      color: #ffffff;
    }}
    .eyebrow {{
      font-size: 18px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.12em;
      color: var(--accent);
      margin-bottom: 18px;
    }}
    h1, h2 {{
      margin: 0;
      line-height: 1.08;
      max-width: 1020px;
    }}
    h1 {{ font-size: 46px; }}
    h2 {{ font-size: 34px; margin-bottom: 26px; }}
    .subtitle {{
      font-size: 22px;
      color: var(--muted);
      max-width: 920px;
      margin-top: 18px;
    }}
    .footer {{
      margin-top: auto;
      font-size: 15px;
      color: var(--text);
    }}
    .footer.muted {{ color: var(--muted); }}
    .section-copy, .closing-layout p, .visual-copy {{
      font-size: 24px;
      line-height: 1.45;
      max-width: 900px;
    }}
    .bullet-list {{
      margin: 0;
      padding-left: 24px;
      display: grid;
      gap: 16px;
      font-size: 25px;
      line-height: 1.35;
      max-width: 1040px;
    }}
    .bullet-list.compact {{
      font-size: 20px;
      gap: 12px;
      max-width: none;
    }}
    .two-col {{
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 28px;
      align-items: stretch;
    }}
    .card {{
      background: rgba(255,255,255,0.82);
      border: 1px solid rgba(20,33,61,0.10);
      border-radius: 24px;
      padding: 24px 24px 18px;
      backdrop-filter: blur(12px);
      min-height: 420px;
    }}
    .card-title {{
      font-size: 20px;
      font-weight: 700;
      margin-bottom: 16px;
      color: var(--primary);
    }}
    .quote-slide blockquote {{
      margin: 18px 0 0;
      font-size: 36px;
      line-height: 1.35;
      color: var(--primary);
      font-style: italic;
      max-width: 1020px;
    }}
    .quote-attribution {{
      margin-top: 18px;
      font-size: 18px;
      font-weight: 700;
    }}
    .visual-grid {{
      display: grid;
      grid-template-columns: 0.92fr 1.08fr;
      gap: 28px;
      align-items: stretch;
      flex: 1;
    }}
    .visual-grid.reverse {{
      grid-template-columns: 1.08fr 0.92fr;
    }}
    .visual-grid.reverse .visual-copy-wrap {{
      order: 2;
    }}
    .visual-grid.reverse .image-frame {{
      order: 1;
    }}
    .visual-copy-wrap {{
      display: flex;
      flex-direction: column;
      justify-content: center;
      gap: 18px;
    }}
    .image-frame {{
      background: rgba(255,255,255,0.86);
      border-radius: 24px;
      overflow: hidden;
      border: 1px solid rgba(20,33,61,0.10);
      display: flex;
      flex-direction: column;
      min-height: 0;
    }}
    .image-frame img {{
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
      flex: 1;
      min-height: 0;
    }}
    .image-frame.tall {{
      min-height: 490px;
    }}
    .image-frame.compare {{
      min-height: 300px;
    }}
    .caption, .credit {{
      padding: 10px 16px 0;
      font-size: 14px;
      line-height: 1.35;
      color: var(--muted);
      background: rgba(255,255,255,0.92);
    }}
    .credit {{
      padding-bottom: 14px;
      font-size: 12px;
    }}
    .image-card {{
      min-height: 0;
    }}
    .compare-grid .card {{
      min-height: 500px;
    }}
    .title-layout, .closing-layout {{
      justify-content: center;
    }}
    .closing-bar {{
      margin-top: 34px;
      width: 220px;
      height: 10px;
      border-radius: 999px;
      background: linear-gradient(90deg, var(--accent), rgba(255,255,255,0.78));
    }}
    @media print {{
      body {{
        padding: 0;
        background: #ffffff;
      }}
      .deck {{
        gap: 0;
      }}
      .slide {{
        border-radius: 0;
        box-shadow: none;
        margin: 0;
      }}
    }}
  </style>
</head>
<body>
  <main class="deck">
    {''.join(slides_html)}
  </main>
</body>
</html>
"""


def main() -> None:
    args = parse_args()
    input_path = Path(args.input)
    output_path = Path(args.output)
    brief = load_brief(input_path)
    validate_brief(brief)
    html_out = build_html(brief, output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(html_out, encoding="utf-8")
    print(f"Created {output_path}")


if __name__ == "__main__":
    main()
