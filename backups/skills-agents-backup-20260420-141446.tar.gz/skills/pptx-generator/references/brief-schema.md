# Presentation Brief Schema

Use this schema when preparing JSON for `scripts/build_presentation.py`.

## Required top-level fields

```json
{
  "meta": {
    "title": "Q3 Growth Plan",
    "subtitle": "Executive review",
    "author": "Strategy Team",
    "company": "Example Co",
    "audience": "Executive leadership",
    "objective": "Approve the proposed market expansion plan"
  },
  "theme": {
    "primary_color": "#173F5F",
    "accent_color": "#F6AE2D",
    "background_color": "#F7F8FA",
    "text_color": "#14213D",
    "font_family": "Aptos"
  },
  "slides": []
}
```

## `meta`

- `title`: Deck title used on the title slide metadata.
- `subtitle`: Optional subtitle for the title slide.
- `author`: Optional author or team name.
- `company`: Optional company name.
- `audience`: Required audience description.
- `objective`: Required decision, action, or learning outcome.

## `theme`

All theme fields are optional. Defaults are applied if omitted.

- `primary_color`
- `accent_color`
- `background_color`
- `text_color`
- `font_family`

Use hex colors like `#173F5F`.

## `slides`

`slides` must be a non-empty array.

### `title`

```json
{
  "type": "title",
  "title": "2026 Product Strategy",
  "subtitle": "Focus, tradeoffs, and launch plan"
}
```

### `section`

```json
{
  "type": "section",
  "eyebrow": "Market context",
  "title": "Demand has shifted toward bundled workflows",
  "body": "Customers now value fewer tools, tighter handoffs, and faster deployment."
}
```

### `bullets`

```json
{
  "type": "bullets",
  "title": "Why we should enter this segment now",
  "bullets": [
    "Pipeline quality improved 28% after the pilot launch.",
    "The current offer solves a high-cost onboarding bottleneck.",
    "Sales can attach the product to existing enterprise renewals."
  ]
}
```

### `two-column`

```json
{
  "type": "two-column",
  "title": "Current state vs target state",
  "left_title": "Current",
  "left_bullets": [
    "Manual handoffs slow launch readiness.",
    "Three tools fragment reporting."
  ],
  "right_title": "Target",
  "right_bullets": [
    "Single workflow from intake to reporting.",
    "Leadership sees weekly health metrics."
  ]
}
```

### `quote`

```json
{
  "type": "quote",
  "title": "Customer signal",
  "quote": "We do not need more features. We need one clear flow our team can adopt in a week.",
  "attribution": "Operations lead, enterprise pilot"
}
```

### `closing`

```json
{
  "type": "closing",
  "title": "Approve the Q3 launch plan",
  "body": "Decision requested today: fund the implementation team and start customer migration in July."
}
```

## Validation Rules

- Use 16:9 storytelling by default.
- Keep `slides` between 4 and 20 unless the user explicitly requests more.
- Keep each slide focused on one message.
- Avoid duplicate slide titles.
- Avoid empty strings and placeholder text.
