# PPTX Quality Bar

Use this checklist before calling a deck client-ready or executive-ready.

## Narrative

- Lead with the conclusion when the audience is executive or commercial.
- Make the order of slides support a clear argument, not a topic dump.
- Use section slides only when they improve pacing.

## Titles

- Write titles as takeaways, not labels.
- Prefer concrete nouns, numbers, and outcomes.
- Keep titles short enough to scan in one pass.

Weak:

- `Market Overview`
- `Recommendations`

Better:

- `The mid-market segment now supports a profitable entry`
- `Approve a two-phase rollout to reduce launch risk`

## Bullets

- Keep bullets parallel in grammar.
- Limit each bullet to one idea.
- Replace generic words like `improve`, `optimize`, `leverage`, and `synergy` with measurable or operational language.
- Delete throat-clearing phrases.

## Visual Density

- Prefer whitespace over completeness.
- If a slide needs more than 5 bullets, split it.
- If a bullet exceeds about two lines in PowerPoint, shorten it or move detail to notes.

## Brand and Professionalism

- Use the user's exact brand assets if supplied.
- If no brand is provided, use restrained colors and typography.
- Avoid novelty layouts, clip-art aesthetics, decorative icons, or loud color combinations.

## Review Gate

Before delivery, verify:

1. every slide supports the stated objective
2. no critical fact was invented
3. tone matches the audience
4. the final slide makes the next action explicit
