# HTML Presentation Brief Schema

Use this schema when the deck should be designed in HTML first, especially when the request needs richer layout, image panels, or a screenshot-driven HTML to PPTX workflow.

## Required top-level fields

```json
{
  "meta": {
    "title": "Global Energy Shock Briefing",
    "subtitle": "Executive review",
    "author": "Strategy Team",
    "company": "Example Co",
    "audience": "Executive leadership",
    "objective": "Prepare leaders for a conflict-driven cost shock"
  },
  "theme": {
    "primary_color": "#213547",
    "accent_color": "#C58B2B",
    "background_color": "#F4F2EE",
    "surface_color": "#FFFFFF",
    "text_color": "#14213D",
    "muted_text_color": "#5B6472",
    "font_family": "Aptos, Segoe UI, sans-serif"
  },
  "slides": []
}
```

## Supported slide types

### `title`

```json
{
  "type": "title",
  "title": "Energy risk has moved from macro noise to operating risk",
  "subtitle": "Why the next 90 days matter"
}
```

### `section`

```json
{
  "type": "section",
  "eyebrow": "Context",
  "title": "Volatility has become persistent rather than episodic",
  "body": "Repeated escalation keeps pricing, shipping, and planning assumptions unstable."
}
```

### `bullets`

```json
{
  "type": "bullets",
  "title": "What management should assume now",
  "bullets": [
    "Energy costs can remain above budget even if hostilities cool briefly.",
    "Transit insurance and freight costs will likely stay elevated.",
    "Cash planning matters more than point forecasts."
  ]
}
```

### `two-column`

```json
{
  "type": "two-column",
  "title": "Base case versus downside case",
  "left_title": "Base case",
  "left_bullets": [
    "Partial de-escalation but persistent premium in oil and gas.",
    "Financial conditions stay tighter than pre-conflict."
  ],
  "right_title": "Downside case",
  "right_bullets": [
    "Longer disruption in chokepoints or energy infrastructure.",
    "Broader inflation rebound and delayed rate cuts."
  ]
}
```

### `quote`

```json
{
  "type": "quote",
  "title": "Investor framing",
  "quote": "The issue is no longer whether the shock is temporary, but how much resilience balance sheets still have.",
  "attribution": "Internal strategy note"
}
```

### `closing`

```json
{
  "type": "closing",
  "title": "Treat the conflict as an operational scenario, not a headline risk",
  "body": "Update cost assumptions, secure alternatives, and protect liquidity before volatility compounds."
}
```

### `visual`

Use when one image should carry the slide with text beside it.

```json
{
  "type": "visual",
  "title": "Shipping disruption is visible before shortages appear",
  "layout": "image-right",
  "body": "A single strong image can anchor the slide while the text explains the business implication.",
  "bullets": [
    "Use 2 to 4 bullets only.",
    "Keep the image relevant, not decorative."
  ],
  "image": {
    "src": "./assets/hormuz-tanker.jpg",
    "alt": "Oil tanker in the Strait of Hormuz",
    "caption": "Energy chokepoints reprice logistics quickly.",
    "credit": "Source: user-provided or licensed image"
  }
}
```

`layout` accepts `image-right` or `image-left`.

### `image-compare`

Use when the slide should compare two visuals side by side.

```json
{
  "type": "image-compare",
  "title": "Before and after the shock",
  "left_title": "Normal flow",
  "left_image": {
    "src": "./assets/normal-flow.png",
    "alt": "Normal shipping lanes",
    "caption": "Baseline shipping pattern"
  },
  "right_title": "Disrupted flow",
  "right_image": {
    "src": "./assets/disrupted-flow.png",
    "alt": "Disrupted shipping lanes",
    "caption": "Rerouting and delay"
  }
}
```

## Image guidance

- Prefer local image paths for repeatable builds.
- Remote `https://` URLs and `data:` URLs are allowed when local files are not practical.
- Use images with clear editorial value: maps, infrastructure, products, facilities, satellite views, charts exported as images.
- Avoid decorative stock art unless the user explicitly wants mood imagery.

## Workflow contract

1. Build the HTML deck with `scripts/build_html_presentation.py`.
2. Open the generated HTML in a browser or with Playwright MCP.
3. Capture one screenshot per `.slide` at 1280x720.
4. Convert the screenshots to `.pptx` with `scripts/images_to_pptx.py`.
