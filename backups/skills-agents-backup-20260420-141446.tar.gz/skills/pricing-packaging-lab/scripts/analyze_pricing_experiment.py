#!/usr/bin/env python3
import argparse
import csv
from pathlib import Path


def main() -> None:
    p = argparse.ArgumentParser(description="Analyze pricing experiment variants")
    p.add_argument("--input", required=True, help="CSV columns: variant,visitors,conversions,revenue")
    p.add_argument("--out", default="pricing_experiment_report.md")
    args = p.parse_args()

    rows = list(csv.DictReader(Path(args.input).read_text(encoding="utf-8").splitlines()))
    stats = []
    for r in rows:
        visitors = float(r["visitors"])
        conv = float(r["conversions"])
        rev = float(r["revenue"])
        cr = conv / visitors if visitors else 0
        arpu = rev / visitors if visitors else 0
        stats.append((r["variant"], visitors, conv, rev, cr, arpu))

    best = max(stats, key=lambda x: (x[4], x[5])) if stats else None
    lines = ["# Pricing Experiment Report", "", "## Variant Metrics"]
    for v, visitors, conv, rev, cr, arpu in stats:
        lines.append(f"- {v}: CR {cr*100:.2f}% | ARPU {arpu:.2f} | Revenue {rev:,.0f}")

    lines += ["", "## Recommendation"]
    if best:
        lines.append(f"- 우선 채택 후보: {best[0]} (CR/ARPU 기준)")
        lines.append("- 반영 전 공지/이탈 리스크 점검 필요")
    else:
        lines.append("- 데이터 없음")

    Path(args.out).write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
