#!/bin/zsh
set -euo pipefail
DIR="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$DIR/output"
mkdir -p "$OUT"
python3 "$DIR/scripts/analyze_pricing_experiment.py" --input "$DIR/assets/sample_experiment_results.csv" --out "$OUT/pricing_experiment_report.md"
echo "Generated: $OUT/pricing_experiment_report.md"
