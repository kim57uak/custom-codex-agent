---
name: "pricing-packaging-lab"
description: "가격 정책과 상품 패키지 구조를 실험하고 전환율 영향을 분석할 때 사용합니다. 요금제 개편, 옵션 재구성, 할인 정책 테스트처럼 수익성/전환 균형을 검토해야 할 때 트리거됩니다."
---

# Pricing Packaging Lab

## 운영 오너
- 개발팀

## 빠른 실행
- 입력 스키마: `references/experiment-schema.md`
- 실행:
```bash
python3 scripts/analyze_pricing_experiment.py \
  --input experiment_results.csv \
  --out pricing_experiment_report.md
```

## 워크플로
1. 실험 결과 CSV를 수집합니다.
2. 스크립트로 variant별 CR/ARPU를 비교합니다.
3. 채택/보류 결론과 고객 공지 계획을 문서화합니다.

## 품질 기준
- 사전 정의 지표로만 의사결정을 내립니다.
- 가격 변경 시 이탈 리스크 대응 문안을 함께 준비합니다.

## 파일 입력 처리
- 입력이 파일일 때는 먼저 `scripts/extract_text_from_file.py`로 텍스트를 추출합니다.
- 지원 형식: `txt,pdf,ppt,pptx,doc,docx,excel(xls/xlsx),md,html`
- 실행 예시:
```bash
python3 scripts/extract_text_from_file.py --input ./input/source.docx --output ./tmp/source.txt
```
- 추출 텍스트를 바탕으로 각 스킬의 본 스크립트(견적/정산/분류/분석)를 실행합니다.

## 파일 입력 유효성 체크

- 이 스킬의 현재 요청이 파일 입력 없이도 수행 가능한 범위라면, 파일 경로를 요구하지 말고 바로 작업을 진행합니다.
- 사용자가 문서/코드/계약서 본문을 메시지에 직접 제공한 경우에는 파일 경로 없이도 해당 텍스트로 작업을 진행합니다.
- 특정 파일의 실제 내용을 읽어야만 작업이 가능한 경우에만, **파일 경로 + 파일명** 제공 여부를 확인합니다.
- 파일 경로 또는 파일명이 누락된 경우에는 파일 작업을 진행하지 않고, 사용자에게 정확한 파일 경로와 파일명을 먼저 요청합니다.
- 경로가 모호한 표현(예: "그 파일", "지난번 문서")만 있는 경우에도 동일하게 명시 경로를 요청합니다.

