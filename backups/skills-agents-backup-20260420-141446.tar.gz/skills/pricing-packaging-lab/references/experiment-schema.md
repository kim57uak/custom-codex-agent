# Experiment CSV Schema

Required columns:
- `variant`
- `visitors`
- `conversions`
- `revenue`
