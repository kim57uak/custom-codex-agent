# Pricing Experiment Report

## Variant Metrics
- A: CR 9.50% | ARPU 9500.00 | Revenue 9,500,000
- B: CR 12.00% | ARPU 11400.00 | Revenue 11,400,000
- C: CR 10.50% | ARPU 10800.00 | Revenue 10,800,000

## Recommendation
- 우선 채택 후보: B (CR/ARPU 기준)
- 반영 전 공지/이탈 리스크 점검 필요
