---
name: run-all-sh
description: /Users/dolpaks/Downloads/project/custom-codex-agent/run_all.sh 실행을 전담합니다. 실행 모드(prod/dev) 선택, 사전 점검, 실행 로그 확인, 실패 시 원인 진단까지 수행합니다.
---

# run_all.sh 실행 스킬

이 스킬은 아래 스크립트를 실행하는 전용 워크플로입니다.

- 대상 스크립트: `/Users/dolpaks/Downloads/project/custom-codex-agent/run_all.sh`
- 기본 모드: `prod`
- 지원 모드: `prod`, `dev`

## 실행 규칙

1. 작업 디렉터리를 `/Users/dolpaks/Downloads/project/custom-codex-agent`로 맞춘다.
2. 스크립트 존재/실행 권한을 점검한다.
3. 사용자가 모드를 명시하면 그 모드로 실행하고, 없으면 `prod`로 실행한다.
4. 장기 실행 프로세스이므로 실행 성공 여부와 바인딩 포트(기본 8000) 상태를 확인한다.
5. 실패 시 표준 에러 로그를 요약하고 원인(venv, python, port 충돌, env 문제)을 진단한다.

## 표준 실행 커맨드

```bash
cd /Users/dolpaks/Downloads/project/custom-codex-agent
./run_all.sh
```

개발 모드:

```bash
cd /Users/dolpaks/Downloads/project/custom-codex-agent
./run_all.sh dev
```

## 결과 보고 형식

- 실행 모드
- 실행 커맨드
- 성공/실패 여부
- 주요 로그 요약
- 실패 시 즉시 실행 가능한 다음 조치

## 파일 입력 유효성 체크

- 이 스킬의 현재 요청이 파일 입력 없이도 수행 가능한 범위라면, 파일 경로를 요구하지 말고 바로 작업을 진행합니다.
- 사용자가 문서/코드/계약서 본문을 메시지에 직접 제공한 경우에는 파일 경로 없이도 해당 텍스트로 작업을 진행합니다.
- 특정 파일의 실제 내용을 읽어야만 작업이 가능한 경우에만, **파일 경로 + 파일명** 제공 여부를 확인합니다.
- 파일 경로 또는 파일명이 누락된 경우에는 파일 작업을 진행하지 않고, 사용자에게 정확한 파일 경로와 파일명을 먼저 요청합니다.
- 경로가 모호한 표현(예: "그 파일", "지난번 문서")만 있는 경우에도 동일하게 명시 경로를 요청합니다.

