---
name: java-coding-standards
description: "Spring Boot 서비스용 Java 코딩 기준입니다. 네이밍, 불변성, Optional 사용, stream, exception, generic, 프로젝트 레이아웃을 다룹니다."
origin: ECC+custom
---

# Java 코딩 기준

Spring Boot 서비스에서 읽기 쉽고 유지보수 가능한 Java(17+) 코드를 위한 기준입니다.

빌드 도구 호환성:
- 이 기준은 Maven과 Gradle 프로젝트 모두에 동일하게 적용됩니다.
- 재현 가능한 CI 일관성을 위해 wrapper 명령 `./mvnw`, `./gradlew`를 우선합니다.

## 활성화 시점

- Spring Boot 프로젝트에서 Java 코드를 작성하거나 리뷰할 때
- 네이밍, 불변성, exception handling 관례를 강제할 때
- record, sealed class, pattern matching 같은 Java 17+ 기능을 사용할 때
- Optional, stream, generic 사용을 리뷰할 때
- package 구조와 프로젝트 레이아웃을 정리할 때

## 핵심 원칙

- 영리함보다 명확함을 우선합니다
- 기본은 immutable, 공유 mutable state는 최소화합니다
- 의미 있는 예외로 fail fast 합니다
- 일관된 네이밍과 package 구조를 유지합니다
- layer boundary를 보존합니다. API/Application/Domain/Infrastructure

## 네이밍

```java
// PASS: Classes/Records: PascalCase
public class MarketService {}
public record Money(BigDecimal amount, Currency currency) {}

// PASS: Methods/fields: camelCase
private final MarketRepository marketRepository;
public Market findBySlug(String slug) {}

// PASS: Constants: UPPER_SNAKE_CASE
private static final int MAX_PAGE_SIZE = 100;
```

## 불변성

```java
// PASS: Favor records and final fields
public record MarketDto(Long id, String name, MarketStatus status) {}

public class Market {
  private final Long id;
  private final String name;
  // getters only, no setters
}
```

규칙:
- setter mutation보다 constructor initialization을 선호합니다.
- immutable collection을 노출합니다. `List.copyOf`, `Collections.unmodifiableList`
- primitive obsession은 `OrderId`, `Email`, `Money` 같은 value object로 대체합니다.

## Optional 사용

```java
// PASS: Return Optional from find* methods
Optional<Market> market = marketRepository.findBySlug(slug);

// PASS: Map/flatMap instead of get()
return market
    .map(MarketResponse::from)
    .orElseThrow(() -> new EntityNotFoundException("Market not found"));
```

규칙:
- entity field에 `Optional`을 사용하지 않습니다.
- method parameter로 `Optional`을 받지 않습니다.
- 사전 가드 없이 `get()`을 호출하지 않습니다.

## Stream 모범 사례

```java
// PASS: Use streams for transformations, keep pipelines short
List<String> names = markets.stream()
    .map(Market::name)
    .filter(Objects::nonNull)
    .toList();

// FAIL: Avoid complex nested streams; prefer loops for clarity
```

규칙:
- stream pipeline은 선형이고 읽기 쉽게 유지합니다.
- 제어 흐름이나 오류 처리가 복잡하면 loop를 선호합니다.

## 예외

- domain error에는 unchecked exception을 사용하고, technical exception은 문맥을 담아 감쌉니다
- `MarketNotFoundException` 같은 domain-specific exception을 만듭니다
- 중앙에서 재던지거나 로깅하지 않는 한 넓은 `catch (Exception ex)`는 피합니다

```java
throw new MarketNotFoundException(slug);
```

규칙:
- domain과 infrastructure exception family를 분리합니다.
- 예외를 삼키지 않습니다.
- API 레이어는 일관된 방식으로 예외를 매핑해야 합니다. `ProblemDetail`/RFC 7807 권장

## Generic과 타입 안정성

- raw type을 피하고 generic parameter를 선언합니다
- 재사용 유틸리티에는 bounded generic을 선호합니다

```java
public <T extends Identifiable> Map<Long, T> indexById(Collection<T> items) { ... }
```

## 프로젝트 구조

```text
src/main/java/com/example/app/
  api/
  application/
  domain/
  infrastructure/
  config/
src/main/resources/
  application.yml
src/test/java/... (mirrors main)
```

가이드:
- domain은 Spring/JPA/HTTP 의존성에서 자유롭게 유지합니다.

## 포맷팅과 스타일

- 2칸 또는 4칸 들여쓰기를 프로젝트 기준에 맞춰 일관되게 사용합니다
- 파일당 public top-level type은 하나만 둡니다
- method는 짧고 집중되게 유지하며 helper를 추출합니다
- member 순서는 constants, fields, constructors, public methods, protected, private를 권장합니다

## 피해야 할 코드 냄새

- 긴 parameter list -> DTO/builder 사용
- 깊은 nesting -> early return 사용
- magic number -> 이름 있는 상수로 추출
- static mutable state -> dependency injection 우선
- silent catch block -> 로깅 후 처리하거나 재던지기
- god class/service -> use case 단위로 분리

## 로깅

```java
private static final Logger log = LoggerFactory.getLogger(MarketService.class);
log.info("fetch_market slug={}", slug);
log.error("failed_fetch_market slug={}", slug, ex);
```

규칙:
- secret/PII는 절대 로그에 남기지 않습니다.
- 추적 가능성을 위해 request/correlation ID를 포함합니다.
- structured logging key를 선호합니다.

## Null 처리

- 불가피한 경우만 `@Nullable`을 허용하고, 그 외에는 `@NonNull`을 사용합니다
- 입력에는 Bean Validation `@NotNull`, `@NotBlank`를 사용합니다
- null 대신 빈 collection을 반환합니다

## 동시성과 트랜잭션

- transactional boundary는 application service에 둡니다.
- 읽기 전용 흐름에는 `@Transactional(readOnly = true)`를 선호합니다.
- 공유 mutable singleton state를 피합니다.
- 재시도 가능 작업은 멱등적으로 설계합니다.

## 테스트 기대치

- fluent assertion에는 JUnit 5 + AssertJ
- mocking에는 Mockito, partial mock은 가능한 피함
- deterministic test를 선호하고 숨겨진 sleep을 두지 않음
- 버그 수정에는 regression test를 추가합니다. 먼저 실패하고 그다음 통과해야 합니다

## 품질 게이트

1. 빌드가 컴파일된다
2. 변경 범위 테스트가 통과한다
3. 정적 분석/스타일 체크가 통과한다
4. API 또는 동작 변경이 문서화된다

**기억할 것**: 코드는 intentional하고, typed하며, observable하고, boundary-safe해야 합니다. 입증된 필요가 없는 한 마이크로 최적화보다 유지보수성을 우선합니다.

## 파일 입력 유효성 체크

- 이 스킬의 현재 요청이 파일 입력 없이도 수행 가능한 범위라면, 파일 경로를 요구하지 말고 바로 작업을 진행합니다.
- 사용자가 문서/코드/계약서 본문을 메시지에 직접 제공한 경우에는 파일 경로 없이도 해당 텍스트로 작업을 진행합니다.
- 특정 파일의 실제 내용을 읽어야만 작업이 가능한 경우에만, **파일 경로 + 파일명** 제공 여부를 확인합니다.
- 파일 경로 또는 파일명이 누락된 경우에는 파일 작업을 진행하지 않고, 사용자에게 정확한 파일 경로와 파일명을 먼저 요청합니다.
- 경로가 모호한 표현(예: "그 파일", "지난번 문서")만 있는 경우에도 동일하게 명시 경로를 요청합니다.

