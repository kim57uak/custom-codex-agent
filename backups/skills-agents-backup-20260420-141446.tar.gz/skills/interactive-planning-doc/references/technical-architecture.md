# 기술 아키텍처

사용자가 대략적인 비즈니스 메모만 제공했더라도, 기획 문서에 기술 설계 레이어가 필요할 때 이 참고 문서를 사용합니다.

## 핵심 원칙

이 스킬은 다음이 연결된 통합 기획 문서를 만들어야 합니다.

- business goal은 왜 이 시스템이 존재하는지 설명한다
- product scope는 시스템이 무엇을 해야 하는지 설명한다
- technical architecture는 그것이 현실적으로 어떻게 전달되고 운영될지 설명한다

실제 시스템, 플랫폼, workflow automation, data pipeline, AI product를 암시하는 요청이라면 architecture를 선택적 후순위 항목으로 취급하지 않습니다.

## 기본 기술 섹션

초안 성숙도에 맞는 유용한 섹션만 추가합니다.

```md
## Technical Architecture Overview
- architecture style
- major building blocks
- hosting or runtime assumptions

## System Components and Responsibilities
- client or channel layer
- backend services
- data stores
- external integrations
- admin or operations tooling

## Data Flow and Integration Points
- main request or event flow
- source systems
- APIs, queues, schedulers, or batch jobs
- data ownership and synchronization boundaries

## Non-Functional Requirements
- performance
- availability
- security and permissions
- auditability
- observability
- scalability

## Technical Risks and Dependencies
- integration uncertainty
- infra cost or capacity risk
- vendor lock-in
- security or compliance review
- migration complexity
```

## 아키텍처 휴리스틱

### 1. 비즈니스 흐름에서 시작

사용자가 다음처럼 말하면:

- "고객 문의를 자동 분류하고 응답 시간을 줄이고 싶다"

이를 다음과 같은 아키텍처 질문과 연결해야 합니다.

- 어떤 채널이 요청을 수집하는가
- 분류 로직은 어디서 실행되는가
- agent, rule engine, workflow orchestrator가 필요한가
- human review는 어느 지점에 들어오는가
- 로그와 audit record는 어디에 저장되는가

### 2. 책임 단위로 분해

다음처럼 모호한 표현은 피합니다.

- "백엔드와 DB를 둔다"

다음처럼 더 구체적으로 씁니다.

- "사용자 요청을 수집하는 채널 계층"
- "업무 규칙과 상태 전이를 처리하는 애플리케이션 서비스"
- "이력과 상태를 보관하는 운영 데이터 저장소"
- "알림, 그룹웨어, CRM 등 외부 시스템 연동 계층"

### 3. 선택을 trade-off와 연결

가능하면 아키텍처 선택을 비즈니스 영향과 연결합니다.

예:

- synchronous API vs asynchronous queue는 response latency와 운영 복원력에 영향을 준다
- managed SaaS vs in-house service는 delivery speed, lock-in, control에 영향을 준다
- monolith vs separated service는 팀 자율성, 복잡도, release risk에 영향을 준다

### 4. 가정을 명시적으로 기록

정확한 스택 세부 사항을 모를 때도 다음처럼 경계가 있는 가정을 적습니다.

- "초기 버전은 단일 리전 클라우드 배포를 전제로 한다."
- "1차 릴리스에서는 실시간 대규모 스트리밍보다 요청 기반 처리에 최적화한다."
- "민감정보는 사내 인증 체계와 권한 모델을 따라야 한다."

### 5. 운영 현실까지 포함

운영 고려가 없으면 아키텍처 기획은 불완전합니다.

요청에 맞는 항목을 포함합니다.

- monitoring과 alerting
- 실패 처리와 retry
- admin tooling
- audit trail
- backup과 recovery
- deployment와 rollout strategy

## 물어볼 가치가 있는 질문

답이 아키텍처를 실질적으로 바꿀 때만 좁게 질문합니다.

가치 높은 예:

- "기존에 반드시 연동해야 하는 시스템이 있나요?"
- "실시간 처리여야 하나요, 아니면 분 단위 배치도 가능한가요?"
- "권한 체계나 보안 규정상 반드시 따라야 할 제약이 있나요?"

## 추론해야 할 것

사용자가 스택을 명시하지 않았을 때는 조심스럽게 추론합니다.

다음은 제안할 수 있습니다.

- 가능성이 높은 architecture style
- component boundary
- core integration flow
- non-functional requirement

확인되기 전까지는 assumption으로 표시합니다.
