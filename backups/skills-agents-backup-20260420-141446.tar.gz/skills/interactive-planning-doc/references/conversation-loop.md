# 대화 루프

사용자가 여러 턴에 걸쳐 점진적으로 기획 내용을 제공할 때 이 참고 문서를 사용합니다.

## 핵심 원칙

사용자가 한 번의 메시지로 전체 템플릿을 채울 것을 기대하지 않습니다.

당신의 역할은 불완전하고, 지저분하고, 계속 바뀌는 텍스트를 점진적으로 더 나은 기획 문서로 바꾸면서 대화 마찰을 최소화하는 것입니다.

항상 다음 두 렌즈를 함께 추적합니다.

- business planning lens: audience, problem, value, scope, KPI, rollout
- technical planning lens: architecture, components, integration, data flow, security, operations

## 턴별 워크플로

### 1. 현재 성숙도 감지

초안을 비공식적으로 다음과 같이 분류합니다.

- level 0: 대략적인 아이디어나 주제만 존재
- level 1: 문제와 대상 사용자가 부분적으로 파악됨
- level 2: 범위, 솔루션 형태, 초기 아키텍처가 드러나기 시작함
- level 3: 요구사항, 연동, 지표, rollout이 구체화되기 시작함
- level 4: 거의 완성되었고, 문장 다듬기와 아키텍처/리스크 정리가 필요함

이 성숙도를 기준으로 질문할지, 추론할지, 다듬을지 결정합니다.

### 2. 새 입력 병합

각 새 사용자 메시지에 대해:

- 사실을 추출합니다
- 선호를 추출합니다
- 제약을 추출합니다
- 암묵적 가정을 추출합니다
- 각 항목을 business, product, technical, cross-cutting으로 분류합니다
- 기존 초안과의 충돌을 감지합니다

채팅 답변만이 아니라 정식 초안 파일을 갱신해야 합니다.

### 3. 최적의 다음 행동 결정

각 턴에서 하나의 주된 행동을 고릅니다.

- `structure`: 메모가 너무 거칠어 정리가 필요할 때
- `expand`: 사용자가 섹션을 깊게 만들 만큼 충분한 정보를 줬을 때
- `clarify`: 하나의 누락 정보가 주요 결정을 막을 때
- `architect`: 비즈니스 의도는 분명하지만 기술 구현이 얇을 때
- `tighten`: 문서는 있지만 문장이 느슨할 때
- `prioritize`: 범위, 단계, 요구사항에 우선순위가 필요할 때

한 답변에서 너무 많은 목표를 섞지 않습니다. 가장 지렛대가 큰 행동 하나를 고릅니다.

### 4. 좁게 질문하기

질문이 필요하다면:

- 다음 수정에 실질적 영향을 주는 것만 묻습니다
- 설문보다 강한 질문 하나를 선호합니다
- 필요하면 최대 세 개의 짧은 질문만 합니다

좋은 질문:

- "이 기획서의 1차 대상 사용자는 누구인가요?"
- "이번 문서가 설득하려는 대상은 경영진인가요, 개발팀인가요, 외부 고객사인가요?"
- "이번 1차 릴리스에서 반드시 포함해야 할 범위는 어디까지인가요?"
- "반드시 연동해야 하는 기존 시스템이나 데이터 소스가 있나요?"
- "실시간 처리와 배치 처리 중 어느 쪽 제약이 더 중요한가요?"

좋지 않은 질문:

- 긴 intake form
- 지금은 안전하게 가정할 수 있는 답을 묻는 질문
- "더 자세히 설명해주세요" 같은 포괄적 질문

### 5. 불확실성을 명시적으로 보존

미해결 항목은 `Open Questions`나 `Assumptions` 같은 섹션에서 눈에 보이게 관리합니다.

다음 구분을 사용합니다.

- confirmed: 사용자가 명시한 내용
- assumed: 진행 유지를 위해 추론한 내용
- unresolved: 사용자 확인이 아직 필요한 내용

기술 항목은 특히 다음을 명시합니다.

- confirmed architecture constraint
- proposed architecture assumption
- unresolved integration 또는 operational dependency

### 6. 모든 의미 있는 턴은 진행감 있게 마무리

응답은 다음 중 하나를 사용자에게 남겨야 합니다.

- 개선된 초안 + 다음 집중 질문
- 개선된 초안 + 권장 다음 정제 단계
- 개선된 초안 + 해당 섹션이 안정화되었을 때의 decision summary

## 정식 초안 규칙

파일이 존재하면 그것을 source of truth로 취급합니다.

- 의미 있는 모든 턴에서 갱신합니다
- 경쟁하는 병렬 초안을 만들지 않습니다
- 명확한 재구성 이유가 없는 한 섹션 순서를 안정적으로 유지합니다
- 중복 메모를 덧붙이지 말고 섹션을 깔끔하게 다시 씁니다

권장 부록 블록:

- `Assumptions`
- `Open Questions`
- `Change Log`
- `Architecture Decisions`

변경 로그는 짧아도 됩니다. 예:

- v0.2: target user와 MVP scope 명확화
- v0.3: KPI와 rollout risk 추가

## 자율성 임계값

다음과 같으면 질문 없이 진행합니다.

- 수정이 편집 수준일 때
- 누락된 세부 사항의 리스크가 낮을 때
- 표준적인 기획 가정을 명확히 라벨링할 수 있을 때
- 합리적인 baseline architecture를 가정으로 제안할 수 있을 때

다음과 같으면 확정 전에 질문합니다.

- budget, ownership, timeline을 지어내게 되는 경우
- stakeholder 또는 audience가 문서의 톤과 구조를 바꾸는 경우
- 아키텍처 선택이 특정 인프라, compliance posture, integration commitment를 암시하는 경우
- scope boundary가 의사결정자를 오도할 만큼 모호한 경우
