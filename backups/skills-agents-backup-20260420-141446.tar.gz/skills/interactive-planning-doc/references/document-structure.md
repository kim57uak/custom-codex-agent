# 문서 구조

조각난 사용자 입력으로부터 살아 있는 기획 문서를 구성할 때 이 참고 문서를 사용합니다.

## 기본 골격

필요한 섹션만 사용합니다. 초기 초안은 4~6개 섹션만 있어도 충분합니다.

```md
# {Document Title}

## 1. Summary
- What is being proposed
- Why now
- Expected outcome

## 2. Background and Problem
- Current situation
- Pain points
- Why existing alternatives are insufficient

## 3. Goals and Non-Goals
### Goals
- ...

### Non-Goals
- ...

## 4. Target Users or Stakeholders
- Primary audience
- Secondary audience
- Key needs or motivations

## 5. Scope
### In Scope
- ...

### Out of Scope
- ...

## 6. Solution Concept
- Core idea
- Major components
- Operating principles

## 7. Technical Architecture Overview
- Architecture style
- Delivery assumptions
- Key technical decisions

## 8. System Components and Responsibilities
- Client/channel
- Application services
- Data stores
- External systems

## 9. Data Flow and Integration Points
- Main process flow
- API/event/batch boundaries
- Integration and ownership boundaries

## 10. Requirements
### Functional Requirements
- ...

### Non-Functional Requirements
- ...

## 11. Success Metrics
- KPI
- Measurement method
- Target threshold

## 12. Risks and Open Questions
- Risks
- Dependencies
- Questions needing confirmation

## 13. Rollout Plan
- Phase 1
- Phase 2
- Owners or collaborating teams
```

## 섹션별 휴리스틱

### Summary

모호한 도입부가 아니라 짧은 executive overview로 씁니다.

다음에 답해야 합니다.

- 무엇을 제안하는가
- 누구를 위한 것인가
- 어떤 비즈니스/사용자 성과를 만들고자 하는가

### Background and Problem

넓은 표현보다 근거와 구체적 pain point를 우선합니다.

예를 들어:

- "운영이 너무 비효율적임"

같은 메모는 다음처럼 의사결정에 쓸 수 있는 문장으로 바꿉니다.

- "현재 운영팀은 수작업으로 요청을 분류하고 처리해 평균 응답 시간이 길어지고 있으며, 반복 업무 비중이 높아 확장성이 떨어진다."

### Goals and Non-Goals

이 섹션은 scope drift를 막기 위해 사용합니다.

사용자가 넓은 포부를 말하면 이를 나눕니다.

- 이번 단계에서 실제로 전달할 것
- 지금은 의도적으로 제외할 것

### Scope

이 섹션은 MVP 경계를 눈에 보이게 해야 합니다.

사용자가 확신이 없으면 비워 두지 말고 thin-slice scope를 제안합니다.

### Technical Architecture Overview

이 섹션은 계획된 기능이 시스템 수준에서 어떻게 구현될지 설명해야 합니다.

최소한 다음을 다룹니다.

- 어떤 종류의 아키텍처를 가정하는가
- 어떤 주요 기술 빌딩 블록이 필요한가
- 어떤 제약이 아키텍처를 규정하는가

### System Components and Responsibilities

계획이 실제 구현 가능해지도록 시스템을 명확한 책임 단위로 나눕니다.

대표적인 컴포넌트 그룹:

- client 또는 user touchpoint
- workflow 또는 business logic layer
- data storage
- integration adapter
- operations 또는 admin console

### Data Flow and Integration Points

정보가 시스템을 통해 어떻게 이동하는지 보여 줍니다.

이 섹션에 좋은 질문:

- 데이터는 어디서 들어오는가
- 어디서 검증/변환되는가
- 어떤 시스템을 호출해야 하는가
- 상태는 어디에 저장되는가
- 실패는 어떻게 재시도하거나 처리하는가

### Requirements

브레인스토밍 bullet을 그대로 던지지 않습니다. 가능하면 테스트 가능한 문장으로 정규화합니다.

좋은 예:

- "사용자는 요청 상태를 단계별로 확인할 수 있어야 한다."

약한 예:

- "상태 관리 기능 필요"

### Success Metrics

지표가 없으면 placeholder metric을 제안하고 assumption으로 표시합니다.

대표 예시:

- task completion time 감소
- conversion 또는 adoption rate
- 오류 감소
- response SLA 개선
- 수작업 workload 감소
- system uptime 또는 failure-rate 목표
- processing latency 목표

### Risks and Open Questions

이 섹션은 전체 대화 동안 계속 살아 있어야 합니다.

대표 리스크 범주:

- 다른 팀 의존성
- 불명확한 데이터 가용성
- 법무 또는 정책 검토
- 압축된 일정
- 운영 도입 리스크
- 현재 팀 역량 대비 아키텍처 복잡도
- 외부 API 의존성과 신뢰성 리스크
- 보안, 개인정보, compliance 공백

## 톤 규칙

- 사용자의 언어에 맞춰 간결한 비즈니스 한국어 또는 평이한 전문 영어를 사용합니다.
- 마케팅식 수사는 피합니다.
- 행동을 암시하지 않는 일반적 전략 문구는 피합니다.
- 명시적 결정, trade-off, 경계를 선호합니다.

## 점진적 확장 순서

사용자가 다른 순서를 강하게 이끌지 않는 한 다음 순서로 확장합니다.

1. summary
2. problem
3. audience
4. scope
5. solution
6. technical architecture
7. requirements
8. metrics
9. risks
10. rollout

이 순서는 사용자가 정보를 뒤섞어 제공해도 문서의 일관성을 유지하게 해 줍니다.
