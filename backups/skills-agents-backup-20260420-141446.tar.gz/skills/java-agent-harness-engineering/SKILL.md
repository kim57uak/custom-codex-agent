---
name: java-agent-harness-engineering
description: 명확한 도구 계약, 오류 복구 경로, 소프트웨어 엔지니어링 품질 게이트를 갖춘 Java 지향 Codex 하네스를 설계하고 운영합니다.
origin: custom
---

# Java 에이전트 하네스 엔지니어링

Codex가 Java 시스템을 구축할 때 어떻게 계획하고, 실행하고, 관찰하고, 복구해야 하는지 정의할 때 이 스킬을 사용합니다.

## 활성화 기준

- Java 서비스/애플리케이션 워크플로를 구축하거나 리팩터링할 때
- 코드 생성 또는 검증을 위한 tool/action contract를 설계할 때
- 복잡한 엔지니어링 작업에서 completion reliability를 높일 때

## 하네스 설계 모델

결과 품질은 다음에 의해 제한됩니다.

1. Action-space precision
2. Observation quality
3. Recovery strategy
4. Context budget discipline
5. Quality-gate rigor

## 액션 계약

모든 액션은 다음을 명시해야 합니다.

- `action_name`: 안정적이고 명시적인 동사구
- `inputs`: schema-first typed parameter
- `preconditions`: 실행 전 safety check
- `expected_output`: deterministic shape

예:

```yaml
action_name: generate_repository_port
inputs:
  aggregate: Order
  id_type: UUID
preconditions:
  - domain package exists
  - persistence adapter boundary defined
expected_output:
  status: success|warning|error
  artifact_paths:
    - src/main/java/com/acme/app/domain/port/OrderRepository.java
```

## 관찰 계약

각 단계는 다음을 반환합니다.

- `status`: success|warning|error
- `summary`: 한 줄 사실 요약
- `artifacts`: 변경된 경로 또는 생성된 식별자
- `next_actions`: 구체적 후속 행동

## 오류 복구 계약

각 실패는 다음을 포함해야 합니다.

- root-cause hypothesis
- safe retry instruction
- stop condition과 escalation trigger

## Java 엔지니어링 제약

- 가능하면 domain을 framework annotation에서 독립적으로 유지합니다.
- transaction은 application layer boundary에 둡니다.
- boundary DTO는 Bean Validation으로 검증합니다.
- immutable DTO와 value object를 선호합니다.
- 명시적 exception taxonomy를 사용합니다. validation/domain/infrastructure를 구분합니다.

## 품질 게이트

완료로 표시하기 전에:

1. 빌드가 컴파일되어야 합니다. `mvn -q -DskipTests compile` 또는 Gradle 동등 명령
2. 영향 범위의 테스트가 통과해야 합니다
3. 새로운 동작에는 최소 하나의 failing-then-passing regression test가 있어야 합니다
4. 공개 API 계약과 오류 응답이 문서화되어야 합니다
5. 보안 민감 변경에는 abuse-case check가 포함되어야 합니다

## 안티패턴

- 목적이 겹치고 소유권이 불명확한 tool action
- artifact pointer가 없는 불투명한 출력
- 삼켜진 예외와 침묵 실패
- controller/adapter에 구현된 domain logic
- 타깃 reference 대신 큰 context dump

## 파일 입력 유효성 체크

- 이 스킬의 현재 요청이 파일 입력 없이도 수행 가능한 범위라면, 파일 경로를 요구하지 말고 바로 작업을 진행합니다.
- 사용자가 문서/코드/계약서 본문을 메시지에 직접 제공한 경우에는 파일 경로 없이도 해당 텍스트로 작업을 진행합니다.
- 특정 파일의 실제 내용을 읽어야만 작업이 가능한 경우에만, **파일 경로 + 파일명** 제공 여부를 확인합니다.
- 파일 경로 또는 파일명이 누락된 경우에는 파일 작업을 진행하지 않고, 사용자에게 정확한 파일 경로와 파일명을 먼저 요청합니다.
- 경로가 모호한 표현(예: "그 파일", "지난번 문서")만 있는 경우에도 동일하게 명시 경로를 요청합니다.

