# Global Agents

Generated under `/Users/dolpaks/.codex/agents`.

- `advanced-statistical-analysis-agent` -> `/Users/dolpaks/.codex/skills/advanced-statistical-analysis/SKILL.md`
- `contract-review-agent` -> `/Users/dolpaks/.codex/skills/contract-review/SKILL.md`
- `doc-agent` -> `/Users/dolpaks/.codex/skills/doc/SKILL.md`
- `imagegen-agent` -> `/Users/dolpaks/.codex/skills/imagegen/SKILL.md`
- `interactive-planning-doc-agent` -> `/Users/dolpaks/.codex/skills/interactive-planning-doc/SKILL.md`
- `java-a2a-multi-agent-agent` -> `/Users/dolpaks/.codex/skills/java-a2a-multi-agent/SKILL.md`
- `java-agent-harness-engineering-agent` -> `/Users/dolpaks/.codex/skills/java-agent-harness-engineering/SKILL.md`
- `java-coding-standards-agent` -> `/Users/dolpaks/.codex/skills/java-coding-standards/SKILL.md`
- `openai-docs-agent` -> `/Users/dolpaks/.codex/skills/openai-docs/SKILL.md`
- `pdf-agent` -> `/Users/dolpaks/.codex/skills/pdf/SKILL.md`
- `plugin-creator-agent` -> `/Users/dolpaks/.codex/skills/plugin-creator/SKILL.md`
- `polyglot-code-review-agent` -> `/Users/dolpaks/.codex/skills/polyglot-code-review/SKILL.md`
- `pptx-generator-agent` -> `/Users/dolpaks/.codex/skills/pptx-generator/SKILL.md`
- `program-from-planning-doc-agent` -> `/Users/dolpaks/.codex/skills/program-from-planning-doc/SKILL.md`
- `skill-creator-agent` -> `/Users/dolpaks/.codex/skills/skill-creator/SKILL.md`
- `skill-installer-agent` -> `/Users/dolpaks/.codex/skills/skill-installer/SKILL.md`
- `springboot-patterns-agent` -> `/Users/dolpaks/.codex/skills/springboot-patterns/SKILL.md`
- `springboot-security-agent` -> `/Users/dolpaks/.codex/skills/springboot-security/SKILL.md`
- `springboot-verification-agent` -> `/Users/dolpaks/.codex/skills/springboot-verification/SKILL.md`

- `router-agent` -> routes to one of the single-skill agents
