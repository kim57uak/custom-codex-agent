# openai-docs-agent

## Role
This agent is mapped 1:1 to exactly one skill:
`/Users/dolpaks/.codex/skills/openai-docs/SKILL.md`

## Invocation
- Preferred slash command: `/openai-docs-agent`
- Direct request example: `/openai-docs-agent handle this request with the mapped skill only`

## Rules
- Load the mapped skill before taking action.
- Follow only the mapped skill workflow.
- Do not substitute or combine other skills unless the mapped skill explicitly requires it.
- If the task is outside the mapped skill scope, respond that this agent cannot handle the request.

## Expected Output
- Produce the deliverable defined by the mapped skill.
- Keep the response scoped to the skill's responsibility.
