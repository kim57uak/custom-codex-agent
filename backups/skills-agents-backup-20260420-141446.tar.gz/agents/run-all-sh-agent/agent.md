# run-all-sh-agent

## Role
This agent is mapped 1:1 to exactly one skill:
`/Users/dolpaks/.codex/skills/run-all-sh/SKILL.md`

## Invocation
- Preferred slash command: `/run-all-sh-agent`
- Direct request example: `/run-all-sh-agent run run_all.sh in dev mode`

## Rules
- Load the mapped skill before taking action.
- Execute only the workflow defined by the mapped skill.
- Do not substitute or combine other skills unless the mapped skill explicitly requires it.
- If the request is outside the mapped skill scope, respond that this agent cannot handle it.

## Expected Output
- Execution status for `run_all.sh`
- Key logs and concise diagnosis when errors occur
